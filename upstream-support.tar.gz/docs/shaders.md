# Horizon shader packs

Horizon has its own shader packs: WGSL written against stages of Horizon's renderer, checked before they run. This page
is the guide for pack authors. The design and the pack format are in [api/shaders.md](api/shaders.md); every stage's
signature, input, resource and limit is in the generated
[api/shaders-reference-0.2.md](api/shaders-reference-0.2.md).

**Shader API 0.1 is retired (#15886).** A 0.1 pack is refused with `needs shader API 0.1; this Horizon serves 0.2`:
it stays in the list, and the game draws without it. To move one, set `api = "0.2"` and treat colours as linear light,
as [api/shaders.md](api/shaders.md#shader-api-02) describes; the example pack Golden Hour 2.0.0 was moved
that way.

Shader packs in the Iris/OptiFine format are a separate feature with its own loader; this page is only about
Horizon's own format.

| Part | Where | State |
|---|---|---|
| Format, stages, check | `crates/horizon-shader-api` | API 0.2, final (preview) |
| Authoring tool | `horizon-shader` (same crate) | `new`, `check`, `pack` |
| Templates | `crates/horizon-shader-api/templates/` | post, sky, material |
| Example pack | `crates/horizon-shader-api/packs/golden_hour` | a warm sky and two post passes |
| Horizon's HDR look as a pack | `crates/horizon-shader-api/packs/horizon_hdr` | material, entity and tonemap stages over the look file the renderer itself starts with |
| In the game: every stage | Options > Video Settings > Shaders > Shader Packs | sky, material, post passes, hot reload |
| The registry and the launcher | `shader` kind ([modding/src/reference/registry-index.md](modding/src/reference/registry-index.md)); the Mods page's Shader packs tab | checked, then installed into `shaderpacks/` |

## Quick start

```sh
cargo install --path crates/horizon-shader-api      # or: cargo run -p horizon-shader-api --bin horizon-shader -- <command>
horizon-shader new my_pack --template post          # also: --template sky, --template material; --name "My Pack"
horizon-shader check my_pack                        # what the game, the launcher and the registry will check
horizon-shader pack my_pack                         # check, then write my_pack-0.1.0.hshader beside the folder
```

`check` prints each stage with its cost, and the pack's SHA-256:

```
golden_hour 2.0.0 (shader API 0.2): ok
  sky       Warm horizon                    131 expressions, 0 texture reads
  post      Glow                            346 expressions, 5 texture reads
  post      Colour grade                    367 expressions, 4 texture reads
  sha256 0b990082...
```

or every problem, at its file, line and column:

```
my_pack 0.1.0 (shader API 0.2): FAILED
  post.wgsl:9:1: expected `;`, found "}"
```

`--json` prints the same for tools (`ok`, `id`, `version`, `api`, `sha256`, `stages`, `problems`).

## Trying a pack in the game

Put the pack folder (or its `.hshader`) in `shaderpacks/` beside `options.txt` (Open Pack Folder opens it) and pick
it on Options > Video Settings > Shaders > Shader Packs..., which lists Horizon's packs, marked (Horizon), beside packs in the
`shaders/` format; one runs at a time, and clicking it again turns it off. `HORIZON_SHADER_PACK=<its folder or file
name>` runs a pack whatever the page says, for development. `HORIZON_TERRAIN_LOOKS=1` makes terrain keep each quad's
own tint, directional shade, ambient occlusion and face beside its vertices while one of Horizon's packs
runs, as a pack whose material or vertex stage reads `tint`, `shade`, `ao` or `face` does, for the engine's
own tests: they take a third again the terrain's memory, and the world loads again when such a pack starts or stops. The game checks the pack first, and refuses one that
fails, with its problems in the chat. While it runs, the game looks at the pack twice a second: save a file
and the pack is checked and rebuilt in place ("Shader pack ... reloaded"); if the new version fails, the chat says
where. A stage that fails keeps the last good version drawing; a manifest that is refused (another API line, a
mistake in it, something the game doesn't draw yet) turns the pack off until it is fixed. All three stages run.

A picked pack's options are pages of the same screen, under the pack's name in its page list: its screens, with the
names the pack gives them, its profiles, and Reset. The main screen and those it links to are in the list (when
there are more than it has room for, they collapse into one `‹ Name ›` row that the arrows and a controller's
bumpers step through); deeper screens open from their links, and Escape goes back. A click, Enter or Right picks an
option's next value, a Shift click or Left the one before, and the options the pack lists in
`sliders` are sliders. Pointing at one shows what the pack says of it (`option.NAME.comment`); the search finds an
option on any screen. Undo puts back the pick, the Shadow Cache, the Horizon packs' options and the options of the
`shaders/` pack that was picked when the screen opened; another `shaders/` pack keeps what was saved for it (picking
away from it saves its changes, as Apply does). A `shaders/` pack's
options are saved to `shaderpacks/<pack>.txt` (`NAME=value` lines), and the pack loads again with them, with Apply
(shown while they differ from the saved ones) or on leaving the screen; a Horizon pack's apply at once.

## Testing a pack frame by frame

A pack that keeps something from frame to frame (kept resources, eased values) draws a little differently in every run,
as frames come when they come. With `HORIZON_STILL=1` and the world frozen the scene holds still
([agent-control.md](agent-control.md#repeatable-screenshots)), and

```sh
horizon-ctl screenshot-sequence 64 50 frame64.png
```

starts the pack over as if just loaded (eased values from the start) and draws 64 frames 50 ms
apart on its clock: frame n has `frame_index` n, `time` (n - 1) × 0.05 and `delta_time` 0.05 (0 on frame 1). The
64th is written to `frame64.png` (and `frame64-hdr.png` with HDR output on) before the reply. STEP_MS may be a
decimal: `16.666667` steps a 60 fps clock. The same build, GPU
and driver write the same bytes every run, so two versions of a pack compare by a pixel diff. `screenshot-sequence
cancel` stops one.

## A pack

A folder (or the same files zipped as a `.hshader`) with `horizon-shaders.toml` and WGSL files:

```toml
schema = 1
id = "my_pack"
name = "My Pack"
version = "0.1.0"
api = "0.2"

[[post]]
file = "post.wgsl"

[[options]]
id = "saturation"
name = "Saturation"
type = "float"
default = 1.15
min = 0.0
max = 2.0
```

Every key is in [api/shaders.md](api/shaders.md#the-pack-format-schema-1).

## Stages

A stage is one function your file defines. Horizon puts its prelude (the structs, `frame`, the stage's resources and
helpers) before your file and calls the function from its own pass, so the world is still culled, batched and meshed
by Horizon: a pack changes how things look, not how they are drawn.

| Stage | Your function | What it does |
| --- | --- | --- |
| `[sky]` | `fn sky(input: SkyInput) -> vec4<f32>` | the sky's colour along each view ray, opaque (alpha is ignored), drawn where vanilla draws its sky dome (the Overworld's sky; not the Nether's or the End's); the sun, moon, stars and clouds are drawn over it |
| `[material]` | `fn material(input: MaterialInput) -> Surface` | the lit colour of each point of a block's surface, before the alpha test and fog: every terrain section and distant tile, solid, cutout and translucent (not entities, block entities or particles) |
| `[entity]` | `fn entity(input: EntityInput) -> Surface` | the lit colour of each point of an entity or a block entity (mobs, players, armour, chests, banners), before the alpha test, the enchantment glint and fog; `input.kind` says which. Items and particles keep Horizon's lighting for now |
| `[weather]` | `fn weather(input: WeatherInput) -> vec4<f32>` | the colour of each point of a rain or snow streak, blended over the world with its alpha; Horizon's light and fog aren't applied, so the pack applies its own |
| `[[post]]` | `fn post(input: PostInput) -> vec4<f32>` | a full-screen pass over the world's picture (up to 12, in order), under the hand and HUD; its alpha is ignored |
| `[tonemap]` | `fn tonemap(input: TonemapInput) -> vec3<f32>` | the post chain's picture for the display, from 0 to `frame.headroom`; without it Horizon's curve runs |

A pack has at least one stage; a stage it leaves out keeps vanilla's look. Each input says what vanilla would draw
(`input.color` in the sky and post stages; `albedo * shaded_tint * vec4(lightmap, 1.0)` for a material, `shaded_tint`
being vanilla's vertex colour, the quad's `tint` times its `shade` and `ao`), so a pack can start
from vanilla and change only what it means to.

Every colour a stage reads or returns is linear light: 1.0 is vanilla's white, and more is brighter, on SDR and HDR
displays alike. Horizon decodes vanilla's gamma values on the way in and encodes what the frame stores, so a constant
written for display values is decoded first (`pow(c, vec3(2.2))`), and luminance is `dot(c, frame.luminance)`.

Every stage can read `frame`: the camera's matrices and position, the sun and moon directions, the time of day,
vanilla's sky and fog colours, rain and thunder, fog distances, the light at the camera, effects and the dimension.
Post passes also read `scene_color`, `scene_depth`, `previous` (the last pass's output), two samplers and the helpers
`depth_at(uv)` and `view_position(uv, depth)`.

Rules the check enforces: your files declare no bindings (`@group`/`@binding`), no entry points and no names starting
with `horizon_`. Code shared by several stages goes in files listed in `shared`, put before every stage.

## Sprite tags

The material stage can tell block sprites apart through tags the manifest declares, and so can a traced ray's hit
(`RayHit.tags`, [ray tracing](#ray-tracing)): a pack with tags has a `[material]` stage or `[ray_tracing]`. Each
`[[tags]]` is a bit of `input.tags`, in the order they appear (32 at most); its `sprites` are sprite names, the namespace `minecraft` by
default, each with at most one `*`:

```toml
[[tags]]
id = "glass"                                      # bit 0: (input.tags & 1u) != 0u
sprites = ["block/glass", "block/*_stained_glass"]
```

Terrain carries its sprite, not its block, so a sprite drawn by several blocks gets the tag for all of them.

## Material ids

Tags answer "is it one of these"; a pack that treats hundreds of kinds of surface differently numbers them
instead. Each sprite takes the `id` of the first `[[materials]]` entry that names it, 0 without one, as
`input.material` (and a traced ray's `RayHit.material`). Patterns may hold any number of `*`:

```toml
[[materials]]
id = 10
sprites = ["block/*_leaves"]

[shadow]
solid_materials = [10]   # these cast whole shadows: their cutouts are ignored in the shadow map
```

## Textures

Each `[[textures]]` entry is a PNG in the pack that every stage reads under the name of its `id`, with a sampler named
`<id>_sampler`. Eight at most, without mipmaps; `filter` is `linear` (the default) or `nearest`, `wrap` is `repeat` (the
default) or `clamp`:

```toml
[[textures]]
id = "noise"
file = "noise.png"
```

```wgsl
let n = textureSample(noise, noise_sampler, input.uv);
```

## Coloured block light

Each `[[lights]]` entry gives the blocks it names a colour. The material stage reads the colour at a point with
`block_light_color(input.position)`: rgb the colours of the sources nearby, averaged by how near each is, and a how
strongly they reach it (0 where none does). Block light keeps its own brightness, so walls still stop it: this is only its
colour, and only what a pack does with it shows.

```toml
[[lights]]
color = [0.3, 0.7, 1.0]
blocks = ["soul_torch", "soul_wall_torch", "soul_lantern"]
```

```wgsl
let tint = block_light_color(input.position);
let block = mix(vec3(1.0), tint.rgb, min(tint.a, 1.0)) * input.light.x;
```

It covers 128 blocks around the camera, moved in steps of 16, and is rebuilt on the CPU when the camera steps or a source
changes, from at most 2048 sources, the nearest first.

## Ray tracing

A pack of API 0.2 can trace rays through the world from its post, material, entity and compute stages. The pack
declares an empty `[ray_tracing]` table and includes a `[[post]]` pass, a `[[before_world]]` pass, a `[material]` or an
`[entity]` stage. Post passes get the trace functions. The other supported stages get them where their files name
one. See the [reference](api/shaders-reference-0.2.md#ray-tracing) for `RayHit`'s fields:

```toml
api = "0.2"

[ray_tracing]

[[post]]
file = "post.wgsl"
```

```wgsl
let position = view_position(input.uv, input.depth);
// A little toward the camera, off the surface the point is on.
if frame.has_ray_tracing == 1u && trace_any(position * 0.99, frame.sun_direction, 512.0) {
    // Terrain stands between the point and the sun.
}
let hit = trace(position * 0.99, direction, 64.0);   // hit.distance < 0.0: nothing there
```

`trace` returns the nearest solid surface along a ray, with what the material stage would get for that point (`albedo`,
`uv`, `material`, `tags`, `fluid`, `translucent`, `tangent`, and on a terrain hit `tint`, `shade` and `ao`)
and its `position`, `normal`, `back` and `distance`. `light` excludes dynamic light. Terrain `emission` comes
from the vertex and gives the block's light level over 15. A pack that reads hit `tint`, `shade` or `ao` queues
fresh meshes for loaded sections. A hit without a usable look record uses baked vertex colour and 1 for both
`shade` and `ao`.
`trace_any` only says whether something is in the way, which is all a shadow needs. Origins are camera-relative,
as `view_position` gives them, and
rays pass through the clear texels of leaves and plants, and through water, stained glass and ice, which are in a
[layer of their own](#layers). `frame.ray_distance` is the distance the scene covers in every direction; a longer ray
is allowed and may still hit geometry toward the corners, and no clamp is needed. Horizon keeps the scene; the look is the pack's: Horizon
adds no shadows, bounce light or denoising of its own. The pack never sees the acceleration structure or a ray query,
and the check refuses a pack that names one itself.

| | |
| --- | --- |
| In the scene today | Terrain within 8 chunks of the camera, in two layers: solid terrain (cut-outs and lava included), which `trace` reads, and translucent terrain (water, stained glass, ice), which [`trace_layers`](#layers) reads; `frame.ray_distance` is how far it surely reaches. For a pack that names `RAY_ENTITY`, a third layer: [the entities within that reach](#entities), in view or not. For a pack with `lights = true` under `[ray_tracing]`, [the light sources around the camera](#light-sources) |
| Not in it yet | Block entities at rest (a closed chest) or out of view, the hand, distant terrain tiles |
| Turning it on | Pick the pack and start the game with it, on a GPU and graphics API with hardware ray queries: the device needs them from its creation, so in a game started without them a pack picked while it runs traces from the next start, and the shader pack screen says so. `HORIZON_RAY_TRACING=1` asks for ray queries and keeps the scene with any pack or none; any other value of it turns ray tracing off |
| Without it | The pack loads and runs as it is: `frame.has_ray_tracing` is 0, `trace` misses and `trace_any` is false. Branch on `has_ray_tracing` and keep a look that works without rays. It is also 0 in a pack none of whose stages calls a trace function |
| Graphics APIs | Vulkan; DirectX 12 where it compiles shaders with DXC (integrated GPUs, a discrete GPU whose device asks for ray queries, or `WGPU_DX12_COMPILER=dxc`), as FXC has no ray queries; Metal on macOS 15 and later where the GPU traces rays from render passes (untested). OpenGL has none |
| Video memory | About 450 MB more for solid terrain on an RTX 5070 Ti, the same at render distance 12 and 32, since the scene holds 8 chunks whatever the render distance: its vertex store (384 MiB there; it starts at 24 MiB, doubles when full and grows to at most 1.5 GiB) and its acceleration structures (65 MB; 190 MB on DirectX 12). More with water, glass and ice in view: their copy shares the store, which then doubles earlier (+192 MB where it first does) |
| When video memory runs out | The scene stops growing: sections that don't fit stay out of it, or as they were, or the whole scene stays as it was, until there is room, and the log says so once. Without room for the scene at all, the pack runs as without ray tracing |

A hit also reads the resource packs' LabPBR maps, as a drawn surface does: `hit_normal_map(hit)` and
`hit_specular_map(hit)` give its sprite's texel at full size, with the same defaults as `block_normal_map` and
`block_specular_map` where there are no maps (and on a miss), and `block_pbr_maps()` says whether there are, in a post
pass too (there it is false while the game doesn't trace, when no hit reads them). `hit.tangent` turns the normal map into world axes as `input.tangent` does. A reflection shaded with the
roughness the same block has on screen:

```wgsl
let hit = trace(position * 0.99, direction, 64.0);
let smoothness = select(0.5, hit_specular_map(hit).r, block_pbr_maps());   // LabPBR's perceptual smoothness
let roughness = (1.0 - smoothness) * (1.0 - smoothness);
let shine = pow(max(dot(reflect(direction, hit.normal), frame.sun_direction), 0.0), 2.0 / max(roughness * roughness, 1e-4));
let color = hit.albedo.rgb * hit.tint.rgb * (hit.light.y + hit.emission) + vec3<f32>(shine * hit.light.y);
```

The scene trails the world by a frame or two where chunks load or blocks change, and is empty for the first frames in
a world. The smallest working pack is `crates/horizon-shader-api/packs/traced_shadows`: the sun's shadows, one ray a
pixel.

### Layers

The scene has two layers, three for a pack that names `RAY_ENTITY`, and a ray reads the ones it names. `trace` and
`trace_any` read solid terrain alone; `trace_layers(origin, direction, max_distance, layers)` and
`trace_any_layers(...)` take the layers, `RAY_SOLID`, `RAY_TRANSLUCENT`, `RAY_ENTITY` or several ORed together
(`RAY_SOLID | RAY_TRANSLUCENT`), and are otherwise the same.

| Layer | Holds | A ray stops |
| --- | --- | --- |
| `RAY_SOLID` | What the solid pass draws: opaque blocks, cut-outs (leaves, plants), lava | At an opaque texel, or a cut-out's texel of alpha 0.5 or more: the solid pass's alpha test |
| `RAY_TRANSLUCENT` | What the translucent pass draws: water, glass and panes, ice, slime and honey blocks; any block whose texture has partly see-through texels | At any texel the translucent pass draws, however faint: only a clear one (alpha below 0.01) lets it through |
| `RAY_ENTITY` | Only for a pack whose files name it: [the entities within the scene's reach](#entities) | Where vanilla's entity alpha test keeps the pixel: `(texel * tint).a` of 0.1 or more |

A hit in the translucent layer has `translucent` true, `fluid` 1 on water, and its `albedo.a` is the texture's alpha
there, so a pack decides what the surface does to the ray: a ray over both layers stops at the nearest surface of
either, and goes on when the pack traces again from just behind the hit. A face stops a ray from either side. The
sun's light at a point, cut off by solid terrain and tinted by the first glass or water on the way:

```wgsl
var origin = position * 0.99;                                          // off the surface the point is on
var light = vec3<f32>(1.0);
var layers = RAY_SOLID | RAY_TRANSLUCENT;
for (var i = 0; i < 2; i++) {
    let hit = trace_layers(origin, frame.sun_direction, 512.0, layers);
    if hit.distance < 0.0 { break; }                                   // nothing more in the way
    if !hit.translucent { light = vec3<f32>(0.0); break; }             // solid terrain: in shadow
    light = mix(light, hit.albedo.rgb * hit.tint.rgb, hit.albedo.a);   // glass or water: tinted
    origin = hit.position + frame.sun_direction * 0.01;                // on from just behind it,
    layers = RAY_SOLID;                                                // through any other glass
}
```

The translucent layer is the terrain's translucent quads as they are meshed: still and flowing water alike. A picture
made with `trace` and `trace_any` alone is the same with the layer as without it.

#### Entities

`RAY_ENTITY` is the entities' layer. Only a pack whose files name it has it, anywhere outside a comment (dead code
too): Horizon then builds it every frame, and binds it to the pack's traced stages, which also get `RayHit.entity`.
Every other pack is built and runs as without it.

| | |
| --- | --- |
| In it | Within the scene's reach, mobs, players (third person, and the others), armour stands, item frames, paintings, projectiles, vehicles, falling blocks and block displays, whether the camera draws them this frame or not (behind it, beside it, hidden behind terrain), so turning the camera changes nothing; the block entities at rest that the block entity cache keeps (on in every graphics preset: closed chests, shulker boxes, bells, decorated pots, banners, within vanilla's 64 blocks), in view or not; and the other block entities the camera draws (a chest while it opens) |
| Not in it | Particles, world text and name tags, the hand, the camera's own body in first person, items Horizon draws itself (a dropped item, a framed one), translucent items, breaking cracks, entity shadows, energy swirls, beams, portals, lightning, glowing outlines, additive glows; other block entities out of view (a chest opening behind the camera) |
| A hit | `entity` true. `albedo` the entity texture's texel in linear light, `tint`, `light` and `uv` its vertices' (the colour vanilla multiplies in, alpha included; block and sky light; the atlas position), `normal` the face's against the ray, `tangent` from its uvs, `shade` vanilla's entity shade for the face (the Nether's in the Nether), `ao` 1; `material`, `tags`, `emission` and `fluid` 0, `translucent` false, and `hit_normal_map` and `hit_specular_map` give their defaults |
| A ray stops | Where vanilla's alpha test keeps the entity's pixel, `(texel * tint).a` 0.1 or more, from either side of the face (on the dying dragon's dissolve, where vanilla's mask keeps it). A pack's own `[entity]` alpha is not the layer's: the scene runs no pack code |
| Cost | For a pack that names the layer: the models of the entities within reach that the camera doesn't draw, posed on the CPU every frame, and one BLAS of the frame's entity quads and the TLAS built again every frame. The cached block entities have a BLAS a section, built again only when that section's change (a chest opens or closes, one is placed or broken) |

A mob's traced shadow on what a post pass lights, starting off the surface as from terrain:

```wgsl
let shadowed = trace_any_layers(position + normal * 0.01, frame.sun_direction, 64.0, RAY_SOLID | RAY_ENTITY);
```

#### Light sources

With `lights = true` under `[ray_tracing]`, a stage whose files name `ray_lights_near`, `ray_light`, `ray_light_at`,
`ray_light_count` or `RayLight` (outside a comment) also gets the light sources around the camera: the blocks that
give off light, up to 1024 of them nearest the camera first, and a grid of 8-block cells 128 blocks across over them,
each listing the sources whose light reaches it (at most 24, the strongest there first). A pass then aims shadow rays
at the few sources its cell lists instead of every source in the world. Without the key the five names are the pack's
own, and a pass that doesn't name them doesn't bind them (one storage buffer fewer).

| | |
| --- | --- |
| A source | `RayLight`: `position`, its block's centre, camera-relative to the player's camera as `trace` takes it; `level`, vanilla's light level of the block (1 to 15); `color`, its `[[lights]]` colour, linear as `block_light_color`'s, white for a block the pack gives none; `material`, its `[[materials]]` id as `RayHit.material` reports it, 0 for none (from one fixed model of the state: weighted models with different materials can differ) |
| `ray_lights_near(position)` | The sources whose light reaches some part of the cell of the camera-relative `position`, as `vec2<u32>(first, count)` of indices to read with `ray_light_at` (`0xffffffffu` past the cell's count, which `ray_light` reads as level 0); none outside the grid. Candidates: the pack's own falloff and a trace decide what each gives. Ranked at the cell's nearest point, not at `position`: testing only the first few shows the cells' edges |
| `ray_light(i)`, `ray_light_count()` | The source `i` of the whole list, below `ray_light_count()` (level 0 past it): the sources of the sections the grid and 15 blocks around it touch, so some lie up to a section beyond where their light reaches the grid |
| Not listed | Fluids: lava lakes don't light through the list (a ray meets the lava's surface, with its `emission`) |
| The grid | A convenience over the list with fixed choices; for others, read the list and build a grid of your own into a kept buffer in a compute or `[[before_world]]` pass |
| When it changes | Rebuilt on a CPU worker when the camera moves on to another 16-block step, and at most every 100 ms when a light source is placed or removed; it reaches the passes a frame or two later, its positions still relative to the current camera |
| Without the scene | The names are still there: `ray_light_count()` is 0 and `ray_lights_near` lists nothing |

Block light that walls stop, from a post pass (`position` and `normal` as above). A full glowing block (glowstone)
is in the scene itself, so the ray ends where it enters the source's block, or it would hit the source:

```wgsl
// How far along `direction` the ray from `origin` enters the block centred on `center`.
fn block_entry(origin: vec3<f32>, direction: vec3<f32>, center: vec3<f32>) -> f32 {
    let tiny = vec3<f32>(1e-6);
    let inverse = 1.0 / select(direction, tiny, abs(direction) < tiny);
    let near = min((center - 0.5 - origin) * inverse, (center + 0.5 - origin) * inverse);
    return max(max(near.x, near.y), near.z);
}

let origin = position + normal * 0.02;
let near = ray_lights_near(position);
var light = vec3<f32>(0.0);
for (var i = 0u; i < near.y; i++) {
    let source = ray_light(ray_light_at(near.x + i));
    let to = source.position - origin;
    let d = length(to);
    let falloff = max(1.0 - d / source.level, 0.0);
    let reach = block_entry(origin, to / d, source.position) - 0.01;
    if falloff > 0.0 && (reach <= 0.0 || !trace_any(origin, to / d, reach)) {
        light += source.color * falloff * falloff * max(dot(normal, to / d), 0.0);
    }
}
```

`crates/horizon-shader-api/packs/traced_lights` is that pass as a pack.

**In the material stage.** Translucent terrain (water, stained glass, ice) is blended where `material` shades it and
leaves no surface for a post pass to light, so that is where its rays go. `input.position` and `input.normal` are
camera-relative and in world axes, so a ray starts from them as they are:

```wgsl
if input.translucent && frame.has_ray_tracing == 1u {
    let hit = trace(input.position, reflect(normalize(input.position), input.normal), 64.0);
}
```

- **Where a ray is paid.** A ray in `material` is paid for every terrain fragment drawn, hidden ones included where
  the depth test hasn't rejected them yet; a ray in a post pass once a pixel. But a post pass knows only the solid
  terrain's surface (`surface_at` isn't `present` behind water, glass or entities) and has no albedo, so direct light
  that must be right there is traced in `material`. With `[material] reads`, a pack can also trace in a compute or
  `[[before_world]]` pass and apply the result in `material`.
- **Only `material` itself traces.** `displacement` and the `[vertex]` file run in vertex shaders: the check refuses a
  pack whose `displacement` or `vertex` reaches a trace function.
- **`trace` passes through water.** A ray from a water surface passes through other water: right for the shore's
  reflection, wrong for what lies behind a waterfall. Name the layer to find it: `trace_layers(..., RAY_SOLID |
  RAY_TRANSLUCENT)`, from a point off the surface (`input.position + input.normal * 0.01`), which is in that layer
  itself.
- **Only a stage that calls them pays.** A material, compute or `[[before_world]]` stage whose files name no trace
  function is built as without `[ray_tracing]`; one that does is built twice, the one with the rays drawing in frames
  that have the scene.

`crates/horizon-shader-api/packs/traced_water` is the smallest pack that traces from `material`: water that mixes in
what a reflected ray hits.

**In the entity stage.** `entity` traces as `material` does, with the same functions, the same cost per fragment and
the same rule: an entity stage whose files name no trace function is built as without `[ray_tracing]`. Its rays run
in the world's colour pass only; the shadow map's entities don't run the stage. `input.position` and `input.normal`
are camera-relative and in world axes, and a ray with `RAY_ENTITY` in its layers can hit the entity it starts on, so
start it off the surface as from terrain:

```wgsl
let start = input.position + input.normal * 0.05;
let shadowed = frame.has_ray_tracing == 1u && trace_any(start, frame.sun_direction, 64.0);
```

#### Candidate steps

With `step = true` under `[ray_tracing]`, a stage whose files name `trace_step` or another of its names (outside a
comment) gets a ray query whose rule is the pack's: `trace_step(origin, direction, max_distance, layers, &state)` makes
one query, as `trace_layers` does, and calls the pack's `ray_step(c, &state)` for every surface the ray crosses. The
pack defines the step and its state. Without the key all these names are the pack's own, and a stage that names none of
them is built as without it; a material, entity, compute or `[[before_world]]` stage that names one is traced, as
one that names `trace` is. A stage has one `ray_step` and one `RayState`, which every `trace_step` call in it shares.
Keep them out of a `shared` file that a sky, weather, tonemap or vertex stage also takes: those stages have no
`RayCandidate`. First build with the key: Nightly `TBD`.

| | |
| --- | --- |
| The pack's | `struct RayState { ... }`, any type (an `alias` too; a spectral pack's array of bands), and `fn ray_step(c: RayCandidate, state: ptr<function, RayState>) -> u32` |
| What `ray_step` returns | `RAY_PASS`: go on past the surface. `RAY_STOP`: keep it as the nearest hit so far, which ends the ray at it. `RAY_END`: end the query now, the hit being the nearest kept by then. `RAY_STOP \| RAY_END`: keep this one, then end |
| `RayCandidate` | `distance` along the ray, `layer` (`RAY_SOLID`, `RAY_TRANSLUCENT` or `RAY_ENTITY`); its other fields are Horizon's |
| Read where called | `candidate_stops(c)`, whether `trace_layers` stops there; `candidate_albedo(c)`, `candidate_tint(c)`, `candidate_material(c)`, `candidate_tags(c)`, `candidate_fluid(c)`, each the `RayHit` field of its name at the candidate. A step pays for those it calls |
| The result | The nearest surface a step kept, as `trace_layers` gives a hit; `distance` negative where it kept none |
| Order | None: surfaces don't come nearest first, and one beyond the surface kept in the end may have been stepped before it was kept. A step that gathers (multiplies, adds) keeps nothing, so everything out to `max_distance` counts, or records each contribution's `c.distance` in its state and drops those past the result's `distance` |
| Repeats | A surface may reach the step more than once in one query: the graphics APIs allow it, and Horizon's scene doesn't forbid it yet. A step that only keeps, ends or takes a minimum is unaffected; one that multiplies can count a pane more than once |
| Without the scene | No surface reaches the step: the result misses and `state` stays as passed |
| Refused | A `ray_step` that reaches a trace function (`trace_step` too), a stage without `RayState` or with another `ray_step`, a pack that builds a `RayCandidate` |

`trace_layers` is a step of this kind that keeps a surface where `candidate_stops(c)`, and `trace_any_layers` one that
keeps it and ends. A stage that wants several kinds of step puts a kind in `RayState`, switches on it in its one
`ray_step`, and [writes the `trace_step` call once](api/shaders-reference-0.2.md#written-ray-calls).

The light that gets through glass, in one query where a `trace_layers` loop makes one a pane: the product of the
translucent texels on the way, nothing behind solid terrain, water and two `[[materials]]` passing untinted. The step
keeps no surface, so every pane out to `max_distance` counts, in whatever order they come:

```wgsl
struct RayState {
    light: vec3<f32>,
    skip: vec2<u32>,                                                 // materials that let light through
}
fn ray_step(c: RayCandidate, state: ptr<function, RayState>) -> u32 {
    if !candidate_stops(c) { return RAY_PASS; }                      // a clear texel
    let material = candidate_material(c);
    if material == (*state).skip.x || material == (*state).skip.y { return RAY_PASS; }
    if c.layer == RAY_SOLID {                                        // in shadow: done
        (*state).light = vec3<f32>(0.0);
        return RAY_END;
    }
    if candidate_fluid(c) == 1u { return RAY_PASS; }                 // water, untinted
    let albedo = candidate_albedo(c);
    (*state).light *= mix(vec3<f32>(1.0), albedo.rgb * candidate_tint(c).rgb, albedo.a);
    return RAY_PASS;
}
fn trace_light(origin: vec3<f32>, direction: vec3<f32>, max_distance: f32, skip: vec2<u32>) -> vec3<f32> {
    var state = RayState(vec3<f32>(1.0), skip);
    _ = trace_step(origin, direction, max_distance, RAY_SOLID | RAY_TRANSLUCENT, &state);
    return state.light;
}
```

`candidate_tint` binds the scene's looks, as `RayHit.tint` does; vanilla's glass and ice are untinted, so a pack that
needs no tint leaves it out and the store with it.

## Compute passes and kept resources

Shader API 0.2 has the keys for storage a pack keeps between frames and for compute passes: `[[resource]]` (buffers,
and textures with this frame's and last frame's versions), `[kept] reach`, `[[before_world]]`, `[[post]]` entries
with `compute = true`, and an option's `resets`. A compute file defines `fn compute(input: ComputeInput)`.
The game runs them. The keys, their limits and the WGSL each pass sees are in the
[reference](api/shaders-reference-0.2.md#kept-resources-and-compute-passes).

A pack whose kept resources don't fit in video memory is refused when it loads ("its kept resources (N MiB) don't fit
in video memory"), and the pack that ran keeps running, its resources made again as at a load. R-relative textures
that don't fit at a new render size stay at the old one, which the log says once, until the size changes again.

Under `[ray_tracing]` a compute or `[[before_world]]` file that calls a trace function gets them, as a post pass does;
a `[[before_world]]` pass traces this frame's scene. The four trace names are found by name, as in the material
stage, so under `[ray_tracing]` don't give them to anything of the pack's own.

`[material] reads` lists the kept resources the terrain reads, as a pass's `reads` does: `x` for this frame's version
of a texture a `[[before_world]]` pass writes (it runs before the world draws, so the terrain sees what it wrote this
frame), `x_previous` for last frame's, and a buffer as it is. A `[[post]]` pass writes after the terrain draws, so
for a texture only it writes, the terrain reads `x_previous`: the check refuses `x`. The material writes none, and
only `material`'s fragments read them: `displacement` and the `[vertex]` file also draw the shadow map, which gets
no kept resources, so the check refuses them there. On a frame that clears a resource the terrain reads zeros, or
what a `[[before_world]]` pass wrote since.

`[entity] reads` and `[sky] reads` work the same way, so mobs, block entities and the sky can use the light the
terrain gets. The entities and the sky draw after `[[before_world]]` and before `[[post]]`, as the terrain does, and
read the same versions. Only their fragments read them: the shadow map's entities are Horizon's own draw, with no
kept resources.

```toml
[[before_world]]
file = "light_cache.wgsl"
dispatch = [65536, 1, 1]
workgroup = [64, 1, 1]
writes = ["cache"]

[material]
file = "material.wgsl"
reads = ["cache", "trail_previous"]

[entity]
file = "entity.wgsl"
reads = ["cache"]
```

## Options

A picked pack with options gets a Shader Options... button at the top of the Shader Packs page. Float and int options
are sliders that take the nearest `step` (an int's whole numbers), and the arrow keys move a focused one a step at a
time; bool and choice options are buttons, where a click picks the next value and a right click the one before.
Shift-click puts either back to its default, and Reset all of them; hovering one shows its `description`. Each change
is saved to `shaderpacks/<pack>.txt` (`id=value` lines, values at their defaults left out), a slider's when it is
let go, and the pack reloads with it within half a second.

The page shows every option two a row, unless the pack lays them out in `[[pages]]`: it opens on the first page, and an
item `"page:<id>"` is a button opening another, so options can be grouped into categories. `""` leaves a slot empty, and
`columns = 1` gives a page full-width buttons:

```toml
[[pages]]
id = "main"
name = "My Pack"
items = ["page:lighting", "page:water"]

[[pages]]
id = "lighting"
name = "Lighting"
description = "Shadows and the light of blocks."   # the tooltip of the button opening it
items = ["shadow_softness", "block_light"]
```

Every page has to be reached from the first and every option has to be on a page, or the check refuses the pack.

Each `[[options]]` entry is a WGSL `override` of the same name, set when the game builds the pipeline: no text
substitution, no recompiling a different program per value.

```wgsl
override saturation: f32 = 1.15;   // type = "float"; bool → bool, int → i32, choice → u32 (the value's index)
```

The game shows the options on the pack's settings screen. Branches on an option are on a constant, so the GPU
skips the side that isn't taken.

The shadow map is most of what a pack with `[shadow]` costs: each frame the terrain in the light's square is drawn again.
Options can size it, so players pick their own quality. While `option` is off there is no map and no shadow pass
(`frame.has_shadow` reads 0); `resolution_option` and `distance_option` name an `int` option, or a `choice` whose values
are numbers, whose value replaces `resolution` or `distance`, checked against their ranges. Changing one rebuilds the map
at the new size. These two need no `override` in your WGSL: the frame has the map's size.

```toml
[shadow]
option = "shadows"                        # a bool: no shadow pass while it is off
resolution_option = "shadow_resolution"

[[options]]
id = "shadow_resolution"
name = "Shadow resolution"
type = "choice"
values = ["1024", "2048", "4096"]
default = "2048"
```

## What the check does

The game runs the same check when it loads a pack (a pack that fails is refused with the message, and the last good
one keeps drawing), the launcher before it installs one, and the registry's CI before a pack is listed:

1. The manifest and the package: known keys, valid ids, every file used, sizes.
2. Each stage built as the renderer builds it and validated by naga.
3. The stage function's signature, and the rules above.
4. Each `override` matches its option's type (or has a default); each option is used (those sizing the shadow map
   may be by `[shadow]` alone).
5. Budgets: 20 000 expressions and 64 texture reads per stage.
6. Every entry point translated for Vulkan (SPIR-V), Metal and DirectX 12 (HLSL), with the options at their
   defaults, minimums and maximums.

`[budget] gpu_ms` is the GPU time your pack aims to add to a frame. To compare, open F3 in the game: while it is
open, each pass is timed on the GPU and the overlay shows the pack's total and its costliest passes, by their `name`
(the median of the last 15 timed frames). Timing waits for nothing, so it does not slow the game. In a timed frame the sky
stage draws in a pass of its own (it shares the world's pass otherwise), so its time includes clearing the picture. The
material stage runs inside terrain's own draws, so it has no time of its own: compare the frame's GPU time with and
without the pack.

With F3 shut, offscreen or from a script, `horizon-ctl gpu-passes on` times the same passes: `horizon-ctl bench 5`
then replies with `shader_passes`, the pack's passes by the names F3 shows, beside `gpu_passes`, Horizon's own, and
with `gpu`, the whole frame's percentiles (`gpu_ms`, every frame, with `bench 5 raw`; `gpu-passes off` stops it).
`horizon-client --benchmark` records them as `shader_pass.<scene>.<pass>_ms`, and `horizon-ctl profile client start
--gpu` into a capture (`horizon-perf query gpu`).

## Next

An overlay showing what each pass draws (F3 already shows what each costs), and items, particles and the
first-person hand through a pack (the entity stage lights entities and block entities so far).
