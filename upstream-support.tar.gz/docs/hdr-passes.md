# HDR: what a render pass keeps

Read this before adding or changing anything that reads, filters or redraws the world's picture: upscaling (FSR,
DLSS in a native mod), anti-aliasing and TAA, sharpening, frame generation, post effects and screen-space effects,
and anything that captures the picture (screenshots, recordings, streams). With HDR the frame holds light above
white, and a pass written for SDR alone breaks it, mostly without any test failing. HDR's work is tracked in
[#12989](https://github.com/horizon-rust/horizon/issues/12989); the design behind it is
[design/hdr-linear-light.md](design/hdr-linear-light.md), and what players see is in [graphics.md](graphics.md).

## The frame

| | Frame | Holds |
| --- | --- | --- |
| Under a 0.2 pack, or with HDR on and no pack | `Rgba16Float` | light: 1.0 is paper white, more is brighter |
| Otherwise: HDR off, or under a `shaders/` pack | the swapchain's 8-bit format | vanilla's picture or the pack's, clipped at 1 |

HDR is on only where the device draws the float frame and keeps the HUD on a layer of its own; elsewhere the HDR
page says so and the picture is SDR's. Under a `shaders/` pack HDR output shows the pack's 8-bit picture at paper
white, the HUD with it.

On the float frame Horizon's own light reaches several times paper white, the sun the most, and a shader pack of
API 0.2 may write any value half float holds. It's stored in vanilla's gamma (the 2.2 power), as the other frames are.
A 0.2 pack's `[frame] blend = "linear"` stores linear light instead ([shaders.md](api/shaders.md)), so a pass
doesn't hard-code the gamma.

## Where a pass goes

Each frame without a shader pack (`Renderer::render` in `gfx.rs`), in order:

1. The world.
2. `world_post` (`gfx/world_post.rs`): resolution scale, FXAA or TAA, sharpening. An upscaler goes here.
3. Post effects: vanilla's post chains, entity outlines.
4. The tone curve (`Hdr::tonemap` in `gfx/hdr.rs`; the curve itself is `hdr_tone_scale` in `hdr_look.wgsl`): the
   light eases into the display's peak.
5. Camera overlays: vignette, pumpkin, powder snow, portal, nausea.
6. The HUD and menus, on an 8-bit layer of their own, with how much of the world they cover.
7. HDR output's last pass (`hdr.wgsl`): the HUD over the world, encoded for the display (PQ or scRGB). The HDR10
   swapchain's 10 bits get dither there, noise of one code fixed to the pixel, so slow gradients such as a clear sky
   don't band; a capture's HDR10 copy (the `-hdr.png`) keeps the exact codes.

Under a shader pack its post passes take step 2's place. A 0.2 pack's `[tonemap]` runs at their end and takes step
4's, so the post effects after it get a tone-mapped picture.
A 0.2 pack without `[[post]]` whose frame holds gamma light (not `blend = "linear"` on the float frame) keeps step
2's FXAA or TAA (their blends are made for gamma light, rule 3). TAA upscales and sharpens as without a pack where the
pack's `[tonemap]`, if it has one, never reads `previous` (`Capabilities::engine_upscale`); elsewhere it runs at the
world's size, its upscaling and sharpening off. `world_post` resolves the world in the frame's encoding, FXAA onto a
target of the world's size and TAA into its history, which it sharpens onto a target of the history's size where it
upscales, and the pack's output decodes that in the world's place (`WorldOutput::resolved`), before the `[tonemap]`.
Under any other pack TAA is off.

A pass on the world's light belongs in steps 2 and 3, before the tone curve, and never sees the HUD. After the tone
curve the frame is what the display will show, so no pass there treats it as light. Frame generation interpolates
the world's light without the hand and the HUD, on the float frame only, and its made frame goes through the tone
curve, the HUD's layer and the last pass as the real one does.

## Rules

1. **Keep light above 1.** No `saturate`, `clamp(c, 0, 1)` or `min(c, 1)` on a colour, and no unorm target in
   between: what a pass keeps (history, mips, pyramids) is a float format, as TAA's `Rgba16Float` history is.
   Clipping cuts the sun and every light source off at paper white.
2. **Don't assume a top of 1.** Limits written for 0..1 misbehave above it: scale by the pixels' own range
   instead. One such limit stays on purpose. The sharpening in `world_post.wgsl` (`2.0 - hi`) eases off above 1 and
   stops at 2, so light far above paper white is left unsharpened. Sharpening the sun's edge as the rest multiplies
   a temporal upscaler's frame-to-frame differences there: under Performance upscaling its flicker rose from about
   10 to 18 PQ code values, for 1 to 6% more detail inside lit textures.
3. **Blend linear light tone-weighted, gamma light as stored.** What counts is the encoding of the values a pass
   accumulates, not the frame's format. Linear light is what a 0.2 pack's post passes read (`color`, `previous`,
   kept resources, under either `[frame] blend`) and what the world's frame holds under `blend = "linear"`. There TAA, a
   temporal upscaler and anything else that keeps a history blends `c / (1 + m)`, where `m` is the largest of `c`'s
   channels, clamps the history in that space too, and turns the result back with `c / (1 - m)`. Raw linear light
   lets a few very bright pixels win the history: torches and the sun's edge sparkle, and smear when the camera
   moves. Horizon's own TAA on the default frame accumulates vanilla's gamma, and blends it as stored: weighted on
   top of the gamma, the sun scene's largest per-pixel standard deviation rose from 11 to 27 PQ code values (40
   still captures at native resolution).
4. **Follow a library's colour contract.** Temporal upscalers such as FSR 2 and 3 and DLSS take HDR input as
   linear light: tell them it's HDR, give them 1.0 at paper white (exposure 1), and on a gamma frame decode the 2.2
   power before and encode it again after. Any other library goes where its documentation says its input must come from, and keeps
   these rules.
5. **Write no NaN, infinity or negative values.** Half float's largest value is 65504, and a history keeps a NaN
   and spreads it.
6. **Drop history when the frame changes.** Its format and encoding change with HDR and the shader pack, and
   blending across the change mixes two meanings.
7. **Captures map the picture.** A screenshot, recording or stream takes the world through HDR's mapping to SDR, as
   `Hdr::sdr_screenshot` does, or as HDR10, as the `-hdr.png` does; never the frame's values as they are.

## Checking a pass

- **HDR off stays byte-identical** unless the pass means to change it:
  `python3 tools/test_frame_identity_parity.py --base origin/main`, and the `frame-identity` label
  ([release-flow.md](release-flow.md)). It also draws the float frame with HDR on, and holds it to SDR.
- **Its sessions run with anti-aliasing and frame generation off,** as by default: TAA and frame generation build
  on earlier frames, which `HORIZON_STILL` doesn't repeat. Check a temporal pass by hand: offscreen with HDR on
  (`hdr:true` in `horizon-graphics.txt`) and `HORIZON_HDR_OUTPUT=pq`, with the camera moving over torches, lava and
  the sun.
- **The `-hdr.png` beside an HDR screenshot** (F2, or `horizon-ctl screenshot`) keeps the whole picture, and its
  `cLLI` chunk gives its brightest pixel in nits. With the sun in view offscreen it is near the peak, 1000 nits; a
  pass that clips brings it down to paper white, 203.
- **Mention #12989 in the pull request**, so HDR's side gets reviewed.
