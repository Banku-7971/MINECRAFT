# Release flow

How a change gets from a pull request to players: the checks a pull request passes, how it merges, and the
automatic releases that follow. Releases are automatic and frequent so the latest Horizon is always playable.
Since 2026-10-28 Horizon ships only the **Nightly** (Ludovic's decision; the Team proposed it): the batch train builds
a Nightly instead of a `vX.Y.Z` release, it is published once its smoke test passed and no `release-blocker` is open,
and every launcher and `horizon-server update` install it ([Nightly only](#nightly-only)).

## Pull request checks

The `checks` workflow (`.github/workflows/ci.yml`) runs two jobs on every pull request (opened, pushed to or
reopened; labels never start it):

| Job | Runs on | What | Time |
| --- | --- | --- | --- |
| `verify` | Blacksmith's runners for every pull request (approved forks' included), the merge queue and main's pushes. `SELF_HOSTED_CI=all` sends this repository's own to our checks runners (label `horizon-checks`, the CI VPS's); forks' pull requests see no repository variable, so no switch moves them ([CI runners](ci-runners.md)) | One job per part, side by side: the public-tree check and the Python tests (`verify (tree and Python tests)`), rustfmt and clippy with warnings denied (`verify (format and lint)`), clippy of the server build (`verify (server build lint)`), the launcher's checks (`verify (launcher)`) and the Rust tests (`verify (Rust tests)`); `verify` waits for them and passes when each passed or had nothing to do. Each Rust part keeps its build folder between runs (a sticky disk on Blacksmith's, the runner's own on ours) | ~8 min |
| `parity / parity` | A runner with the label `horizon-game`: the Mac mini's and playhorizon's (below) | Only for a change to a harness, an oracle, a probe or the runner (or the `run-parity` label): the vanilla harnesses the change can affect (`tools/parity.py --changed <base>`). Other pull requests skip it: [parity-main](#parity-on-main) checks them on main | seconds when nothing is affected; minutes per affected harness |

Pushes to main run `verify` only; the nightly audit covers main's harnesses.

`verify` is the check main requires, so it has no condition and runs in every run of `checks`: GitHub counts a
*skipped* required check as passed, and labels used to start runs whose `verify` was skipped, which let
auto-merge merge before the real `verify` finished. A pull request that changes no Rust (docs, tools) runs only its
quick steps and finishes in about a minute. A pull request's public-tree check reads only
its own commits (`--range base..head`); a push to main that the merge queue didn't verify reads the whole history
reachable from `HEAD` (`--history`), on a full clone, since reading old blobs through a partial clone takes over 30
minutes.

### The parity job

The job is `.github/workflows/parity.yml`, a reusable workflow: `checks` calls it for pull requests from this
repository, `run-parity.yml` for a fork's pull request a maintainer labels `run-parity`.

A pull request every harness reaches (a crate split moves files every probe links: #2160 ran all 352 harnesses, 71
minutes on a Mac mini runner, while five other pull requests' jobs queued behind it) carries the `full-parity` label:
its job runs on playhorizon's runner only (4 harnesses at a time), and waits for it while that runner is busy
instead of taking the Mac mini's. Labels don't start `checks`: add it when opening the pull request
(`gh pr create --label full-parity`), or before the next push.

A pull request that must leave the picture alone (HDR, shader packs) carries the `frame-identity` label: its job also
runs `frame_identity` ([parity-workflow.md](parity-workflow.md)), which no automatic selection picks, since it fails
any change that moves the picture on purpose. Like `full-parity`, it is read when the job starts.

Horizon never downloads the game, so harnesses that compare with vanilla run only where the maintainer's own
copy is: the Mac mini and playhorizon (below). Their runners run as the maintainer's account and keep their checkout
between runs (`clean: false`), so the probes build incrementally into `.local/parity-target` and earlier passes
stand.

The job tests the pull request's head merged into main's current tip, which is what merging it would land: harness
and game fixes that reached main after the branch was made apply to it too, and an old branch runs main's runner
scripts and selection unless it changes them. The base for the selection is that main commit, so only the pull
request's own changes count. The job summary names the main commit. A head that conflicts with main is tested
alone, with a warning. The check is still reported on the head.

1. `tools/ci/runner-env.sh` puts the machine's Python 3.13 and the JDK `research-lock.json` pins on the PATH
   (Homebrew and `java_home` on the Mac; on Linux what `linux-runner.sh` pinned, else nixpkgs), and sccache when
   the machine has it.
2. `tools/ci/vanilla-data.sh` links `.local/` to the runner's copy of the vanilla data, cloned once from
   `~/code/horizon-parity/shared-local` into `~/.actions-runners/horizon/_work/horizon/shared-local`, and
   prepares `.local/horizon-client` with the pull request's own `horizon-prepare` once per preparer version
   (its sources, the exporters in `mods/horizon/src/test/java` and `research-lock.json`). The game's sounds, which
   depend only on the Minecraft version, are kept once in `shared-local/sounds/<version>/` (copied from a folder
   `horizon-prepare sounds` made from the maintainer's own game; the Mac mini has no official launcher of its own)
   and cloned into each preparation (not linked: vanilla's packs refuse symbolic links), for the audio harnesses.
   `tools/prepare_output.py check` then compares what was prepared with `crates/horizon-prepare/output-versions.txt`:
   launchers keep a player's prepared resources across releases whose preparer declares the same `OUTPUT_VERSION`
   (`crates/horizon-prepare/src/lib.rs`), so a change to the prepared files fails here until it bumps the number
   and appends the new digest (the error gives both lines).
3. `tools/parity.py --changed <base sha>` picks the harnesses whose traced dependencies (their script, Python
   modules, Java oracles and every Rust source their probes compile) changed since the merge base, plus any
   harness nothing is recorded about yet, and runs those that have no pass for their current inputs. A change to
   `Cargo.lock` or `research-lock.json` affects every harness. Each harness has 25 minutes, the job 45.

Failed harnesses' logs are uploaded as the `parity-logs` artifact.

**Hosted parity.** A maintainer can also run harnesses on Blacksmith's runners, away from the Mac mini:
`gh workflow run parity-hosted.yml --ref <branch> -f harnesses="..."`, or `-f base=<commit>` for what the branch's
changes reach. The data comes encrypted from the maintainers' private `horizon-rust/vanilla-data`. The only thing
that leaves the runner is the harness logs: the first-attempt and failure logs, holding compared values, log tails and
names, as this job's public logs already do ([ci-runners.md](ci-runners.md#hosted-parity)). Its result is advisory;
this job is still the check.

**Platform-specific harnesses.** A harness listed under `linux_only` in `tools/parity_hosts.json` gives
different results on macOS for a reason that is not a Horizon bug (the reason is printed). `parity.py` skips it on
other platforms unless it is named on the command line. Today it holds only `save_roundtrip` (it needs `vscreen`):
`options`, `chunk_generation`, `world_border_render` and `mob_ai`, which once differed on macOS through the
platform's libm, pass on the Mac mini since `horizon_core::jmath` computes what HotSpot computes (checked
2026-10-14).

**Pull requests from forks** never run code on the Mac mini by themselves. A maintainer who has read the change
adds the `run-parity` label: that runs the job once, on the commit the pull request had then. To run it again
after new pushes, remove the label and add it again.

**Two runners.** The Mac mini has two runners for this repository, `ludovics-mac-mini`
(`~/.actions-runners/horizon`, `CARGO_BUILD_JOBS=10`) and `ludovics-mac-mini-2` (`~/.actions-runners/horizon-2`,
`CARGO_BUILD_JOBS=6`), with the same labels, so the 30-minute nightly audit or a long parity job never holds a
release's macOS build back. Each keeps its own checkout, `target/` and Rust install; the second's
`_work/horizon/shared-local` links to the first's, so they share the vanilla data, the preparations (one at a
time, under a lock) and the parity passes and slots.

**playhorizon's runner.** `playhorizon-horizon` runs on a server a hosting partner lends the project (Ubuntu, 8
AMD EPYC threads, 30 GB, in Detroit; reachable only through the maintainer's tailnet). Nobody sits at it, so the
watcher never pauses it except by hand. It gets half the machine: `RUNNER_MEMORY=24`, `CARGO_BUILD_JOBS` and the
harness slots at 4, and a drop-in (`~/.config/systemd/user/horizon-runner.service.d/cpus.conf`) that starts it under
`taskset -c 4-7` (the user slice can't set `AllowedCPUs`: systemd doesn't delegate the cpuset controller to it).
Agents' `tools/remote.sh` runs and benchmarks share CPUs 0-3, so they never slow a pull request's job.
Without Nix, `linux-runner.sh` takes the build libraries, the JDK, sccache, Xvfb and Mesa's software Vulkan
(lavapipe; there is no GPU) from apt, and Python 3.13 from uv. The partner can reach the machine, so gh is not
logged in there: the registration token comes from another machine (`RUNNER_TOKEN`), and no job with secrets may
run there (parity has none). It is also a parity host (`playhorizon` in `tools/parity_hosts.json`, 3 jobs on CPUs 0-3). Since
2026-10-26 it has the `horizon-game` label: pull requests' parity jobs run there or on the Mac mini, and
`full-parity` ones only there.

## Merging

Pull requests go through the merge queue, which squashes each one into a single commit titled with the pull
request's title and number (`kind(area): what changes (#123)`); never `gh pr merge --auto`. Branch protection on main
requires `verify` for everyone, and a council member's review (team `council`) for the files `.github/CODEOWNERS` lists (what builds, signs
and ships releases). Branches don't have to be up to date with main: main's own `checks` run catches the rare
semantic conflict.

**Who merges.** The Horizon Team (GitHub team `horizon-team`: kacpherek, levzzz5154, rdbtCVS, Online5277, dezer-x,
NikitaMGrimm) and Ludovic. The orchestrator's agents prove only the risky pull requests (below), so a contributor's
ordinary pull request doesn't wait for them.

**An ordinary pull request merges on CI.** A Team member:

1. reads the whole diff (for a fork, before adding `run-parity`: that runs the fork's code on a maintainer's machine);
2. adds `run-parity` to a fork's pull request; our own branches run `parity` by themselves. Since #2448 it tests
   the pull request merged into main;
3. merges once `verify` and `parity` pass, nobody's change request is open, and every comment has been read (a
   "don't merge" from anyone holds it).

Never merge your own pull request: another Team member reviews and merges it. Never push to, force-push or rebase a
contributor's branch.

**A risky pull request gets the `needs-proof` label** and waits for an agent's local proof (both single-player
paths, `lan_e2e`, a screenshot for anything visible) before it merges. Risky means any of:

- it changes what is saved or loaded (`save.rs`, `entity_nbt.rs`, `block_entity_nbt.rs`, `region.rs`, `datafix/`):
  a bug there damages players' worlds;
- the network or the server thread: `horizon-protocol`, `net.rs`, `remote*.rs`, `lan/`, `lan*.rs`,
  `integrated.rs`, `levels.rs`, `dedicated*`;
- world generation (`worldgen/`): seeds must keep generating the same terrain;
- the launcher's installs and updates, or the mod runtime;
- the harnesses themselves (`tools/test_*_parity.py`, the Java oracles): a wrong harness hides regressions;
- over ~3000 lines of code ([what counts](../CONTRIBUTING.md#pull-requests)), or `parity` failed, was skipped or ran no harness for gameplay code.

Unsure? Add `needs-proof`: it costs a few hours, a broken release costs more.

`parity` becomes required once it has run green on pull requests for a while (a week without a false failure):

```sh
gh api -X POST repos/horizon-rust/horizon/branches/main/protection/required_status_checks/contexts -f 'contexts[]=parity / parity'
```

A skipped `parity` (a fork's pull request without the label) counts as passed, so requiring it never blocks a
fork's pull request: the Team member decides whether to run it, and a skipped run makes the pull request risky.

## Parity on main

Most pull requests merge on `verify` alone and leave the vanilla harnesses to `.github/workflows/parity-main.yml`,
which runs them on main a batch of merges at a time, on the Mac mini's runner:

- It starts on every push to main, one run at a time (`concurrency: parity-main`). A run that started always
  finishes; merges that land while it goes on wait in one pending run: GitHub keeps only the newest and cancels the
  others, so the next run takes them all. The many `cancelled` runs in the list are those pending ones.
- `tools/parity_main.py base` gives the newest commit main contains whose parity-main passed (else the last
  merge's parent), and the run is `tools/parity.py --changed <that commit>`: the union of the harnesses every merge
  since then can affect, once, with every earlier pass reused.
- On a failure, `tools/parity_main.py verdict` decides the run, as before: the failed harnesses (known failing
  ones aside) run again at HEAD on the same build, and the run passes only when they all pass then (a flake, counted
  as a pass). It reads only the list this run's `tools/parity.py` recorded (`PARITY_RUN_ID`, the run id and attempt):
  a batch that stopped before recording one fails the run instead of judging an earlier run's list. The step has
  50 minutes, so a hung rerun ends red. The search for the merge that broke a harness is no longer part of the run:
  it held the only gate runner for up to an hour. Run it by hand on a machine whose
  `.local/parity-runner/last-run.json` holds the failed harnesses (`python3 tools/parity.py <them>` on the run's
  commit writes it; the verdict report lists them): `python3 tools/parity_main.py bisect <base> [--comment]` reruns
  them at HEAD as the gate did, then checks out the batch's first-parent merges by halves, names the first merge they
  fail on and, with `--comment`, comments on its pull request. It has 90 minutes (`--budget`), then says between
  which merges each harness broke; a later search from the same base goes on from there
  (`.local/parity-runner/bisect.json`).
- Jobs on the self-hosted Mac take turns at compiling (`tools/compile_lock.py`, flock on files in
  `/Users/Shared/horizon-compile-lock`): parity-main's probe prebuild, pull requests' parity prebuilds and the
  Nightly's, releases' and the launcher's Mac compiles. A pull request's job is not given the turn while parity-main
  or a Mac build is waiting or compiling; those wait only for the turn's holder, and a pull request's prebuild that
  holds it gives it back after its current Cargo run. A holder that dies frees the turn at
  once (the kernel drops its lock). Waits are bounded (parity-main 20 min and the Mac builds 60, each for all its
  compiles together; pull requests 60 per prebuild), then the job compiles anyway and says who held the turn. parity-main's prebuild then has 240 minutes (`PREBUILD_LIMIT`),
  past which its Cargo process group is stopped and the run fails.
- The verdict report, `verdict-<run id>-<attempt>.json` (the run's `parity-main-verdict` artifact, uploaded best
  effort), holds the head, the base, the run id and attempt, the exit code, each failed harness's tries (the batch's,
  its retry if `tools/parity.py` gave one, the rerun at HEAD) and `repeat_flakers`: harnesses not on `known_flaky`
  that passed only when run again in 3 or more of the last 10 runs (kept in
  `.local/parity-runner/verdict-history.json` on the runner). The run's summary names each; they don't fail it: put
  one on `known_flaky` with its issue, or fix it. Neither the report nor the history can change the verdict.
- The `parity-main-prebuild-timings` artifact (7 days, best effort) tells which crates take the probe prebuild's
  minutes: Cargo's `--timings` report of each prebuild run (`cargo-NN.html`, the largest left out above 20 MB in
  all) and `prebuild-calls.txt`, each run's `cargo N/M` line with the change in the machine's sccache hits and
  misses since the reading before it. Only parity-main
  collects them (`HORIZON_PARITY_PREBUILD_TIMINGS=1` on its harness step).
- Nightlies build only on a commit both `checks` and `parity-main` passed on (`tools/release_train.py`,
  `tools/ci/nightly.py`, see below), so a broken merge holds them instead of reaching players. They take the
  newest such commit even when a later batch failed: that failure is in merges the green commit doesn't contain, so
  a broken or flaky harness holds only what landed after the last green run, never the whole Nightly (before
  2026-11-03, any later failure held every Nightly until a run passed again: 30 h without one). `release.yml`
  also starts when a parity-main run finishes. A forced run (`force=true`) doesn't wait for parity-main.
- A harness that keeps failing on main while its issue is open goes on `known_failing` in
  `tools/parity_hosts.json` ([parity-workflow.md](parity-workflow.md)): it still runs and reports, but no longer
  fails parity-main, so main's last green commit moves on and later merges are checked and bisected on their own.
  From 2026-11-15 to 11-17 one batch of regressions kept every run red and no Nightly could ship. Harnesses whose
  difference harms players (crashes, saves, multiplayer) stay off the list: they hold the Nightly until fixed.

A pull request still runs its own parity job when it changes a harness script, an oracle
(`mods/horizon/src/test/`), a probe (`crates/*/examples/`, `game/*_fixture.rs`, `game/*_harness.rs`), the runner
(`tools/parity*.py`, `tools/lab.py`, `tools/parity_hosts.json`, `parity*.yml`), or carries the `run-parity` label
(`run-parity.yml` runs it when the label is added).

## Game releases

`.github/workflows/release.yml` is the batch train: it decides when a new Nightly goes out and starts
`nightly build` (`.github/workflows/nightly-build.yml`, [Nightly channel](#nightly-channel)) on the commit it
decided, which builds, signs and publishes it. It starts after every green `checks` or `parity-main` run of a push to
main, every 10 minutes (so a batch waiting for merges to settle goes out without another merge), and by hand.

The Nightly is built and published by `nightly build` alone, with the mod SDK of its commit ([Mod SDK](#mod-sdk)).

```mermaid
flowchart LR
    pr(["pull request"]) --> checks{"verify<br/>parity"}
    checks -- green --> merge["merge queue<br/>(squash)"]
    merge --> main(["main"])
    main --> mainchecks{"checks and<br/>parity-main"}
    mainchecks -- green --> decide{"decide<br/>tools/release_train.py"}
    cron(["every 10 minutes"]) --> decide
    decide -- "5 player-facing PRs settled 5 min,<br/>the oldest waited 6 h, or release-now" --> nightly["nightly build:<br/>that commit + the reviewers' picks"]
    decide -- otherwise --> wait(["wait"])
    nightly --> gate{"smoke test drew a world,<br/>no release-blocker is open"}
    gate -- no --> nothing(["nothing is published"])
    gate -- yes --> publish["publish the nightly pre-release<br/>notes: what merged since the last one"]
    publish --> launcher(["every launcher and server installs it"])
    publish --> kira(["Kira posts it; the first after<br/>20:00 UTC pings, once a day"])
```

### Mod SDK

The mod SDK of a Nightly is built inside `nightly build`, for the exact main commit `pick` chose:

1. `sdk` builds the commit's prebuilt SDK on hosted runners (`prebuilt-game-build.yml`), next to the game's build.
   All four legs must pass: Linux client and server, Windows GNU client and macOS ARM64 client. Each builds two
   native starter mods against the SDK alone, starts their installed executable, and checks Windows export capacity.
   A live run can reuse an existing SDK only after its complete inventory and signed index are authenticated.
   Each leg logs its runner's cores and memory. On a dry run only (`dry_run`, which sets `HORIZON_SDK_TIMINGS`), it
   also uploads `sdk-timings-<leg>` (3 days), the `cargo rustc --timings` report of its SDK build, apart from the
   SDK's own artifact: cargo fails a build that can't write the report, so a published SDK's build never makes one. The surface export reuses the `horizon-stage` that
   staging built (`target/prebuilt/tools`).
2. After the game build (including its smoke test), `sdk-publish.yml` gathers identical build data and surfaces,
   builds the generated API source, writes `sdk.json`, and checks every slice's commit, host, side, compiler,
   checksums and exact carried registry patches. Publication requires successful `checks` and `parity-main` push
   runs on that exact main SHA, no open `release-blocker`, and `RELEASES_PAUSED` unset.
3. Only the signing job uses the existing protected, main-only `release` environment. It checks out only the
   signing script from the caller's trusted workflow revision, checks main ancestry again, and hashes the assets
   without running them. The SDK signature names `sdk-<sha>`, not a game tag. No unsigned SDK is accepted.
   Builders and index jobs have no signing/write credentials and use no shared build caches.
4. A read-only verification job checks the signature and exact asset set, including dry runs. Only a live main
   publication starts the separate write-authorized job, which rechecks the exact-main gates and creates the
   immutable prerelease `sdk-<sha>` (never latest). It never overwrites an existing exact-build SDK.
   `sdk-index` copies its authenticated `sdk.json` into both Nightly signatures and the Nightly release; publication
   checks `require-sdk` again before rotation and before creating the Nightly.

`prebuilt-game.yml` is the same SDK build/publication route by hand. It defaults to a full dry run; branch runs are
always dry. Dry runs rebuild all four legs, use a throwaway signing key, and publish no SDK tag or release. Nightly
dry runs consume that run's validated index without requiring a published SDK, and run beside a real Nightly in a
concurrency group of their own ([When it releases](#when-it-releases)).

```sh
gh workflow run prebuilt-game.yml --ref main                         # full dry run
gh workflow run nightly-build.yml --ref main -f dry_run=true         # SDK + game dry run
gh workflow run prebuilt-game.yml --ref main -f dry_run=false         # maintainer publication, after review/CI
gh workflow run prebuilt-game.yml --ref main -f off_main=true -f commit=<full sha>   # dry run of a dry-run/* commit
```

Its `commit` gets the Nightly's base rule (its dry run off main, under
[Trusted reviewers pick the Nightly's pull requests](#trusted-reviewers-pick-the-nightlys-pull-requests): `nightly.py
base`, run from this workflow's own commit, checked out beside the judged one and never inside it): on main, or, in a
dry run with `off_main` only, a commit a
freshly fetched `dry-run/*` branch holds. A pull request's head, another branch's commit or a bare SHA is refused, a
dry run's too, and so is `off_main` with a commit on main or in a real run; the run's name says `(off main)`. A
branch run's own commit, off main, needs the same: a `dry-run/*` branch holding it and `off_main`. The
dry run runs the commit's own build scripts in jobs whose GitHub Actions cache scope is main's when dispatched from
main, which is why the commit must be one somebody with push rights chose. No job on the route saves a cache: no
`actions/cache`, Rust cache, sticky disk or compiler cache (tests/test_nightly.py pins it).

These are publication machinery, not evidence that a candidate has shipped. Activate a candidate only after
code-owner review, green exact-head CI and the real platform/native canaries. A Nightly predating this route may
have no SDK; consumers must report that rather than rebuilding the game per mod.

The game workflow also builds `horizon-wasm-std.wasm` once with the pinned Rust toolchain, `rust-src` and
`wasm32-unknown-unknown`, without credentials or shared caches. Every client archive (including musl) and the Linux
server archive take that same member beside the executable through xtask's required-input preflight.
The dedicated executable is built from `horizon-game --no-default-features --bin horizon-client`.

For `[[native.mixin]]`, delivery currently uses the existing pinned-source tool build when no matching prebuilt
exists. Building that small tool once per pin/patch/platform does not rebuild any game crate. The former unsigned
`prebuilt-mixins-tool.yml` publication route is not restored; checksums and identity alone are not release signatures.
The launcher still supports matching existing prebuilts and the explicit `native-build --mixins-from-source` canary.

For the candidate's native canaries, `SDK_BASE` must hold exactly one complete `sdk-<candidate SHA>` folder and
`LAUNCHER` must be the matching launcher for the machine running the command. Use a fresh `SCRATCH` parent;
the script creates isolated game/launcher/XDG homes and checks that the prebuilt game library's hash is unchanged.
Dry-run SDKs additionally require a debug-assertions launcher with `HORIZON_SDK_TRUSTED_KEY` set to that run's
throwaway public key; never pass production private signing material.

```sh
# Linux x86-64: runtime proof with prepared read-only RESOURCES, plus client build/link proof.
FNR_SIDE=server FNR_TARGET=x86_64-unknown-linux-gnu FNR_MIXINS_FROM_SOURCE=1 \
  tools/ci/fn_replace_check.sh "$LAUNCHER" "$SDK_BASE" "$SCRATCH/linux-server" "$RESOURCES"
FNR_SIDE=client FNR_TARGET=x86_64-unknown-linux-gnu FNR_MIXINS_FROM_SOURCE=1 \
  tools/ci/fn_replace_check.sh "$LAUNCHER" "$SDK_BASE" "$SCRATCH/linux-client"
# On Windows x86-64 (Git Bash), then on macOS ARM64:
FNR_SIDE=client FNR_TARGET=x86_64-pc-windows-gnu FNR_MIXINS_FROM_SOURCE=1 \
  tools/ci/fn_replace_check.sh "$LAUNCHER" "$SDK_BASE" "$SCRATCH/windows-client"
FNR_SIDE=client FNR_TARGET=aarch64-apple-darwin FNR_MIXINS_FROM_SOURCE=1 \
  tools/ci/fn_replace_check.sh "$LAUNCHER" "$SDK_BASE" "$SCRATCH/macos-client"
```

The SDK producer's four hosted legs must also complete `prebuilt_game.py build`, `smoke`, `start`, `exports`
and `pack` on their real hosts. A local source check does not substitute for these platform results.

### Tests outside the checks

There is no daily run: `daily.yml` and the workflows it called (`ignored-tests.yml`, `wasm-mods.yml`,
`fn-replace-check.yml`, `native-dylib-probe.yml`, `launcher-windows-check.yml`), and `hot-paths.yml`,
`paper-parity.yml` and `wasm-coverage.yml`, are gone from main. The workflows that run Rust tests now:

| Workflow (job) | When | What it tests |
|---|---|---|
| `ci.yml` (`verify (Rust tests)`) | A pull request that `tools/ci/rust_changes.py` selects (any change except `docs/`, Markdown, and Python under `tools/` and `tests/`; `rust_changes.py` and `release_train.py` themselves count); every merge-queue entry, manual dispatch and push to main (a push only builds when a merge-queue run already passed on its commit) | On Linux: the workspace's unit, binary, integration and doc tests, and the `#[ignore]`d `mod_content::tests::` (they pass at once without the vanilla data, which no GitHub runner holds) |
| `ci.yml` (`verify (launcher)`) | A pull request or push to main that `rust_changes.py --launcher` selects, or whose earlier commit can't be read; every manual dispatch. Never in the merge queue (the job's condition), and a push to main only builds when a merge-queue run already passed on its commit | On Linux: the launcher's library and binary tests |
| `ci.yml` (`verify (mod API)`) | A pull request that `rust_changes.py` selects for the mod API (see `needs_mod_api`: crate manifests count, for example); every merge-queue entry, manual dispatch and push to main | On Linux, pull requests only: the generated mod API against the base (`tools/check_mod_api_unchanged.py`) and the surface report |
| `ci.yml` (`Windows ARM64 game and launcher`) | Manual dispatch with `-f arm64=true` only | The launcher's library tests and the `#[ignore]`d `rust_toolchain::tests::managed_arm64_toolchain_builds_the_game` |
| `ci.yml` (`Windows x64 game and launcher tests`) | Manual dispatch with `-f windows=true` only, a [try run](ci-runners.md#try-runs) | On Windows x64: the launcher's tests; the game's release build, uploaded for 3 days |
| `launcher.yml` (`build`) | See the workflow's `on:` (pushes to `main`, `launcher` and `launcher-*` within its path filter, a schedule, manual dispatch) and its `decide` job: it builds when a launcher release is due, and on every dry run (every run off main, and a dispatch with `dry_run`, the default), which publishes nothing | The launcher's tests on Linux, macOS (two builds, one for x86-64) and Windows (x64, ARM64) |
| `game-build.yml`, from `nightly-build.yml` | Each Nightly build | On Windows x64, in release, in its own job (`polytone windows`) beside the Windows build, which `sign` and `publish` wait for as for the builds: `horizon-client-render`'s `particles::polytone::tests::` |
| `perf-wasm.yml` | Pull requests and pushes to main that change `crates/horizon-perf/`, `crates/horizon-perf-format/`, `crates/horizon-bench/`, `xtask/`, `Cargo.lock`, `Cargo.toml` or the workflow itself; manual dispatch | On Linux: `horizon-perf`'s `wasm` test |
| `mod-registry.yml` | Pull requests and pushes to main that change `crates/horizon-mod-package/`, `crates/horizon-mod-registry/` or the workflow itself | On Linux: `horizon-mod-registry`'s tests |
| `telemetry-server.yml` | Pull requests and pushes to main that change `crates/horizon-telemetry/`, `crates/horizon-telemetry-server/` or the workflow itself | On Linux: `horizon-telemetry-server`'s tests |
| `parity.yml`, from `ci.yml` (`parity`) and `run-parity.yml` | A pull request from this repository that changes a harness, an oracle, a probe or the runner, or carries the `run-parity` or `frame-identity` label; the `run-parity` label being added | On the self-hosted `horizon-game` runners: the harnesses the change can affect (`tools/parity.py --changed`) |
| `parity-main.yml` | Pushes to main; manual dispatch | On the self-hosted macOS `horizon-parity-main` runner: the harnesses the push can affect |
| `nightly.yml` (`audit`) | Once a day (03:07 in Paris); manual dispatch | On the self-hosted macOS `horizon-game` runners: every harness (`tools/parity.py --all`) |

An `#[ignore]`d test also runs when something else starts it:

- An ordinary test can start it as a child process, as `processes_sharing_the_secrets_file_lose_nothing` starts
  `secrets_file_writer` (`launcher/src/account/tests.rs`).
- A parity harness can run it with its oracle's output: the tests in `tools/ci/ignored-tests/parity-harness.txt`, such
  as `vanilla_bed_poi_states`, which `tools/test_bed_poi_parity.py` (`bed_poi`) runs with `HORIZON_BED_POI_ORACLE` set.
  Run these through their harness (`python3 tools/parity.py bed_poi`), not with `-- --ignored`: without the
  oracle's file the test panics.

Run by no workflow: the other `#[ignore]`d tests (many are marked `daily`), the launcher's tests on Windows between
the runs above (a try run with `-f windows=true` runs them on a branch), and `horizon-mod-package`'s tests on Windows
with its `runtime-process` feature. Run them by hand when a change reaches them:

- A crate's ignored tests: `cargo test -p <crate> -- --ignored`, naming the test to run one. In `launcher/`, a
  separate workspace, `cargo test -- --ignored`.
- The launcher on Windows: `cargo test` in `launcher/`.
- `horizon-mod-package` on Windows: `cargo test -p horizon-mod-package --features runtime-process`, and its ignored
  tests with `-- --ignored` added.
- Tests that read the vanilla data need resources prepared with `horizon-prepare`; without them they prove nothing.

The function-replacement check above is run by hand too. It compares hashes with `sha256sum`
(`tools/ci/fn_replace_check.sh`), so on macOS put a `sha256sum` on `PATH` first (GNU coreutils has one).

### When it releases

`tools/release_train.py decide --kind game` looks at the pull requests merged into main (first-parent merge
commits) since the commit the published Nightly was built on:

- A pull request counts when it changed what players run: `crates/` (not `examples/`, `tests/`, `benches/`),
  `xtask/`, `packaging/`, `Cargo.toml`, `Cargo.lock`, `research-lock.json`, or an exporter `horizon-prepare`
  compiles (the `mods/horizon/src/test/java/dev/horizonlab/parity/*.java` files its sources name). Markdown never
  counts.
- It goes in batches, so players get a few Nightlies a day rather than one per merge: once 5 pull requests count
  and the newest of them merged at least 5 minutes ago (a wave of merges becomes one Nightly), or once the oldest has
  waited 6 hours, however few they are.
- A pull request labelled `release-now` (a crash or a blocker) goes out at once.
- A pull request labelled `skip-release` (work players don't see) doesn't count and isn't listed in the notes.
- An open issue labelled `release-blocker` holds every Nightly, forced ones too (`held by release-blocker #N`);
  `nightly build` checks again right before publishing.
- One Nightly build at a time: while one runs or waits, dry runs included, the train starts none. Real builds share
  the concurrency group `nightly-build`, which never cancels a running build. A dry run (`dry_run`, or any dispatch
  off main) gets a group of its own, `nightly-build-dry-<run id>`: it never holds up a real cut (the rerun of its
  `sdk-publish` jobs queues in the shared group) nor replaces it or another dry run as the waiting run, so a dry run
  can start while a cut waits. The run's name says `(dry run)` or `(real)` and the `base` it was given, and
  `(off main)` for a dry run's base off main. At most 12
  builds a UTC day (the reviewers' `/nightly` builds count): past that the train waits for the next day, except for
  `release-now` and `force=true`.
- A scheduled run takes main's newest commit where `checks` and `parity-main` passed (a later failed
  parity-main batch doesn't change it); after a run of either, the commit it passed on, once both passed there.

### Nightly only

Ludovic decided on 2026-10-28 that Horizon ships only the Nightly. No `vX.Y.Z` game release is made any more:
the last one stays GitHub's *latest*, so launchers and servers from before the switch (which don't read Nightlies)
keep a working build until they update themselves. `.github/release-line.txt` still numbers the launcher's releases
(`launcher@X.Y.Z`).

- **Launchers** (#3342) install the current `nightly` pre-release as their update, as the version
  `nightly-<date>-<commit>`, after checking its checksums signed for the Nightly channel. A player on the newest
  release, on a Nightly or on nothing moves to it at the next check; a version picked by hand or pinned by an
  instance stays. Worlds are in the game's folder, never in a version's, so nothing touches them. The "Nightly
  builds" setting is gone. The last week's Nightlies (`nightly-<date>`) and the old releases stay on the Versions
  page. An instance on Stable set to Latest is offered the newest Nightly of each week and plays an installed
  Nightly, never one of the old releases (up to `v0.2.97`) unless no Nightly is installed yet: they stay full
  releases for `releases/latest`, but Stable skips them. A newer game release, not a pre-release, with a build for the player's platform replaces
  that weekly Nightly.
- **Servers** (#3331): `horizon-server update`, `install.sh` and `install.ps1` follow the Nightly the same way.
- **Kira** posts each Nightly in #releases; the bug template asks for the version the game shows.
- **Everyone gets the reviewers' picks.** A Nightly is main plus the pull requests the trusted reviewers picked
  ([below](#trusted-reviewers-pick-the-nightlys-pull-requests)), so a pick reaches every player with the next
  Nightly. `/nightly clear` makes it main alone.

### Labels

| Label | Effect |
| --- | --- |
| `feature` | Listed under **New** in the Nightly's and the launcher's notes |
| `release-now` | A Nightly as soon as main's checks and parity-main pass, past the batch rule and the day's cap |
| `skip-release` | Doesn't trigger a Nightly or a launcher release and isn't listed in the notes |
| `run-parity` | Runs the parity job once on a fork's pull request |
| `full-parity` | Runs the pull request's parity job on playhorizon's runner only (a change every harness reaches) |
| `parity-regression` | Opened by the nightly audit for a harness that fails on main |
| `release-blocker` | On an issue: no Nightly is published while it is open ([When it releases](#when-it-releases)) |

Pull requests without `feature` are listed under **Fixed**. Titles are written for players, since they become
the notes.

### Builds

| Archive | Runs on | Checks |
| --- | --- | --- |
| `horizon-linux-x86_64.tar.gz` | GitHub `ubuntu-22.04` (an older glibc, so it runs on any recent distribution) | the standard loader and libraries only (`tools/check_imports.py`) |
| `horizon-linux-musl-x86_64.tar.gz` | Alpine 3.22 in Docker on GitHub `ubuntu-22.04`, targeting `x86_64-unknown-linux-musl` | musl loader and libraries only (`tools/check_imports.py --musl`), CPU baseline and every program's startup checked inside Alpine |
| `horizon-server-linux-x86_64.tar.gz` | the same Linux job, after the client archive: `horizon-server`, `horizon-prepare` and the game built with `--no-default-features` as `horizon-engine` (docs/server.md) | as above, and neither `libasound.so.2` nor `libudev.so.1` (`tools/check_imports.py --server`) |
| `horizon-windows-x64.zip` | GitHub `windows-latest`, C runtime linked in | system DLLs only (`tools/check_imports.py`); PE machine is x64 |
| `horizon-windows-arm64.zip` | GitHub `windows-11-vs2026-arm`, built for `aarch64-pc-windows-msvc`, C runtime linked in | system DLLs only (`tools/check_imports.py`); PE machine is ARM64 and binaries start on the native runner |
| `horizon-macos-arm64.zip` | The Mac mini's runner (`vars.MAC_RUNNER=macos-latest` sends it to GitHub) | system libraries only (`otool -L`); a 1500-frame offscreen run of a new world (about 12 s; 300 frames end before the world has loaded) with resources prepared from the runner's own Minecraft (`--offscreen --world smoke --frames 1500 --smoke-report`: frames drawn, chunks generated and meshed, a player, no error) |
| `horizon-macos-x64.zip` | The same runner, cross-built for `x86_64-apple-darwin` (#1161) | as `horizon-macos-arm64.zip`, every program and the 1500-frame run under Rosetta 2; only the arm64 build's `smoke-test.json` is published |

Each builds `horizon-client`, `horizon-ctl`, `horizon-prepare` and `horizon-server` in release mode, checks they
exist, verifies Windows PE architectures, checks the `--help` and `--version` entry points, packages the folder with
`cargo run -p xtask -- package` and archives it. The
GitHub jobs keep their Cargo caches (`Swatinem/rust-cache`); the Mac mini keeps its `target/`. Only the Mac
runs the game: GitHub's runners have neither a GPU worth the name nor the game files.

The musl archive is an optional manual download for musl-based Linux desktops; see
[installation and updates](native-client.md#musl-linux-manual-installation). The launcher still selects the
standard glibc archive. The musl client and tools keep audio and controllers enabled and link musl dynamically
(`-C target-feature=-crt-static`) to load graphics and window libraries at runtime. A failed musl build does
not block other platforms: signing and publication omit the missing archive with a warning. The dedicated
server archive remains glibc; the bundled musl `horizon-server` refuses automatic updates to glibc archives.

Musl gameplay parity is not yet validated. On x86-64, `horizon-core::jmath` uses the platform libm for several
functions, so musl may round differently from glibc or HotSpot. Values near a simulation threshold could
therefore change world generation or mob behaviour for the same seed. This build has no musl parity results;
CLI startup checks do not establish gameplay parity. Before merging the platform support, record a successful
Nightly dry run and a musl-desktop launch covering the title screen, a new world, sound and a controller.

Building Windows ARM64 locally: [Windows ARM64](windows-arm64.md).

### Notes

`tools/ci/nightly.py pick` writes them: what reached main since the previous Nightly (`### New`, label `feature`,
and `### Fixed`, one line per pull request: its title, its number, the issues it closes; `release_train.bullet`),
then the picked pull requests (`### Not merged yet`), `### Known issues` (the bullets of
[docs/known-issues.md](known-issues.md)), thanks to outside contributors, the source commit and the disclaimer. The
title stays `Nightly <date> · <commit>`, which launchers and servers read the version from. Pull request titles
are written for players, since they become the notes.

Kira posts every Nightly once in Discord's #releases. It pings the releases role at most once a day: the first
Nightly published after 20:00 UTC, with a short list of what came out since its last ping. Every other post is
silent (no ping and Discord's @silent flag). Launcher releases post without a ping.

### One channel

Before 2026-10-28 game releases were `vX.Y.Z` (numbering: [versioning.md](versioning.md)), each published by this
workflow as the release and GitHub's *latest*. From 2026-10-23 there was one channel (the Alpha pre-releases and the
daily promotion at 20:00 UTC ended: `promote.yml` and `tools/release_channels.py` are gone), and from 2026-10-27 the
Nightly was opt-in beside it. Since 2026-10-28 the one channel is the Nightly ([Nightly only](#nightly-only)).

### Signed checksums

Every game and launcher release carries `SHA256SUMS` (the archives' SHA-256, `sha256sum`'s format) and
`SHA256SUMS.sig`: one base64 Ed25519 signature per line over `horizon release <tag>\n` followed by SHA256SUMS,
so a signed list can't be reused under another tag.

- A `sign` job of its own makes them: `tools/ci/sign_release.sh` runs the runner's `sha256sum` and OpenSSL and
  nothing else. It is the only job that holds the private key, the `RELEASE_SIGNING_KEY` secret of the
  repository's `release` environment, which only real releases from main enter (`environment:` is empty in dry
  runs, which sign with a throwaway key). No code from the repository runs beside the key, so no pull request
  can read it by changing what a build compiles; the key is in no file, no log and no password vault, and nobody
  needs to read it.
- The publish job then checks the signature the way launchers do (`horizon-release-sign verify --publishing`,
  crates/horizon-release-sign), against the public keys built in from
  `crates/horizon-release-sign/release-keys.txt`. While that file lists no key, releases go out with SHA256SUMS
  alone and a warning (today's releases keep working). Once it lists one, a missing secret or a key it doesn't
  list fails the release before anything is published, instead of publishing something launchers would refuse.
- Making the key: `tools/ci/new_release_key.sh` pipes a new key from `horizon-release-sign keygen` straight into
  `gh secret set RELEASE_SIGNING_KEY --env release` and prints only the public key, which then goes into
  release-keys.txt by pull request.

**Releases from before signing.** The launcher and `horizon-server update` install only signed releases, with
one exception, so a player or a server can still go back to an older version: every release published before
signing began has its archives' SHA-256 pinned in `crates/horizon-release-sign/legacy-releases.txt`, built into
both. Those releases install only with exactly those files, whatever GitHub serves for them later. The file was
written once by `tools/ci/legacy_releases.py` from the SHA-256s GitHub computed at upload; it lists no signed
release and never changes again (`--check` says whether it is complete).

**Rotating the key** (a new key every year, or at once if the old one may have leaked). The publish job signs
with every key the environment holds, `RELEASE_SIGNING_KEY` and `RELEASE_SIGNING_KEY_NEXT`, and the two names take
turns:

1. `tools/ci/new_release_key.sh <the empty name>` makes the next key; add its public key to release-keys.txt
   beside the old one. From then on every release is signed with both keys (one line each).
2. Wait until launchers and servers built with both keys are in use (a few weeks: launchers update themselves).
3. Delete the old key's secret (`gh secret delete <its name> --env release`) and its line in release-keys.txt.
   The next rotation makes its new key under the name just freed.

If the old key may have leaked, skip the wait: remove its public key from release-keys.txt at once and delete
its secret. Launchers built before the new key cannot check releases signed only with it: they refuse to install
them with a clear message, and players download the launcher again from the website once.

### Starting one by hand

```sh
gh workflow run release --ref <branch>                         # dry run: decides and says why, starts nothing
gh workflow run release --ref main -f dry_run=false            # the usual decision, now
gh workflow run release --ref main -f dry_run=false -f force=true   # a Nightly now, whatever the rules (even while paused)
```

### Pausing

```sh
gh variable set RELEASES_PAUSED --body 1     # no automatic Nightly or launcher releases
gh variable delete RELEASES_PAUSED           # back on; the next run catches up
```

While paused, runs still decide and say why in their summary; `force=true` still starts a Nightly, but never past an
open `release-blocker`. The reviewers' `/nightly` and the 20:17 UTC build still run: a line `paused` in
`.github/trusted-reviewers.txt` stops the reviewers' commands.

### Rolling back

To stop the next Nightlies while a problem is fixed, label an issue about it `release-blocker`. The way out is
forward: revert the pull request (or `/nightly remove` a pick), label the revert `release-now`, and a fixed Nightly
is out as soon as main's checks and parity-main pass. Meanwhile a player can pick an earlier build on the launcher's
Versions page (the last week's `nightly-<date>`, or a `vX.Y.Z`), and `horizon-server update --version <tag>` does
the same for a server.

## Prebuilt SDK retention design (horizon-rust/horizon, arismoko/horizon#3011)

**Proposed for review, not enabled.** This is an availability policy, not an implementation or an instruction to
build an SDK. Automated SDK pruning stays removed until this design is reviewed. SDK signing and authentication
of downloads or caches belong to arismoko/horizon#3009; retaining a release does not authenticate it.

### Current publication contract

The [Nightly workflow](../.github/workflows/nightly-build.yml) builds the SDK of its source commit, publishes it as
`sdk-<sha>` ([sdk-publish.yml](../.github/workflows/sdk-publish.yml)), and calls `require-sdk`
([`tools/ci/nightly.py`](../tools/ci/nightly.py)) before rotation and again before publication. A complete SDK means a
published, non-draft `sdk-<40 lowercase hex SHA>` release holding every asset
`nightly.py sdk-assets` names: `sdk.json`, `SHA256SUMS` signed for `sdk-<sha>` (`SHA256SUMS.sig`), `surface.json`,
`api-source.tar.xz`, `build-data.tar.xz` and the `runtime`, `api` and `engine` slices of the four packages (Linux client, Linux server,
Windows GNU and macOS ARM64); its `sdk.json` must match those sums and name that build and this package format. The
Nightly carries that `sdk.json` in its own signed sums. The SDK signature's message names `sdk-<sha>`, so it never
passes for a game release, nor a game release's for an SDK (`horizon-release-sign`: `signed_digest`, `sdk_digest`).
One publish step ([sdk-publish.yml](../.github/workflows/sdk-publish.yml)), called by the Nightly workflow and by the
[SDK workflow](../.github/workflows/prebuilt-game.yml)'s hand dispatch, publishes those exact-SHA releases without
pruning; it signs through the `release` environment on main only, and any other run signs with a throwaway key and
publishes nothing. Older `prebuilt-<sha>` releases are outside it and are removed by hand.
These workflows currently have separate concurrency groups (`nightly-build` and `prebuilt-game`): the two
publication-time checks alone would not make concurrent deletion safe.

Nightly publication rotates `nightly` to `nightly-YYYY-MM-DD`, replacing a previous dated release for the same
day. It prunes dated releases whose date is strictly older than UTC today minus seven days; it never expires
the current `nightly`. `nightly.py source_line` writes the full source commit into release notes, and
`keep-source` preserves it under `nightly-source/<date>-<short>`. Those permanent source tags preserve source
availability, not a promise to retain compiled SDKs forever.

### What pruning deletes

Once SDKs publish as `sdk-<sha>` releases, each asset's `kind` is listed in the release's signed `sdk.json`.
Pruning deletes only assets whose `kind` is `runtime`, `api` or `engine`, never the release, its small files or
its signature. An evicted build keeps `sdk.json`, `surface.json`, `build-data.tar.xz`, `api-source.tar.xz`,
`SHA256SUMS` and `SHA256SUMS.sig`, so `cargo horizon-mod sdk diff` and the fit test keep working for it; only
building against it needs the compiled assets back.

### Keep set and bound

At one UTC instant T, let R be **all actually existing** current and dated Nightly releases, including drafts,
plus matching Nightly tags without a release. Protect each one's resolved full source SHA, regardless of age.
Do not assume a dated Nightly is gone just because its date is outside the usual seven-day window. A failed or
stalled Nightly cleanup must not turn a still-downloadable game into an unpaired game.

Keep every exact-SHA SDK referenced by R, and the **10 newest unreferenced exact-SHA SDK releases**, ordered by
publication time (`published_at`) descending, then release ID descending as a deterministic tie-breaker.
For drafts without `published_at`, use draft `created_at` as the provisional ordering timestamp;
publication replaces that timestamp. Never use a published release's `created_at` for publication order:
GitHub derives it from the target commit's date. Delete only the
remaining unreferenced SDK releases. Count incomplete and draft SDK releases toward those 10 too: neither is
an excuse to delete a referenced release. There is no age exemption or accumulating grace-period queue.
The reserve covers SDKs published since the last Nightly pick that no Nightly references yet.
Never delete unrelated tags, release families, permanent source tags or build branches in this operation.

After a successful complete sweep the SDK release count is at most `distinct protected SHAs + 10` (assuming
one exact-SHA release per SHA). Under normal dated-Nightly cleanup this is at most 19: eight inclusive UTC
date buckets and one current Nightly, often fewer because pins overlap. This is a count bound, not a byte
quota. If older Nightlies remain, the bound grows with their distinct pins; a hard global cap cannot coexist
with preserving every retained Nightly. Report excess retained Nightlies for repair rather than overriding
their protection. API failures likewise favor availability over the target bound.

Installed games whose Nightly release has already expired are not additional server-side roots: their source
tag stays, but their SDK may eventually be evicted. Keeping their SDK indefinitely would require an additional
reference-registration contract and would defeat this bound. Do not delete a player's local SDK cache.

### Complete source discovery, or no deletion

1. While holding the shared publication lock below, enumerate the repository's entire releases API history,
   following every pagination link to normal exhaustion, and enumerate every matching Git tag. A fixed limit
   such as the existing Nightly pruner's `--limit 200`, the latest release, workflow run history, or a cached
   release list is not sufficient. Record release IDs, names, draft status, timestamps and tag identities.
2. For each `nightly` or valid `nightly-YYYY-MM-DD` root, resolve its actual Git tag to a commit. Recursively
   peel annotated tags; require a full 40-digit lowercase commit SHA. Never interpret `target_commitish`
   as the source pin: it can be a branch name, not the commit the built game used.
3. For each Nightly release, require its notes' full `Source: commit <SHA>` pin and require equality with the
   resolved tag commit. Cross-check any named permanent source tag against that same commit. A short SHA in
   the title, today's main head, a date or the suffix of a source tag cannot substitute for the full pin.
   A tag-only root is conservatively protected by its resolved commit; a release whose tag is missing or whose
   pin is missing, ambiguous or inconsistent aborts the sweep, rather than guessing that it is obsolete.
4. Build a deduplicated protected set and a reverse map of SHA to all roots for the review summary. Discover
   SDK candidates only by the exact `prebuilt-[0-9a-f]{40}` release tag-name pattern. Resolve each candidate's tag
   and require it to agree with the SHA in its name. An unreferenced draft whose exact-SHA tag is absent
   (for example, a failed upload) still counts toward the reserve and is eligible for release-only deletion
   outside it; do not invent or delete a tag for that draft. A referenced draft or missing tag still fails
   closed. Other malformed SDK-family names or mismatches abort the sweep
   for manual review. For every protected SHA require the corresponding SDK to exist and be complete under
   the publication contract above. A missing pair is an availability incident: delete nothing and report it;
   pruning neither rebuilds it nor silently removes its Nightly.
5. Finish all discovery and validation before the first destructive request. Any missing page, truncated or
   malformed response, permission/rate-limit/network error, unresolved tag (except the unreferenced SDK draft
   exception above) or incomplete asset listing means
   **zero deletions**, a failed run and an actionable summary. An empty result is accepted only after successful
   exhaustive queries and tag reconciliation; a 404 or an API exception is not an empty history.

### Publication/deletion exclusion

Retention defaults to dry-run: it issues zero release or tag mutations and reports the protected roots,
reserve and proposed deletions. Review a complete dry-run summary before enabling pruning. Mutation
requires an explicit `--apply` switch; neither a schedule nor a saved plan implicitly enables it.
On apply, acquire the shared lock and repeat complete discovery and validation to compute a fresh plan,
not replay the earlier dry-run inventory. Keep the lock through deletion.

Before enabling pruning, replace the independent workflow concurrency groups with one repository-wide,
non-cancelling group, `nightly-sdk-publication`, used by the **entire** real Nightly workflow, SDK workflow and
retention workflow. Acquire it before Nightly source selection and SDK readiness checks, not just before
`gh release create`, and retain it through rotation, publication and cleanup. Entire-workflow serialization
deliberately trades throughput for a simple invariant; do not nest a job lock inside that workflow lock.
All dispatch, scheduled, retry and recovery paths that mutate these releases/tags must honor this exclusion.
Manual operations must use the same serialized maintenance path, not out-of-band API writes.
With GitHub Actions' default concurrency queue, a newer pending run can replace an older pending run even when
`cancel-in-progress` is false. Treat a canceled pending publication or retention run as not executed; surface it
and retry it, or use a supported durable queue. Never infer that every requested publication or sweep ran.

A Nightly that wins the lock first publishes before retention discovers its roots; retention therefore keeps
its pair. Retention that wins first finishes before Nightly selects and freshly checks an available pair.
If a requested historical SDK was evicted, the later explicit Nightly request fails before rotating current;
it does not publish a missing pair. SDK publishing cannot interleave with discovery either. Rechecking readiness
without this exclusion leaves a check/delete/create race and is not an alternative.

Within the lock, re-read root IDs and resolved pins and each candidate's release ID/tag immediately before
deletion; unexpected changes abort remaining work. Delete by the inventoried release ID, never a newly looked-up
name; remove its exact SDK tag only after successful release deletion and confirming the tag still has the
inventoried value. Stop on a failed mutation and report completed deletions; an interrupted sweep may leave an
unreferenced SDK tag, which a later sweep may remove only after the same full discovery and SHA checks.
Do not claim transactional rollback. Concurrent manual writes bypassing the lock invalidate the guarantee,
so pruning must remain disabled unless every authorized writer follows it.

### Review cases

| Case | Required outcome |
| --- | --- |
| Current `nightly` is months old while SDKs keep publishing | Keep its exact SDK regardless of count or date, plus the bounded unreferenced reserve. |
| Current and several dated Nightlies share a SHA | One protected SDK; deleting one Nightly never releases the other roots' protection. |
| Dated Nightly expires or is replaced by another on the same day | Its SDK becomes eligible only once no current, dated or tag-only root references it; the 10-release reserve still applies. |
| An old dated Nightly remains after failed cleanup | Keep its SDK; report the larger protected set instead of inferring deletion from age. |
| API history stops after a page, a source tag cannot resolve, or a release lacks its full source pin | No deletions; fail closed, even if known roots appear safe. |
| A referenced SDK is missing assets or absent | No deletions; report the broken pair for recovery. |
| Nightly and retention start together, including a retry using an old explicit base | Shared lock orders them; discovery protects an already published pair, or selection refuses the evicted base before rotation. |
| A sweep dies after deleting a release but before its tag | No protected pair was eligible; rediscover everything before cleaning the orphan tag or resuming. |

Implementation review must exercise these outcomes with synthetic paginated release/tag inventories and
controlled publication/deletion interleavings, including annotated tags, API errors and partial mutation failure.
No SDK compilation is needed to evaluate this design.

## Launcher releases

`.github/workflows/launcher.yml` releases the launcher the same way. It starts on a push to main that changes
`launcher/`, `crates/horizon-prepare/` or `crates/horizon-theme/` (what the launcher builds in), every hour at :47,
and by hand; pushes to `launcher` and `launcher-*` branches only build. Branch builds of the launcher (any run off
main) are unsigned and run on GitHub-hosted runners; signing stays on main. The notes and the signature check
run on every run with a token that only reads; a separate publish job, only for main's real release, creates the
release.

- `tools/release_train.py decide --kind launcher` counts the pull requests merged since the last published
  launcher release that changed those paths (not `launcher/links.json`, which the launcher reads from main, nor
  tests or Markdown), with the same batching rule except that the oldest waits 1 hour, not 6 (5 pull requests settled
  5 minutes, or the oldest 1 hour: a fix to installs or updates starts its release at most ~70 minutes after it
  merges, as the decision runs every 10 minutes, then builds and publishes), `release-now`, `skip-release` and
  `RELEASES_PAUSED`.
- The tag is `launcher@X.Y.Z` on the release line (`launcher@0.2.0` first; the game and the launcher count their
  patches separately). Without `.github/release-line.txt`, `launcher-vX.Y.Z`: the patch after the last launcher tag,
  or the next minor (`X.Y+1.0`) when one of those pull requests is labelled `feature`. `launcher-v0.2.0` was taken
  long before 0.2, hence the new prefix.
- No version-bump commits: the build gets the version in `HORIZON_LAUNCHER_VERSION` and the tag in
  `HORIZON_LAUNCHER_TAG`, which `launcher/src/backend.rs` reads with `option_env!` (falling back to `Cargo.toml`'s),
  so `--version`, the window, the User-Agent and the self-update comparison all use them. Each build checks
  `--version` says it.
- Linux on GitHub `ubuntu-22.04`, Windows x64 on `windows-latest`, Windows ARM64 on `windows-11-vs2026-arm`, and
  macOS on the Mac mini's runner; each runs the launcher's tests and checks its libraries. The smoke test installs
  the newest game build for that platform; Intel macOS skips only the install step while no matching build is
  available yet, and Windows ARM64 installs the x64 build (under emulation) from a Nightly without an ARM64 one.
- Published with `--latest=false`: the repository's latest release stays a game release. Notes list the pull
  requests under New and Fixed; Kira posts launcher releases without pinging.
- Windows also publishes `horizon-launcher-setup.exe` (x64) and `horizon-launcher-setup-arm64.exe`, the launcher's
  binary under another name: with no
  arguments it opens the per-user setup (`launcher/src/installer.rs`) instead of Home, and
  `horizon-launcher.exe uninstall` removes it again. Both files are in the release's signed `SHA256SUMS`.

Making a launcher release GitHub's latest instead would break servers: every `horizon-server` already installed,
`install.sh` and `install.ps1` ask for `releases/latest` and expect the game's archives there, and a server that
can't update can't fetch the fix either. So the game release stays the latest, and it sends people to the launcher
(#1647): its notes open with a "Want to play? Download the Horizon launcher" block (`PLAYERS` in
`tools/release_train.py`: raw HTML, which GitHub shows and launchers' notes skip; the site's Releases page leaves
it out too), which `PLAYERS_FOOTER` repeats above the disclaimer at the end, and its archives carry labels ("Game files the
launcher installs: Linux (…)") that GitHub shows in place of the file names. Everything that downloads matches
the asset's name, which is unchanged.

Starting by hand, pausing and rolling back work as for the game (`gh workflow run launcher …`,
`RELEASES_PAUSED`, `gh release edit launcher@X.Y.Z --draft`). Launchers older than the withdrawn release then
see the previous one as the newest; launchers that already updated keep running.

With several game releases a day, the newest launcher release soon falls out of the newest 100 releases the
launcher and the website read: both then look the newest launcher tags up one by one
(`git/matching-refs/tags/launcher@`, then `launcher-v` if there is none, then `releases/tags/<tag>`).

## Nightly channel

`.github/workflows/nightly-build.yml` builds and publishes the Nightly, the only build players get since
2026-10-28: when the batch train decides ([Game releases](#game-releases), with the commit as `base`), once a night
(20:17 UTC) and when a trusted reviewer asks (#2681). It builds main's newest commit where
`checks` and `parity-main` passed, as a release does (or the `base` input), plus the pull requests the trusted
reviewers picked, merged in their order; with none picked, that commit alone (`tools/ci/nightly.py pick`). No green
commit (main's newest `checks` or `parity-main` run failed) builds nothing. A night with nothing new publishes nothing. A pull request goes in without a review: a trusted
reviewer or Ludovic can pick any open pull request to main, reviewed or not (Ludovic, 2026-10-30, at the Team's
request, because they were often blocked on the launcher; from 2026-10-28 it needed an approving review at the
head that is built). The guards stay: the pull request must be open and target main, it must leave the
CODEOWNERS-guarded files alone, the sets and builds stay capped, `paused` stops the reviewers, the council's `remove`
sticks, and the build runs without secrets. Each pull request is built at the head it was picked at; a push after
the pick waits until someone picks it again (`/nightly add`).

Every Nightly ships its exact source. Its notes name the commit; `horizon-source.tar.gz` on the release is that
commit's `git archive`, signed with the builds in `SHA256SUMS`; and `nightly.py keep-source` tags the commit
`nightly-source/<date>-<short>`. That tag is never pruned, unlike the `nightly-<date>` release and the
`nightly/build-*` branch (7 days each), because native mods pin a Nightly's commit and the launcher downloads that
commit's source to build them ([modding/src/how-to/native-mods.md](modding/src/how-to/native-mods.md)).

### Trusted reviewers

One list, `.github/trusted-reviewers.txt`, governs two things for the people on it (kacpherek, rdbtCVS and
Online5277 since 2026-10-27, levzzz5154 since 2026-10-28) and for Ludovic, with no repository role: `/nightly` (below) and triage by comment.

```text
/close                    closes an issue as completed; a pull request is closed without merging
/close not planned        closes an issue as not planned
/close duplicate of #123  comments "Duplicate of #123", closes as a duplicate
/reopen
/label bug, good first issue    existing labels only; never creates one
/unlabel bug
/unclaim @login           releases someone else's claim on an issue (anyone can `/claim` and `/unclaim` their own)
```

- **Where.** On the first line of a comment on the issue or pull request (`.github/workflows/triage-command.yml`,
  `tools/ci/triage_command.py`). The workflow answers with one comment, `🤖 Triage: <action>, on behalf of @login`,
  linking the comment that asked; a refusal answers too. Claims are their own workflow
  (`.github/workflows/claim-command.yml`, `tools/ci/claim_command.py`), open to everyone for their own claim.
- **Refused.** Any label with `release` in its name (`release-now`, `release-blocker`, `skip-release`) and
  `full-parity`; anything on Ludovic's own issues and pull requests; a merged pull request; a locked thread; more
  than 60 actions per reviewer in 24 hours (counted from the workflow's own comments).
- **Safety.** Same as `/nightly`: main's copy of the workflow runs, no pull request's code is checked out or run,
  the comment reaches the script as env vars, and the token has `issues` and `pull-requests` write only.
- **`needs-info`.** `/label needs-info` on an issue asks its author for more. A person's comment takes it off
  (bots' don't count); with no answer in 7 days, `.github/workflows/needs-info.yml` (`tools/ci/needs_info.py`)
  closes the issue as not planned. It can be reopened once the details are there.
- **The council stays in charge.** A one-line pull request removing a reviewer's line revokes it as soon as it merges
  (the council reviews the file under CODEOWNERS). A line `paused` stops `/nightly`, the triage commands and the
  reviewers' claim powers for every reviewer; the council's own still work.
- **Accounts, not names.** Each line is `<numeric GitHub ID> <login>`, and every command decides by the comment
  author's ID (`AUTHOR_ID`, from `github.event.comment.user.id`), never by the login: GitHub hands a renamed or deleted
  account's login to whoever claims it next, while an ID is never reused. The council's members are listed the same way in `.github/council.txt` (and the founder is `OWNER_ID` in
  `tools/ci/nightly_set.py`); each holds these owner powers. A line in any other form, a bare login included, grants nothing.
  `python3 tools/ci/resolve_reviewer_ids.py` fills in IDs for new lines; `--check` reports a listed ID whose login
  changed (a rename to look at) or whose account is gone.

### Stale pull requests

`.github/workflows/stale-prs.yml` (`tools/ci/stale_prs.py`, daily) closes pull requests left waiting on their author.
An open, non-draft pull request to main gets the `stale` label and one comment naming the reason when it conflicts
with main and saw no push, reopen, or person's comment, review or review-thread reply for 4 days, or when its head is
still the commit a changes-requested review looked at 7 days later and that reviewer hasn't been asked to look again.
Any push or person's comment takes the label off; unchanged 3 days after the notice, it is closed with a comment (its
unfinished checks are cancelled, as `cancel-on-close.yml` would), and reopening it starts again. Drafts, the merge
queue, other bases and the labels `keep-open`, `pinned`, `proposal`, `tracker` and `release-now` are never touched, nor
is a pull request whose mergeable state GitHub hasn't worked out yet; each one is read again right before it is
labelled or closed. At most 30 actions a run. A dry run by hand: `gh workflow run stale-prs.yml` (its `dry_run` box is
ticked by default), or locally `python3 tools/ci/stale_prs.py`, which only reads. Before the first scheduled run,
`python3 tools/ci/stale_prs.py create --apply` creates the labels.

### Trusted reviewers pick the Nightly's pull requests

The Nightly is where contributors test pull requests before the gate. The trusted reviewers listed in
`.github/trusted-reviewers.txt` (kacpherek, rdbtCVS and Online5277 since 2026-10-27, levzzz5154 since 2026-10-28) and the council pick them with a
comment on any issue or pull request (`.github/workflows/nightly-command.yml`, `tools/ci/nightly_set.py`):

```text
/nightly 2640 2642     the set becomes these pull requests, merged onto main in this order; builds now
/nightly add 2650      adds one, or takes its newest head again; builds now
/nightly remove 2640   drops one; builds now
/nightly clear         empties the set: back to main alone; builds now
/nightly status        what the set holds
/nightly dry-run 2640  builds main + these and signs with a throwaway key; publishes nothing, the set stays
```

- **The answer.** The workflow answers in the thread with one comment starting `🤖 Nightly:`: the set, the build's
  run, and later the published Nightly (or why it failed).
- **The set** is `set.json` on the `nightly-state` branch: who asked, when, and each pull request at the head it had
  then. A head is taken again only when someone asks again, never silently in between. The
  scheduled run builds every pull request at that head and drops the merged, closed and refused ones; the notes say so.
  `builds.jsonl` there records each build's set (for `nightly_stats.py`).
- **Assembly.** `pick` (main's code) fetches each head and merges them onto main with `git merge-tree
  --write-tree`: git objects only, no working tree, so no file, hook or filter of theirs reaches the runner. The
  result is pushed as `nightly/build-<date>-<n>` and `build` compiles that, without secrets, as for a release.
  Equal inputs give the same commit, so an unchanged set and main publish nothing new. On a conflict the build
  stops and answers which two pull requests conflict and where; a reviewer can then open an integration pull
  request from their fork that combines them, and pick that one instead.
- **Old builds.** The scheduled run deletes the `nightly/build-*` branches older than 7 days (Ludovic,
  2026-10-27), and lists each in its summary. It never deletes the newest build, a build a published `nightly` or
  `nightly-<date>` release points to, or any other branch (`nightly.py prune-builds`).
- **Refused.** A pull request that changes a path CODEOWNERS gives to the council (`.github/`, `tools/ci/`, the
  signing and update code, `launcher/src/backend.rs`, `launcher/links.json`…), more than 30 in a set, and more than
  12 builds a day (the scheduled one always runs; 6 until 2026-10-28).
- **No repository role.** Reviewers need no permission on the repository: the list file and the workflow are the
  whole of it.
- **The council stays in charge.**
  - A council member's `/nightly clear` or `/nightly remove` always applies. A pull request the council removed can
    only come back when a council member adds it.
  - A one-line pull request removing a login from `.github/trusted-reviewers.txt` revokes it as soon as it merges
    (the council reviews the file under CODEOWNERS).
  - A line `paused` in that file stops every reviewer's `/nightly` (and triage commands); the council's still work.
  - Main and the gate don't change, but a pick reaches every player with the next Nightly.

- **Jobs.** `pick` assembles the commit and writes the notes: what reached main since the previous Nightly (New and
  Fixed, as a release's notes), then each picked pull request with its title, author and who picked it, the known
  issues and the thanks. `build` is
  `game-build.yml`, the same builds and smoke test as a release, with the version `nightly-<date>` and
  `HORIZON_NIGHTLY="<date> <short sha>"` built in, macOS signed ad hoc. `sign` signs SHA256SUMS for the channel
  (the message says `horizon release nightly`, so a nightly's signature never passes for a release's). `publish`
  checks the signature, the smoke test and that no `release-blocker` is open (as a release; a dry run only warns, so
  `/nightly dry-run <pr>` still tries a blocker's fix), renames the
  previous `nightly` pre-release to `nightly-<its date>`, publishes the new one as the `nightly` pre-release (never
  GitHub's latest), and deletes the `nightly-<date>` pre-releases and tags older than 7 days, nothing else.
- **The signing key never meets the pull requests' code.** Every workflow file and script runs from main's copy (a
  schedule and `issue_comment` run the default branch; `uses: ./…` takes the caller's commit), never a pull
  request's `.github/`, and a pull request that changes `.github/` or `tools/ci/` is refused. `build` compiles the
  merge with a read-only token that isn't kept in the checkout and no secrets; the runner's Developer ID keychain
  stays locked. `sign` is the only job with the key, and checks out only main's `tools/ci/sign_release.sh`, which
  hashes the archives with the runner's `sha256sum` and signs with its OpenSSL: it never runs what `build` made.
  `publish` runs main's `horizon-release-sign`, never the archives.
- **Where it builds.** `release.yml` starts `nightly-build.yml`, which calls `game-build.yml` with `trusted: false`
  and `developer_id: false`, so releases build as Nightlies do. The macOS jobs run on the Mac mini's nightly runner
  (`horizon-nightly`), never the release runner (`MAC_RUNNER`), and the Rust cache has its own key and is never
  saved. They don't read machine-shared caches: no sccache (`HORIZON_NO_SCCACHE`, `tools/ci/runner-env.sh`) and no
  cargo configuration from outside the checkout (`tools/ci/cargo_isolation.py` fails the job and names it), and
  each run starts from a fresh cargo home.
- **Players.** Every launcher and `horizon-server update` install the `nightly` pre-release
  ([Nightly only](#nightly-only)). It is never GitHub's latest: the last `vX.Y.Z` stays that, for launchers,
  servers and `install.sh` from before the switch.

```sh
gh workflow run "nightly build"                  # now; skips when the pick is the commit already published
gh workflow run "nightly build" -f force=true    # build and publish anyway
gh workflow run "nightly build" -f dry_run=true  # build and sign with a throwaway key, publish nothing
```

A dry run can build a commit that is not on main yet, so a fix is tried before it merges. Push the commit to a
branch under `dry-run/` (the one prefix reserved for this; pushing there is someone with push rights saying "this
commit may be dry-run built"), dispatch from main with the full SHA, and delete the branch afterwards:

```sh
git push origin <sha>:refs/heads/dry-run/<name>
gh workflow run "nightly build" --ref main -f dry_run=true -f off_main=true -f base=<full sha>
git push origin --delete dry-run/<name>          # once the run is over
```

`pick` takes such a base only in a dry run with `off_main` set, and only when a `dry-run/*` branch, fetched fresh,
holds it. Any other branch doesn't count (some hold outside code nobody reviewed: fork snapshots, Dependabot's
bumps), nor does a pull request's `refs/pull/*` head: GitHub hands out a fork's commits by SHA here too, so having
the commit proves nothing. `off_main` with a base on main stops too, so the run's name (`(off main)`) and summary
never say it wrongly. Such a run gets no repository secrets (the signing keys reach `sign` jobs on a real run only),
and nothing publishes. Every dry run's own `nightly/dry-run-<run id>-<attempt>` branch is deleted when it ends,
failed or cancelled too (`dry-run-cleanup`, by that exact name).

What it proves: the candidate's build, smoke test and SDK indexing. It still runs main's `nightly-build.yml`, the
reusable workflows and `nightly.py pick`, so a fix to those can't be proven this way.

An off-main dry run builds with `trusted: false` on the Mac mini's nightly runner (`ludovics-mac-mini-nightly`):
it never uses the release runner, never saves the GitHub Actions Rust cache, doesn't read machine-shared caches
(no sccache: `HORIZON_NO_SCCACHE`, `tools/ci/runner-env.sh`) and starts from a fresh cargo home.

## Nightly audit

`.github/workflows/nightly.yml` runs every harness from scratch (`tools/parity.py --all`) on main at 03:00 Paris
time, on the Mac mini's runner, after preparing the resources again if the preparer or its exporters changed.
`tools/ci/parity_issues.py` then compares the results with the previous audit
(`.local/parity-runner/audit.json` in the runner's checkout):

- a harness that fails now and passed last night, or is in its first audit, gets an issue labelled
  `parity-regression`, titled `Parity regression: <harness>`, with the commit, the run and the end of its log (one
  issue per harness: an open one gets a comment instead);
- a harness with an open issue that passes again gets its issue closed.

The bugs session picks the issues up. The audit's logs are the run's `nightly-parity-logs` artifact; harnesses
listed `linux_only` are skipped there (see above). By hand: `gh workflow run "nightly audit"` (add
`-f dry_run=true` to leave issues alone).

## Disk

Releases ship often, so nothing they leave behind may grow without bound.

- **Artifacts:** every upload keeps 3 days (nightly parity logs 7); a release's assets live on the release itself.
- **Mac runners:** `tools/ci/runner-gc.sh` runs every 30 minutes from launchd (`StartInterval` 1800) on the Mac mini, as a copy taken from main
  (`~/.actions-runners/runner-gc.sh`, plist `dev.horizon.runner-gc`), never from a pull request's checkout. It skips a
  runner in a job, removes a checkout's cargo build folders past 12 GB (`MAX_TARGET_GB`) and harness work folders
  under `.local/` untouched for 3 days (`STALE_DAYS`), and keeps the 2 newest shared preparations (`KEEP_PREPARED`)
  while no runner works. It also stops harness JVMs (vanilla servers, oracles) left orphaned for 3 hours
  (`ORPHAN_HOURS`): parent gone, command line under a runner's checkout or a worktree's `.local/`. `tools/parity.py`
  stops its own harnesses on SIGTERM and SIGHUP (a cancelled job), so these come only from a SIGKILL or a harness run
  by hand. Runner builds go through the machine's sccache (`tools/ci/runner-env.sh`), so what it removes
  comes back from the cache. It also runs `tools/ci/git-slim.sh` on each idle runner's checkout (the nightly runner's
  too): actions/checkout switches git's gc off in a persistent checkout and fetches into it at every job, so packs
  pile up (1051 of them, 111 GB, in one desktop checkout on 2026-11-09). git-slim removes the leftovers of cut-short
  fetches, collects a `.git` over 5 GB (`MAX_GIT_MB`) with `git gc --prune=now` and folds more than 40 packs
  (`MAX_PACKS`) into few. Update the copies after changing the scripts (git-slim.sh goes beside runner-gc.sh):
  `ssh macmini 'cd ~/.actions-runners && for f in runner-gc.sh git-slim.sh; do curl -fsSL https://raw.githubusercontent.com/horizon-rust/horizon/main/tools/ci/$f -o $f; done'`.

Guest-stack release note (arismoko/horizon#3232): game and server executables reserve 136 MiB
(144 MiB on macOS) for their main stack through MSVC `/STACK` or Apple `-stack_size` linker arguments;
Linux raises RLIMIT_STACK and re-execs before initialization. Rosetta 2 ignores `-stack_size`, so an
Intel macOS program there runs its `main` on a stack its main thread allocates (`run_main`).
