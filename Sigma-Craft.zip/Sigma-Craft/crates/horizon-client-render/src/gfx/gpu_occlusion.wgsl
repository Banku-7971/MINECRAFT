// GPU culling's occlusion test (gpu_culling.rs `BoxTest`), after
// gpu_culling.wgsl in one module, made only where the depth test can be forced
// before the fragment shader (Vulkan, cull.rs `DepthTest::Early`): one instance
// per box `cull` listed, its section's box drawn front faces only against phase
// 1's depth; then `count2`, `scan2` and `scatter2` write phase 2's draws.
@group(0) @binding(9) var<storage, read> box_list: array<u32>;
@group(0) @binding(10) var<storage, read> box_origins: array<vec4<u32>>;
@group(0) @binding(11) var<storage, read_write> box_runs: array<u32>;
@group(0) @binding(12) var<storage, read> box_sections: array<Section>;

// The corners (bit 0: x, bit 1: y, bit 2: z) of the box's 12 triangles,
// counter-clockwise seen from outside (cull.wgsl's `box_triangle_corner`).
// Packed four bits each, eight a word, read through a switch: a constant array indexed by the
// vertex would be a private array, which Adreno's Vulkan compiler (build 0676.41) fails to link.
fn box_triangle_corner(v: u32) -> u32 {
    var word: u32;
    switch v / 8u {
        case 0u: { word = 0x31640260u; }
        case 1u: { word = 0x05105717u; }
        case 2u: { word = 0x76237245u; }
        case 3u: { word = 0x54320130u; }
        default: { word = 0x00006747u; }
    }
    return (word >> (v % 8u * 4u)) & 0xfu;
}

struct BoxOut {
    @builtin(position) position: vec4<f32>,
    @location(0) @interpolate(flat) id: u32,
}

@vertex
fn vs_box(@builtin(vertex_index) v: u32, @builtin(instance_index) t: u32) -> BoxOut {
    let id = box_list[params.occl.y + t];
    let o = bitcast<vec3<f32>>(box_origins[id].xyz);
    var out: BoxOut;
    out.id = id;
    out.position = params.view_proj * vec4(box_corner(o, box_sections[id].a.z, box_triangle_corner(v)), 1.0);
    return out;
}

// Seen at this fragment, which runs only where the depth test passes (forced
// before it: a fragment that failed would still write). Every writer stores
// the same stamp.
@fragment
@early_depth_test(force)
fn fs_box(in: BoxOut) -> @location(0) vec4<f32> {
    let at = in.id * RUN_WORDS + SEEN_WORD;
    if box_runs[at] != params.occl.x {
        box_runs[at] = params.occl.x;
    }
    return vec4(0.0);
}

var<workgroup> tally: array<atomic<u32>, 3>;

// After the test, one workgroup per block of ids: the quads of the sections
// with runs, the tested boxes not seen and their quads, and per (page, band)
// each block's draws that phase 2 makes (`drawn_in`'s condition).
@compute @workgroup_size(64)
fn count2(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {
    if lane < 3u {
        atomicStore(&tally[lane], 0u);
    }
    if lane < FAST_BUCKETS {
        atomicStore(&wg_buckets[lane], 0u);
    }
    workgroupBarrier();
    let block = group.y * ROW + group.x;
    let id = block * BLOCK + lane;
    if id < params.ids {
        let at = id * RUN_WORDS;
        let w = runs[at];
        let n = w & 7u;
        if n > 0u {
            var quads = 0u;
            for (var k = 0u; k < n; k++) {
                quads += runs[at + 2u + 2u * k];
            }
            atomicAdd(&tally[0], quads);
            let saw = runs[at + SEEN_WORD] == params.occl.x;
            if (w & TESTED) != 0u && !saw {
                atomicAdd(&tally[1], 1u);
                atomicAdd(&tally[2], quads);
            }
            if (w & PHASE2) != 0u && saw {
                let page = w >> PAGE_SHIFT;
                let band = (w >> BAND_SHIFT) & BAND_MASK;
                if page < FAST_PAGES {
                    atomicAdd(&wg_buckets[page * BANDS + band], n);
                } else {
                    atomicAdd(&counts[block_count(block, page, band, 1u)], n);
                }
            }
        }
    }
    workgroupBarrier();
    if lane == 0u {
        let q = atomicLoad(&tally[0]);
        if q > 0u {
            atomicAdd(&counts[QUADS], q);
        }
        let h = atomicLoad(&tally[1]);
        if h > 0u {
            atomicAdd(&counts[HIDDEN], h);
        }
        let hq = atomicLoad(&tally[2]);
        if hq > 0u {
            atomicAdd(&counts[HIDDEN_QUADS], hq);
        }
    }
    if lane < FAST_BUCKETS {
        let count = atomicLoad(&wg_buckets[lane]);
        if count > 0u {
            let page = lane / BANDS;
            let band = lane % BANDS;
            let blocks = (params.ids + BLOCK - 1u) / BLOCK;
            atomicStore(&counts[block_base(page, band, 1u, blocks) + block], count);
        }
    }
}

@compute @workgroup_size(256)
fn scan2(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {
    scan_page(group.x, lane, 1u);
}

@compute @workgroup_size(64)
fn scatter2(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lane: u32) {
    scatter_block(group.y * ROW + group.x, lane, 1u);
}
