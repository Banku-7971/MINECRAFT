//! The material stage of Horizon's own shader packs (docs/shaders.md): the pack's `material`
//! function gives the lit colour of each point of a block's surface, before the alpha test and
//! fog. Terrain still draws with Horizon's meshes, culling and draw lists; only its pipelines
//! change. Their shader is the pack's stage (`CheckedStage::source`), then a copy of
//! terrain.wgsl's terrain section whose names all take a `horizon_terrain_` prefix
//! (`wgsl_prefix.rs`), then entries that hand the pack what vanilla's `fs_solid` and
//! `fs_translucent` combine: the texture, the vertex tint, the light levels and the lightmap's
//! colour. They read the terrain's group 0, the flat draws' group 1 where those run, and the
//! pack's frame at group 3.

use horizon_shader_api::{check::CheckedStage, stages::GROUP};

use super::displace::{Displacement, MAX_SECTIONS};
use super::external::{DisplacementPrepare, Near, OpaqueCopy, TerrainLayers};
use super::native_post::kept::StageReads;
use super::native_post::trace::{TerrainTrace, TraceShape, Traced};
use super::native_post::{NativeFrame, NativePost, present_constants};
use super::wgsl_prefix::{TERRAIN, prefixed, section};

const PREFIX: &str = "horizon_terrain_";

/// The entries around the pack's `material`: vanilla's vertex work without the lightmap
/// product, then the material, the alpha test and fog as `fs_solid` and `fs_translucent` do.
const ENTRIES: &str = "
// The manifest's `[frame] fog`: false when the pack fogs what it draws itself.
override horizon_material_fog: bool = true;
fn horizon_material_fogged(color: vec4<f32>, spherical: f32, cylindrical: f32) -> vec4<f32> {
    if horizon_material_fog {
        // In vanilla's gamma, as vanilla mixes it: on a frame of linear light, encoded for it.
        let gamma = horizon_terrain_frame_gamma(color);
        return horizon_terrain_frame_stored(horizon_terrain_apply_fog(gamma, spherical, cylindrical));
    }
    return color;
}
// The manifest's `[material] coverage`: true for `pack`, where the stage's returned
// alpha cuts the holes; else the texture's own alpha does, as on Horizon's terrain, and the
// returned alpha is only translucent terrain's opacity.
override horizon_material_coverage_pack: bool = false;
fn horizon_material_covers(in: HorizonMaterialOut, color: vec4<f32>, cutoff: f32) -> bool {
    if horizon_material_coverage_pack {
        return color.a >= cutoff;
    }
    return horizon_terrain_sprite(in.uv, in.layer & 0x7fffu).a >= cutoff;
}
struct HorizonMaterialOut {
    @builtin(position) clip: vec4<f32>,
    @location(0) uv: vec2<f32>,
    @location(1) @interpolate(flat) layer: u32,
    // rgb the vertex colour (vanilla's product of the tint, the shade and the ambient
    // occlusion), alpha the corner's ambient occlusion (`horizon_look_ao`).
    @location(2) tint: vec4<f32>,
    @location(3) light: vec2<f32>,
    @location(4) lightmap: vec3<f32>,
    @location(5) position: vec3<f32>,
    @location(6) spherical: f32,
    @location(7) cylindrical: f32,
    // From the quad's look: bits 0..2 the face, bit 3 a fluid quad, bits 4..6 the shade's code
    // (0: no look), bits 8..11 the light level the surface gives off; from the vertex, bits 12..14
    // its light-source code (terrain.wgsl's `emission`, `horizon_material_light_tier`).
    @location(8) @interpolate(flat) look: u32,
    // The look's tint, 0xBBGGRR.
    @location(9) @interpolate(flat) look_tint: u32,
    // How far the section's fade-in is from whole, of 65535 (`horizon_material_faded`).
    @location(10) @interpolate(flat) fade: u32,
    // The point on the flat face (`position` without `[displacement]`'s relief), how much of
    // that relief it has (`MaterialInput.displaced`) and the face's normal (0 when the
    // fragment finds it).
    @location(12) base: vec3<f32>,
    @location(13) displaced: f32,
    @location(14) @interpolate(flat) normal: vec3<f32>,@lit_varying@
}@lit_fn@
// `slot`: the corner's in the arena page, whose look is its quad's (`horizon_look`).
fn horizon_material_vertex(position: vec3<f32>, uv: vec2<f32>, layer: u32, color: vec4<f32>,
    light: vec2<u32>, origin: vec4<f32>, slot: u32, corner: u32) -> HorizonMaterialOut {
    let look = horizon_look(slot);
    let ao = horizon_look_ao(look, corner);
    let pos = horizon_material_displace(position + origin.xyz, uv, layer, color, light, look, ao);
    var out = horizon_material_out(pos, uv, layer, color, vec2<f32>(light), look, ao);
    // The section's fade-in (`RenderSection.getVisibility`), as how far it is from whole: 0
    // (whole) where nothing fades. It is the same for the whole section, so the flat varying
    // loses nothing.
    let instance = horizon_terrain_instance_visibility(origin.w);
    out.fade = u32(round((1.0 - instance) * 65535.0));
    return out;
}
// terrain.wgsl's fade-in (terrain.vsh's chunkVisibility): whole within 16 blocks, the section's
// own visibility from 32 out, toward the fog colour, alpha kept. The distance blend runs here on
// the interpolated distance, as vanilla's interpolated `visibility`, not once per triangle. In
// vanilla's gamma, as the fog: on a frame of linear light, encoded for it.
fn horizon_material_faded(in: HorizonMaterialOut, color: vec4<f32>) -> vec4<f32> {
    let instance = 1.0 - f32(in.fade) / 65535.0;
    let visibility = mix(1.0, instance, clamp((in.spherical - 16.0) / 16.0, 0.0, 1.0));
    let gamma = horizon_terrain_frame_gamma(color);
    let faded = mix(horizon_terrain_globals.fog_color.rgb, gamma.rgb, visibility);
    return horizon_terrain_frame_stored(vec4(faded, color.a));
}
// `light`: sky, block, 16 per level. `look` the quad's, `ao` the point's (`horizon_look_ao`).
fn horizon_material_out(pos: vec3<f32>, uv: vec2<f32>, layer: u32, color: vec4<f32>,
    light: vec2<f32>, look: vec2<u32>, ao: f32) -> HorizonMaterialOut {
    var out: HorizonMaterialOut;
    out.clip = horizon_terrain_globals.view_proj * vec4(pos, 1.0);
    out.uv = uv;
    out.layer = layer;
    out.tint = vec4(color.rgb, ao);
    let block = max(light.y, horizon_terrain_dynamic_block_light(pos));
    let sky = light.x;
    // 16 per level, 15 levels.
    out.light = min(vec2(block, sky) / 240.0, vec2(1.0));
    out.lightmap = horizon_terrain_sample_lightmap(sky / 16.0, block / 16.0).rgb;
    out.position = pos;
    out.spherical = length(pos);
    out.cylindrical = max(length(pos.xz), abs(pos.y));
    // The colour's alpha byte (mesher.rs's `emitting`): bit 3 clear on a fluid quad, the high
    // nibble 15 minus the light level. Every corner of a quad carries the same byte, so the
    // interpolated value rounds back exactly.
    let flags = u32(round(color.a * 255.0));
    let fluid = (flags & 8u) == 0u;
    let code = (look.x >> 24u) & 7u;
    let level = 15u - (flags >> 4u);
    let tier = 7u - (flags & 7u);
    out.look = ((look.x >> 27u) & 7u) | u32(fluid) << 3u | code << 4u | level << 8u | tier << 12u;
    out.look_tint = look.x & 0xffffffu;
    out.base = pos;
    out.displaced = 0.0;
    out.normal = vec3(0.0);@lit_out@
    return out;
}
// A vertex's index is its slot in the arena page, and a quad's four come in order.
@vertex fn horizon_material_vs(@builtin(vertex_index) vertex: u32,
    @location(0) position: vec3<f32>, @location(1) uv: vec2<u32>,
    @location(2) layer: u32, @location(3) color: vec4<f32>, @location(4) light: vec2<u32>,
    @location(5) origin: vec4<f32>) -> HorizonMaterialOut {
    return horizon_material_vertex(position, horizon_terrain_terrain_uv(uv, origin.w), layer,
        color, light, origin, vertex, vertex & 3u);
}
@vertex fn horizon_material_vs_flat(
    @builtin(vertex_index) vertex: u32,
    @location(0) position: vec3<f32>, @location(1) uv: vec2<u32>,
    @location(2) layer: u32, @location(3) color: vec4<f32>, @location(4) light: vec2<u32>
) -> HorizonMaterialOut {
    let origin = horizon_terrain_slot_origins[horizon_terrain_block_slots[vertex >> 6u]];
    return horizon_material_vertex(position, horizon_terrain_terrain_uv(uv, origin.w), layer,
        color, light, origin, vertex, vertex & 3u);
}
// Solid draws reading the arena page (`SECTION_CORNER`), in either layout of the solid quads.
fn horizon_material_corner(s: horizon_terrain_SectionCorner, vertex: u32, origin: vec4<f32>)
    -> HorizonMaterialOut {
    let c = horizon_terrain_corner_inputs(s.c);
    return horizon_material_vertex(c.position, horizon_terrain_terrain_uv(c.uv, origin.w), c.layer,
        c.color, c.light, origin, s.slot, vertex & 3u);
}
@vertex fn horizon_material_vs_section(@builtin(vertex_index) vertex: u32,
    @location(5) origin: vec4<f32>) -> HorizonMaterialOut {
    return horizon_material_corner(horizon_terrain_section_corner(vertex), vertex, origin);
}
@vertex fn horizon_material_vs_section_flat(@builtin(vertex_index) vertex: u32)
    -> HorizonMaterialOut {
    let s = horizon_terrain_section_corner(vertex);
    return horizon_material_corner(s, vertex, horizon_corner_origin(s));
}
// The prelude's `block_texture`: a sprite of the terrain's arrays at a mip level.
fn horizon_block_size() -> vec2<f32> {
    return vec2<f32>(textureDimensions(horizon_terrain_sprites).xy);
}
fn horizon_block_sample(uv: vec2<f32>, layer: u32, lod: f32) -> vec4<f32> {
    let s = horizon_terrain_sprite_sampler;
    let l = i32(layer % horizon_terrain_SPRITE_SPLIT);
    switch layer / horizon_terrain_SPRITE_SPLIT {
        case 0u: { return textureSampleLevel(horizon_terrain_sprites, s, uv, l, lod); }
        case 1u: { return textureSampleLevel(horizon_terrain_sprites_1, s, uv, l, lod); }
        case 2u: { return textureSampleLevel(horizon_terrain_sprites_2, s, uv, l, lod); }
        case 3u: { return textureSampleLevel(horizon_terrain_sprites_3, s, uv, l, lod); }
        case 4u: { return textureSampleLevel(horizon_terrain_sprites_4, s, uv, l, lod); }
        case 5u: { return textureSampleLevel(horizon_terrain_sprites_5, s, uv, l, lod); }
        case 6u: { return textureSampleLevel(horizon_terrain_sprites_6, s, uv, l, lod); }
        default: { return textureSampleLevel(horizon_terrain_sprites_7, s, uv, l, lod); }
    }
}
fn horizon_material_color(in: HorizonMaterialOut, translucent: bool) -> vec4<f32> {
    let albedo = horizon_terrain_sprite(in.uv, in.layer & 0x7fffu);
    horizon_block_layer = in.layer & 0x7fffu;
    // The mip level of this point in the texture: its texels, as the sampler would pick.
    let texels = in.uv * horizon_block_size();
    let footprint = max(dot(dpdx(texels), dpdx(texels)), dot(dpdy(texels), dpdy(texels)));
    horizon_block_lod = max(0.5 * log2(max(footprint, 1e-8)), 0.0);
    // Water draws translucent and lava solid, so the pass resolves the fluid kind.
    let fluid = select(0u, select(2u, 1u, translucent), (in.look & 8u) != 0u);
    // Without a look the vertex colour is the tint, with its shade and ambient occlusion in it.
    let code = (in.look >> 4u) & 7u;
    let tint = select(in.tint.rgb, unpack4x8unorm(in.look_tint).rgb, code != 0u);
    let horizon_shaded = vec4(horizon_line_in(in.tint.rgb), 1.0);
    // `[displacement]`'s grid hands down its face's normal: its relief is the pack's to shade.
    let normal = select(horizon_material_normal(in.position), in.normal,
        dot(in.normal, in.normal) > 0.5);
    horizon_material_face_normal = normal;
    horizon_surface = vec4<f32>(0.0);
    let tangent = horizon_material_tangent(in.base, in.uv, normal);
    let out = material(MaterialInput(vec4(horizon_line_in(albedo.rgb), albedo.a),
        vec4(horizon_line_in(tint), 1.0), horizon_line_in(vec3(horizon_look_shade(code))).x,
        horizon_line_in(vec3(in.tint.a)).x, in.light, horizon_line_in(in.lightmap),
        in.position, in.uv, translucent, horizon_sprite_tags(in.layer & 0x7fffu),
        horizon_sprite_material(in.layer & 0x7fffu), in.clip.xy / frame.resolution,
        in.look & 7u, fluid, f32((in.look >> 8u) & 15u) / 15.0, normal, tangent,
        horizon_line_in(horizon_terrain_native_colored_light(in.position)),
        in.displaced@light_source@@lit_tint@@shaded_tint@)).color;
    return vec4(horizon_line_out(out.rgb), out.a);
}
// `MaterialInput.light_source_tier` and `light_source_whole` from the vertex's light-source code
// (`look` bits 12..14), as terrain.wgsl's `solid_finish_at` reads its `emission`: 1..4 a tier,
// 5..7 tiers 1..3 shining whole.
fn horizon_material_light_tier(look: u32) -> u32 {
    let code = (look >> 12u) & 7u;
    return select(code, code - 4u, code > 4u);
}
fn horizon_material_light_whole(look: u32) -> bool {
    return ((look >> 12u) & 7u) > 4u;
}
// `MaterialInput.light_source_threshold`: the sprite's, as `solid_finish_at` reads it.
fn horizon_material_light_threshold(layer: u32) -> f32 {
    let l = layer & 0x7fffu;
    let at = vec2(i32(l % horizon_terrain_SPRITE_SPLIT), i32(l / horizon_terrain_SPRITE_SPLIT));
    return textureLoad(horizon_terrain_emission_thresholds, at, 0).r;
}
var<private> horizon_material_face_normal: vec3<f32>;
struct HorizonMaterialSolid {
    @location(0) color: vec4<f32>,
    // The surface target's data: `set_surface`'s, then the fragment's depth, which the post
    // stage's `surface_at` compares with the final depth.
    // Its four floats' bits (`SURFACE_FORMAT` is an integer format).
    @location(1) surface: vec4<u32>,
}
struct HorizonMaterialMsaa {
    @location(0) color: vec4<f32>,
    @location(1) surface: vec4<u32>,
    @builtin(sample_mask) coverage: u32,
}
var<private> horizon_material_coverage: u32;
@fragment fn horizon_material_fs_msaa(in: HorizonMaterialOut) -> HorizonMaterialMsaa {
    let solid = horizon_material_solid_sampled(in, true);
    return HorizonMaterialMsaa(solid.color, solid.surface, horizon_material_coverage);
}
@fragment fn horizon_material_fs_solid(in: HorizonMaterialOut) -> HorizonMaterialSolid {
    // `[displacement]`'s grid draws these pixels.
    if length(in.base) < horizon_displace_distance - 0.05 && horizon_displaced_layer(in.layer) {
        discard;
    }
    return horizon_material_solid(in);
}
fn horizon_material_solid(in: HorizonMaterialOut) -> HorizonMaterialSolid {
    return horizon_material_solid_sampled(in, false);
}
// Multisampled, the cutout leaves the samples it covers (`horizon_material_coverage`) instead
// of discarding.
fn horizon_material_solid_sampled(in: HorizonMaterialOut, multisampled: bool) -> HorizonMaterialSolid {
    let color = horizon_material_faded(in, horizon_material_color(in, false));
    // Bit 15 of the layer marks opaque leaves (forceOpaque): no alpha cutout.
    if multisampled {
        // The alpha `horizon_material_covers` cuts on, as the samples it covers.
        let alpha = select(horizon_terrain_sprite(in.uv, in.layer & 0x7fffu).a, color.a,
            horizon_material_coverage_pack);
        horizon_material_coverage = horizon_terrain_cutout_coverage(alpha, (in.layer & 0x8000u) != 0u);
    } else if !horizon_material_covers(in, color, 0.5) && (in.layer & 0x8000u) == 0u { discard; }
    if horizon_surface.w == 0.0 {
        set_surface(horizon_material_face_normal, 0.0, 0.0);
    }
    var out: HorizonMaterialSolid;
    out.color = horizon_material_fogged(vec4(color.rgb, 1.0), in.spherical, in.cylindrical);
    out.surface = bitcast<vec4<u32>>(vec4(horizon_surface.xyz, in.clip.z));
    return out;
}
@fragment fn horizon_material_fs_translucent(in: HorizonMaterialOut) -> @location(0) vec4<f32> {
    let color = horizon_material_faded(in, horizon_material_color(in, true));
    if !horizon_material_covers(in, color, 0.01) { discard; }
    return horizon_material_fogged(color, in.spherical, in.cylindrical);
}
";

/// A solid draw's corner read from the arena page, a vertex's words or its quad's compact record
/// (terrain.wgsl's `section_corner`), decoded by the engine's own `corner_inputs`: the material's
/// and the shadow pass's solid entries take the engine's inputs from either layout. And what
/// they take from a quad's look (`horizon_look`, `mesher::QuadLook`), whose shade code is 0
/// where the quad has none: its shade as a ray hit's (`stages::look_shade`).
pub(super) fn section_corner() -> String {
    let shade = horizon_shader_api::stages::look_shade("horizon_look_shade");
    format!("\n// `mesher::SHADES` by code; 1 for none.\n{shade}{SECTION_CORNER}")
}

/// `section_corner` after the shade.
const SECTION_CORNER: &str = "\
// Corner `corner`'s ambient occlusion, 0..1 as vanilla's vertex colour holds it; 1 without a look.
fn horizon_look_ao(look: vec2<u32>, corner: u32) -> f32 {
    if ((look.x >> 24u) & 7u) == 0u {
        return 1.0;
    }
    return f32((look.y >> (8u * corner)) & 255u) / 255.0;
}
// `horizon_terrain_corner_inputs` gives a corner's colour as the engine's own terrain converts
// it (`unorm8x4`), which on some devices (NVIDIA) differs from the vertex fetch by one 1/255
// step for some bytes: a pack's material and shadow see the engine's colours.
alias HorizonCorner = horizon_terrain_CornerInputs;
// A flat draw's origin of the corner: its block's slot's.
fn horizon_corner_origin(s: horizon_terrain_SectionCorner) -> vec4<f32> {
    return horizon_terrain_slot_origins[horizon_terrain_block_slots[s.slot >> 6u]];
}
";

/// `[displacement]`'s grid (gfx/displace.rs): one instance a quad the pick chose, its corners
/// read from the copy of the arena, each of its cells two triangles moved along the face's
/// normal by the pack's `displacement`, measured from the texture's mean height so that the
/// face's edges, pinned there, meet their neighbours whatever their relief.
const DISPLACED_ENTRIES: &str = "
@vertex fn horizon_material_vs_displaced(@builtin(vertex_index) v: u32,
    @builtin(instance_index) instance: u32) -> HorizonMaterialOut {
    let p = horizon_displace_point(v, instance);
    var out = horizon_material_out(p.position, p.uv, p.layer, p.color, p.light, p.look, p.ao);
    out.base = p.base;
    out.displaced = p.near;
    out.normal = p.normal;@lit_displaced@
    return out;
}
@fragment fn horizon_material_fs_displaced(in: HorizonMaterialOut) -> HorizonMaterialSolid {
    if length(in.base) >= horizon_displace_distance + 0.05 {
        discard;
    }
    return horizon_material_solid(in);
}
";

/// What the material's displaced pipeline is built against: `[displacement]`'s values and
/// its group 1.
pub struct DisplacedShape<'a> {
    pub distance: f32,
    pub cells: u32,
    pub steps: bool,
    pub layout: &'a wgpu::BindGroupLayout,
}

/// What terrain pipelines are built against: the renderer's layouts and constants.
pub struct TerrainShape<'a> {
    /// The terrain's group 0.
    pub globals: &'a wgpu::BindGroupLayout,
    /// The flat draws' group 1, where they run (`flat.rs`).
    pub flat: Option<&'a wgpu::BindGroupLayout>,
    /// terrain.wgsl's `SPRITE_ARRAYS` and `SPRITE_SPLIT`.
    pub sprites: [f64; 2],
    /// terrain.wgsl's sprite arrays, the unused ones a stand-in: what a `[ray_tracing]` pack's
    /// `trace` reads a hit's texture from.
    pub sprite_views: &'a [wgpu::TextureView],
    /// The world target's colour format, and whether it holds linear light (`linear_blend`).
    pub format: wgpu::TextureFormat,
    pub linear: bool,
    /// The renderer was made with 4x MSAA on (`msaa::Msaa::built`): the pack's solid terrain
    /// gets four-sample pipelines too.
    pub msaa: bool,
    /// The pack's tags of each tagged sprite layer, as `(layer, bits)`
    /// (`Manifest::sprite_tags`).
    pub sprite_tags: &'a [(u32, u32)],
    /// The pack's material id of each sprite layer with one, as `(layer, id)`
    /// (`Manifest::sprite_materials`).
    pub sprite_materials: &'a [(u32, u32)],
    /// The entities' group 0 (their atlas), for the shadow pass's entity draw and the entity
    /// stage, and the retained block entities' group 1 (their place), for that stage.
    pub entities: &'a wgpu::BindGroupLayout,
    pub retained_entities: &'a wgpu::BindGroupLayout,
    /// The weather's groups 0 and 1 (the entities' atlas, the fall clock), for the weather
    /// stage.
    pub weather_groups: [&'a wgpu::BindGroupLayout; 2],
    /// The resource packs' LabPBR maps (normals, specular), when they ship any.
    pub pbr: Option<&'a [wgpu::Texture; 2]>,
    /// The arenas' quad looks' group (`looks`), while sections carry them (`looks::wanted`).
    pub looks: Option<&'a wgpu::BindGroupLayout>,
}

/// The pack's terrain pipelines: solid (with the cutout test) and translucent, for the
/// renderer's instanced draws and, where they run, its flat ones.
pub struct MaterialPipelines {
    pub solid: wgpu::RenderPipeline,
    pub translucent: wgpu::RenderPipeline,
    pub flat: Option<(wgpu::RenderPipeline, wgpu::RenderPipeline)>,
    /// `solid` and the flat solid pipeline at four samples, for 4x MSAA; none with
    /// `[displacement]`, which keeps its single-sample path.
    pub msaa: Option<(wgpu::RenderPipeline, Option<wgpu::RenderPipeline>)>,
    /// `[displacement]`'s grid of the solid terrain near the camera (gfx/displace.rs).
    pub displaced: Option<wgpu::RenderPipeline>,
}

/// A pack's material stage: its terrain pipelines, and for a stage that calls `trace` or
/// `trace_any`, where the device takes the scene, the same against the scene.
pub struct NativeMaterial {
    /// Built with a `trace` that misses: every device, every frame without the scene.
    pub pipelines: MaterialPipelines,
    pub(super) scene: Option<TerrainTrace>,
    /// The stage calls `set_surface`: its solid pipelines also write the surface target.
    pub writes_surface: bool,
    /// `[material] reads`: none without.
    pub(super) kept: Option<StageReads>,
}

/// terrain.wgsl's group 0 (`TerrainShape::globals`): its globals, the sprite arrays and their
/// sampler, the lightmap and its sampler, the emission thresholds.
pub(super) fn terrain_entries() -> Vec<wgpu::BindGroupLayoutEntry> {
    let entry = |binding, ty| wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
        ty,
        count: None,
    };
    let texture = |view_dimension| wgpu::BindingType::Texture {
        sample_type: wgpu::TextureSampleType::Float { filterable: true },
        view_dimension,
        multisampled: false,
    };
    let sampler = wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering);
    let sprite_array = texture(wgpu::TextureViewDimension::D2Array);
    let globals = wgpu::BindingType::Buffer {
        ty: wgpu::BufferBindingType::Uniform,
        has_dynamic_offset: false,
        min_binding_size: None,
    };
    let mut entries = vec![
        entry(0, globals),
        entry(1, sprite_array),
        entry(2, sampler),
        entry(3, texture(wgpu::TextureViewDimension::D2)),
        entry(4, sampler),
    ];
    entries.extend((5..=11).map(|binding| entry(binding, sprite_array)));
    entries.push(entry(12, texture(wgpu::TextureViewDimension::D2)));
    // The arrays past the first eight, where a pack needs them (gfx.rs `MORE_SPRITE_ARRAYS`).
    let more = super::bound_sprite_arrays().saturating_sub(super::SPRITE_ARRAYS);
    entries.extend((0..more).map(|i| entry(super::MORE_ARRAYS_BINDING + i, sprite_array)));
    entries
}

/// terrain.wgsl's terrain section (its globals, bindings, sampling, lighting and fog), with
/// every name it declares prefixed.
fn vanilla_terrain() -> String {
    prefixed(
        &(super::wgsl_prefix::HDR_LIGHT.to_owned()
            + section(TERRAIN, "struct Globals {", "// Sky (SkyRenderer)")),
        PREFIX,
    )
}

/// The function `name(layer)`, the value of each sprite layer in `table` and 0 for the rest:
/// `horizon_sprite_tags` (`MaterialInput.tags`) and `horizon_sprite_material`
/// (`MaterialInput.material`).
pub(super) fn layer_table(name: &str, table: &[(u32, u32)]) -> String {
    let mut out = format!("fn {name}(layer: u32) -> u32 {{\n    switch layer {{\n");
    let mut table = table.to_vec();
    table.sort_unstable_by_key(|&(layer, value)| (value, layer));
    for group in table.chunk_by(|a, b| a.1 == b.1) {
        let layers: Vec<String> = group.iter().map(|(layer, _)| format!("{layer}u")).collect();
        out += &format!(
            "        case {}: {{ return {}u; }}\n",
            layers.join(", "),
            group[0].1
        );
    }
    out + "        default: { return 0u; }\n    }\n}\n"
}

/// Where a corner of terrain is drawn without a vertex stage.
pub(super) const DISPLACE_VANILLA: &str = "
fn horizon_material_displace(pos: vec3<f32>, uv: vec2<f32>, layer: u32, color: vec4<f32>,
    light: vec2<u32>, look: vec2<u32>, ao: f32) -> vec3<f32> {
    return pos;
}
";

/// The vertex stage's call, with its inputs from terrain's vertex and its quad's `look` (`ao`
/// the corner's, `horizon_look_ao`). `horizon_material_translucent`: the pipeline draws the
/// translucent pass, where a fluid is water (lava is solid). `stages::shaded_entries` fills in
/// `shaded_tint`.
pub(super) const DISPLACE_PACK: &str = "
override horizon_material_translucent: bool = false;
fn horizon_material_displace(pos: vec3<f32>, uv: vec2<f32>, layer: u32, color: vec4<f32>,
    light: vec2<u32>, look: vec2<u32>, ao: f32) -> vec3<f32> {
    let fluid = (u32(round(color.a * 255.0)) & 8u) == 0u;
    let lit = min(vec2(f32(light.y), f32(light.x)) / 240.0, vec2(1.0));
    let code = (look.x >> 24u) & 7u;
    let tint = select(color.rgb, unpack4x8unorm(look.x).rgb, code != 0u);
    let face = (look.x >> 27u) & 7u;
    let kind = select(0u, select(2u, 1u, horizon_material_translucent), fluid);
    let horizon_shaded = vec4(horizon_line_in(color.rgb), 1.0);
    return vertex(VertexInput(pos, uv, horizon_sprite_material(layer & 0x7fffu), lit,
        vec4(horizon_line_in(tint), 1.0), horizon_line_in(vec3(horizon_look_shade(code))).x,
        horizon_line_in(vec3(ao)).x, face, kind@shaded_tint@));
}
";

/// The surface target (the post stage's `scene_surface`): the bits of four floats, x the normal
/// (two snorm16 in its bits), y smoothness, z the pack's data, w the fragment's depth. Stored
/// as unsigned integers, not `Rgba32Float`: RGBA32UI is colour-renderable on every backend,
/// where OpenGL (GLES 3 semantics) refuses RGBA32F as a render attachment, and integers keep
/// the packed normal's bits exact.
pub const SURFACE_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba32Uint;

/// What a pack whose files name `lit_tint` (`CheckedStage::lit_tint`) has at each mark of the
/// terrain's shader (`ENTRIES`, `DISPLACED_ENTRIES`, `displace::GRID`), and one that doesn't
/// lacks, so that its shader is the text it was before the field: the varying, in the location
/// the others leave free (the terrain's 15th, the last the weakest GPUs have), set at each
/// corner as terrain.wgsl's `terrain_vertex` lights its colour, and on `[displacement]`'s grid
/// between the face's corners' as the grid's colour is.
const LIT_MARKS: [(&str, &str); 8] = [
    (
        "@lit_varying@",
        "
    // `MaterialInput.lit_tint`: the vertex colour lit at each corner (`horizon_material_lit`).
    @location(11) lit_tint: vec3<f32>,",
    ),
    (
        "@lit_fn@",
        "
// The vertex colour `color` lit at a corner as terrain.wgsl's `terrain_vertex` lights it, in
// vanilla's gamma: by the lightmap at its `light` (sky, block, 16 per level) and Horizon's
// dynamic block light, and by the coloured lights at `pos` under it.
fn horizon_material_lit(pos: vec3<f32>, color: vec3<f32>, light: vec2<f32>) -> vec3<f32> {
    let block = max(light.y, horizon_terrain_dynamic_block_light(pos));
    var lit = color * horizon_terrain_sample_lightmap(light.x / 16.0, block / 16.0).rgb;
    if horizon_terrain_globals.colored_count.x > 0u {
        lit = min(lit + color * horizon_terrain_native_colored_light(pos), vec3(1.0));
    }
    return lit;
}",
    ),
    (
        "@lit_out@",
        "
    out.lit_tint = horizon_material_lit(pos, color.rgb, light);",
    ),
    ("@lit_displaced@", "\n    out.lit_tint = p.lit;"),
    (
        "@lit_point@",
        "
    // The lit vertex colour (`horizon_material_lit`), between the corners'.
    lit: vec3<f32>,",
    ),
    (
        "@lit_corners@",
        "
// The lit vertex colour at (`s`, `t`) of a quad, between its corners' as the colour is.
fn horizon_displace_lit(c0: HorizonDisplaceCorner, c1: HorizonDisplaceCorner,
    c2: HorizonDisplaceCorner, c3: HorizonDisplaceCorner, origin: vec3<f32>, s: f32, t: f32)
    -> vec3<f32> {
    let l0 = horizon_material_lit(c0.position + origin, c0.color.rgb, c0.light);
    let l1 = horizon_material_lit(c1.position + origin, c1.color.rgb, c1.light);
    let l2 = horizon_material_lit(c2.position + origin, c2.color.rgb, c2.light);
    let l3 = horizon_material_lit(c3.position + origin, c3.color.rgb, c3.light);
    return mix(mix(l0, l1, s), mix(l3, l2, s), t);
}",
    ),
    (
        "@lit_grid@",
        "\n    p.lit = horizon_displace_lit(c0, c1, c2, c3, section.origin.xyz, s, t);",
    ),
    (
        "@lit_step@",
        "\n    p.lit = horizon_displace_lit(q.c0, q.c1, q.c2, q.c3, q.origin, s, t);",
    ),
];

/// `text` with the marks of `lit_tint` (`LIT_MARKS`) filled in where `lit`, removed where not.
/// Only Horizon's own text: a pack's source is left as written.
pub(super) fn lit_marks(text: &str, lit: bool) -> String {
    let mut out = text.to_owned();
    for (mark, wgsl) in LIT_MARKS {
        out = out.replace(mark, if lit { wgsl } else { "" });
    }
    out
}

/// What `MaterialInput.lit_tint` takes in a pack that names it (`CheckedStage::lit_tint`).
const LIT_TINT: &str = ", horizon_line_in(in.lit_tint)";

/// What `MaterialInput`'s light-source fields take in a pack that names them
/// (`CheckedStage::light_source`).
const LIGHT_SOURCE: &str = ", horizon_material_light_tier(in.look), \
    horizon_material_light_whole(in.look), horizon_material_light_threshold(in.layer)";

/// The terrain shader for the pack's material stage `source`, with its sprite `tags` and
/// `materials`, the vertex stage in its module when `vertex`, its inputs' `shaded_tint` where
/// `shaded` (`CheckedStage::shaded_tint`), their light-source fields where `light`
/// (`CheckedStage::light_source`) and `lit_tint` with its varying where `lit`
/// (`CheckedStage::lit_tint`).
fn shader_source(
    source: &str,
    tags: &[(u32, u32)],
    materials: &[(u32, u32)],
    (vertex, displaced, shaded, light, lit): Inputs,
    linear: bool,
) -> String {
    let shaded = |text: &str| {
        let text = horizon_shader_api::stages::shaded_entries(text, shaded);
        let text = horizon_shader_api::stages::lit_entries(&text, lit.then_some(LIT_TINT));
        let text =
            horizon_shader_api::stages::light_source_entries(&text, light.then_some(LIGHT_SOURCE));
        lit_marks(&text, lit)
    };
    // The LabPBR maps in the frame's group, read by the prelude's `block_normal_map` and its
    // kin, and by a tracing stage's `hit_normal_map`.
    let pbr = horizon_shader_api::stages::PBR_MAPS_TERRAIN;
    format!(
        "{source}\n// Horizon's terrain (terrain.wgsl)\n{}{}{}{}{}{}{}{pbr}{}{}",
        vanilla_terrain(),
        super::native_post::line_helpers(linear),
        if vertex {
            shaded(DISPLACE_PACK)
        } else {
            DISPLACE_VANILLA.to_owned()
        },
        layer_table("horizon_sprite_tags", tags),
        layer_table("horizon_sprite_material", materials),
        section_corner(),
        shaded(ENTRIES),
        super::displace::RELIEF,
        if displaced {
            lit_marks(&(super::displace::GRID.to_owned() + DISPLACED_ENTRIES), lit)
        } else {
            String::new()
        }
    )
}

/// What a material's terrain shader is built with (`shader_source`): the vertex stage in its
/// module, `[displacement]`'s grid, and its inputs' `shaded_tint`, light-source fields and
/// `lit_tint`.
type Inputs = (bool, bool, bool, bool, bool);

/// The material's naga module from the stage's `source` (`CheckedStage::source` or
/// `scene_source`), its errors in the stage's `file`.
fn module(
    (source, file): (&str, &str),
    tags: &[(u32, u32)],
    materials: &[(u32, u32)],
    inputs: Inputs,
    linear: bool,
) -> Result<naga::Module, String> {
    let text = shader_source(source, tags, materials, inputs, linear);
    naga::front::wgsl::parse_str(&text).map_err(|e| format!("{file}: {}", e.emit_to_string(&text)))
}

impl NativeMaterial {
    /// The pipelines of the pack's material `stage` with the option values `constants`.
    pub(in crate::gfx) fn new(
        device: &wgpu::Device,
        shape: &TerrainShape<'_>,
        frame: &NativeFrame,
        stage: &CheckedStage,
        constants: &[(String, f64)],
        fog: bool,
        coverage: horizon_shader_api::Coverage,
        vertex: bool,
        displaced: Option<&DisplacedShape<'_>>,
        kept: Option<StageReads>,
    ) -> Result<Self, String> {
        let writes_surface = horizon_shader_api::stages::calls_set_surface(&stage.source);
        let linear = frame.linear;
        let build = |source: &str, group: &wgpu::BindGroupLayout| {
            let flags = (fog, vertex, writes_surface, coverage);
            let terrain = (shape, displaced, constants);
            Self::pipelines(device, terrain, (stage, source), group, flags, linear)
        };
        let limits = device.limits();
        if let Some(why) = (kept.as_ref()).and_then(|k| k.over(frame, &terrain_entries(), &limits))
        {
            return Err(format!("{}: {why}", stage.file));
        }
        let validation = device.push_error_scope(wgpu::ErrorFilter::Validation);
        let internal = device.push_error_scope(wgpu::ErrorFilter::Internal);
        let built = build(
            &stage.source,
            kept.as_ref().map_or(&frame.layout, |k| &k.layout),
        );
        let internal = pollster::block_on(internal.pop());
        if let Some(e) = internal.or(pollster::block_on(validation.pop())) {
            return Err(format!("{}: {e}", stage.file));
        }
        let pipelines = built?;
        let scene = stage.scene_source.as_deref().and_then(|source| {
            let traced = TraceShape::of(shape, stage.traces_entities(), None);
            let reads = (stage.traces_looks(), stage.traces_lights());
            let terrain = (&terrain_entries()[..], &traced, reads);
            let own = kept.as_ref().map_or(&[][..], |k| &k.entries);
            TerrainTrace::new(device, frame, terrain, own, |group| build(source, group))
        });
        Ok(Self {
            pipelines,
            scene,
            writes_surface,
            kept,
        })
    }

    /// Makes the groups the terrain draws with this frame, for the frame's group as it is now,
    /// `scene`, this frame's, where it traces, and the kept resources of `post` it reads.
    pub(super) fn bind(
        &mut self,
        device: &wgpu::Device,
        frame: &NativeFrame,
        scene: Option<&Traced<'_>>,
        post: &NativePost,
    ) {
        if let Some(trace) = &mut self.scene {
            let reads = self.kept.as_ref().and_then(|k| k.reads(post));
            trace.bind(device, frame, scene, reads);
        }
        if let Some(k) = &mut self.kept {
            k.bind(device, frame, post);
        }
    }

    /// This frame's `frame.ray_distance` when the terrain traces `scene`.
    pub(super) fn trace(&self, queue: &wgpu::Queue, scene: Option<&Traced<'_>>) -> Option<f32> {
        self.scene.as_ref()?.trace(queue, scene)
    }

    /// The pipelines and group 3 the terrain draws with this frame: against the scene where
    /// it traces, else the ones whose `trace` misses with the frame's own `group`, or with the
    /// kept resources it reads, this frame's version `parity`.
    pub(super) fn drawn<'a>(
        &'a self,
        group: &'a wgpu::BindGroup,
        parity: usize,
    ) -> (&'a MaterialPipelines, &'a wgpu::BindGroup) {
        let traced = self.scene.as_ref().and_then(|t| t.drawn(parity));
        let group = (self.kept.as_ref())
            .and_then(|k| k.group(parity))
            .unwrap_or(group);
        traced.unwrap_or((&self.pipelines, group))
    }

    /// One set of a material stage's terrain pipelines, from its `source`, with `frame_group` as
    /// their group 3; `(fog, vertex, writes_surface, coverage)` as `NativeMaterial::new` has them.
    fn pipelines(
        device: &wgpu::Device,
        (shape, displaced, constants): (
            &TerrainShape<'_>,
            Option<&DisplacedShape<'_>>,
            &[(String, f64)],
        ),
        (stage, source): (&CheckedStage, &str),
        frame_group: &wgpu::BindGroupLayout,
        (fog, vertex, writes_surface, coverage): (bool, bool, bool, horizon_shader_api::Coverage),
        linear: bool,
    ) -> Result<MaterialPipelines, String> {
        let source = &(source.to_owned() + super::looks::wgsl(shape.looks.is_some()));
        let module = module(
            (source, &stage.file),
            shape.sprite_tags,
            shape.sprite_materials,
            (
                vertex,
                displaced.is_some(),
                stage.shaded_tint(),
                stage.light_source(),
                stage.lit_tint(),
            ),
            linear,
        )?;
        let mut constants = present_constants(&module, constants);
        let sprite_names = [
            "horizon_terrain_SPRITE_ARRAYS",
            "horizon_terrain_SPRITE_SPLIT",
        ];
        constants.extend(sprite_names.into_iter().zip(shape.sprites));
        constants.push(("horizon_material_fog", f64::from(u8::from(fog))));
        let pack = coverage == horizon_shader_api::Coverage::Pack;
        constants.push(("horizon_material_coverage_pack", f64::from(u8::from(pack))));
        let [(_, write_light), (_, linear)] =
            super::linear_blend::frame_constants(shape.format, linear);
        constants.push(("horizon_terrain_HDR_WRITE_LIGHT", write_light));
        constants.push(("horizon_terrain_FRAME_LINEAR", linear));
        constants.push((
            "horizon_displace_distance",
            displaced.map_or(0.0, |d| f64::from(d.distance)),
        ));
        if let Some(d) = displaced {
            constants.push(("horizon_displace_cells", f64::from(d.cells)));
            constants.push(("horizon_displace_steps", f64::from(u8::from(d.steps))));
        }
        let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some(&super::dx12_compiler::module_label(&stage.label)),
            source: wgpu::ShaderSource::Naga(std::borrow::Cow::Owned(module)),
        });
        let layout = |flat: Option<&wgpu::BindGroupLayout>| {
            let mut groups: [Option<&wgpu::BindGroupLayout>; GROUP as usize + 1] =
                Default::default();
            groups[0] = Some(shape.globals);
            groups[1] = flat;
            groups[super::looks::GROUP as usize] = shape.looks;
            groups[GROUP as usize] = Some(frame_group);
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("Native shader pack terrain"),
                bind_group_layouts: &groups,
                ..Default::default()
            })
        };
        let instance_attributes = wgpu::vertex_attr_array![5=>Float32x4];
        let vertices = wgpu::VertexBufferLayout {
            array_stride: std::mem::size_of::<super::TerrainVertex>() as u64,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &super::TERRAIN_ATTRIBUTES,
        };
        let instances = wgpu::VertexBufferLayout {
            array_stride: 16,
            step_mode: wgpu::VertexStepMode::Instance,
            attributes: &instance_attributes,
        };
        // As the renderer's terrain pipelines (gfx.rs): back faces culled, reversed depth.
        let staged = vertex;
        let pipeline = |layout: &wgpu::PipelineLayout,
                        vertex: &str,
                        buffers: &[Option<wgpu::VertexBufferLayout<'_>>],
                        fragment: &str,
                        blend: Option<wgpu::BlendState>,
                        samples: u32| {
            let mut constants = constants.clone();
            if staged {
                let translucent = fragment == "horizon_material_fs_translucent";
                constants.push((
                    "horizon_material_translucent",
                    f64::from(u8::from(translucent)),
                ));
            }
            let options = wgpu::PipelineCompilationOptions {
                constants: &constants,
                ..Default::default()
            };
            let solid_targets = [
                Some(wgpu::ColorTargetState {
                    format: shape.format,
                    blend,
                    write_mask: wgpu::ColorWrites::ALL,
                }),
                Some(wgpu::ColorTargetState {
                    format: SURFACE_FORMAT,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                }),
            ];
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some(&stage.label),
                layout: Some(layout),
                vertex: wgpu::VertexState {
                    module: &module,
                    entry_point: Some(vertex),
                    compilation_options: options.clone(),
                    buffers,
                },
                primitive: wgpu::PrimitiveState {
                    cull_mode: Some(wgpu::Face::Back),
                    ..Default::default()
                },
                depth_stencil: Some(wgpu::DepthStencilState {
                    format: wgpu::TextureFormat::Depth32Float,
                    depth_write_enabled: Some(true),
                    depth_compare: Some(wgpu::CompareFunction::GreaterEqual),
                    stencil: Default::default(),
                    bias: Default::default(),
                }),
                multisample: super::msaa::state(samples),
                fragment: Some(wgpu::FragmentState {
                    module: &module,
                    entry_point: Some(fragment),
                    compilation_options: options,
                    targets: if fragment != "horizon_material_fs_translucent" && writes_surface {
                        &solid_targets
                    } else {
                        &solid_targets[..1]
                    },
                }),
                multiview_mask: None,
                cache: None,
            })
        };
        let blend = Some(wgpu::BlendState::ALPHA_BLENDING);
        let instanced = layout(None);
        let buffers = [Some(vertices.clone()), Some(instances.clone())];
        // With flat draws' page groups the solid draws read the page themselves
        // (`SECTION_CORNER`), in either layout of the solid quads, as the renderer's do.
        let paged = shape.flat.map(|group| layout(Some(group)));
        let origins = [None, Some(instances)];
        // The solid draws' pipeline, single-sampled or 4x MSAA's (`horizon_material_fs_msaa`).
        let solid_with = |fragment: &str, samples: u32| match &paged {
            Some(paged) => pipeline(
                paged,
                "horizon_material_vs_section",
                &origins,
                fragment,
                None,
                samples,
            ),
            None => pipeline(
                &instanced,
                "horizon_material_vs",
                &buffers,
                fragment,
                None,
                samples,
            ),
        };
        let flat_with = |layout: &wgpu::PipelineLayout, fragment: &str, samples: u32| {
            pipeline(
                layout,
                "horizon_material_vs_section_flat",
                &[],
                fragment,
                None,
                samples,
            )
        };
        let solid = solid_with("horizon_material_fs_solid", 1);
        let translucent = pipeline(
            &instanced,
            "horizon_material_vs",
            &buffers,
            "horizon_material_fs_translucent",
            blend,
            1,
        );
        let flat = paged.as_ref().map(|layout| {
            let buffers = [Some(vertices.clone())];
            (
                flat_with(layout, "horizon_material_fs_solid", 1),
                pipeline(
                    layout,
                    "horizon_material_vs_flat",
                    &buffers,
                    "horizon_material_fs_translucent",
                    blend,
                    1,
                ),
            )
        });
        // A driver that refuses them costs the pack 4x MSAA, not its load.
        let msaa_scope = device.push_error_scope(wgpu::ErrorFilter::Validation);
        let msaa_internal = device.push_error_scope(wgpu::ErrorFilter::Internal);
        let msaa = (shape.msaa && displaced.is_none()).then(|| {
            let solid = solid_with("horizon_material_fs_msaa", super::msaa::SAMPLES);
            let flat = paged
                .as_ref()
                .map(|layout| flat_with(layout, "horizon_material_fs_msaa", super::msaa::SAMPLES));
            (solid, flat)
        });
        let msaa_internal = pollster::block_on(msaa_internal.pop());
        let msaa = match msaa_internal.or(pollster::block_on(msaa_scope.pop())) {
            Some(e) => {
                log::warn!(
                    "{}: no 4x MSAA pipelines, it draws single-sampled ({e})",
                    stage.file
                );
                None
            }
            None => msaa,
        };
        // The grid's corners come from its group 1, not from vertex buffers.
        let displaced = displaced.map(|d| {
            pipeline(
                &layout(Some(d.layout)),
                "horizon_material_vs_displaced",
                &[],
                "horizon_material_fs_displaced",
                None,
                1,
            )
        });
        Ok(MaterialPipelines {
            solid,
            translucent,
            flat,
            msaa,
            displaced,
        })
    }
}

#[cfg(test)]
impl NativeMaterial {
    /// The layout of the group 3 `drawn` gives this frame, where the material reads kept
    /// resources, for a test's own entry points.
    pub(in crate::gfx) fn drawn_layout(&self) -> &wgpu::BindGroupLayout {
        match (
            self.scene.as_ref().filter(|t| t.drawn(0).is_some()),
            &self.kept,
        ) {
            (Some(t), _) => t.layout(),
            (None, Some(k)) => &k.layout,
            (None, None) => unreachable!("the material reads no kept resources"),
        }
    }
}

/// The terrain shader of a material's composed `source`, for a test's own entry points: no
/// vertex stage, no displacement, no `shaded_tint`, light-source fields or `lit_tint`, and the
/// quads' looks not bound.
#[cfg(test)]
pub(in crate::gfx) fn test_shader(source: &str) -> String {
    let source = source.to_owned() + crate::gfx::looks::NO_LOOK_WGSL;
    shader_source(
        &source,
        &[],
        &[],
        (false, false, false, false, false),
        false,
    )
}

/// The terrain shader of a pack's checked material `stage` for a test's own entry points, its
/// inputs' `shaded_tint`, light-source fields and `lit_tint` as the renderer builds them: no
/// vertex stage, no displacement, a frame of vanilla's gamma, and the quads' looks not bound.
#[cfg(test)]
pub(in crate::gfx) fn stage_test_shader(stage: &CheckedStage) -> String {
    let source = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
    let inputs = (
        false,
        false,
        stage.shaded_tint(),
        stage.light_source(),
        stage.lit_tint(),
    );
    shader_source(&source, &[], &[], inputs, false)
}

impl super::native_pack::NativePack {
    /// The material stage's terrain layers; none without one.
    pub fn terrain_layers(&self) -> Option<TerrainLayers<'_>> {
        let m = self.material.as_ref()?;
        // Against the ray scene where the material traces, else the frame's own group 3.
        let (pipelines, frame) = self.terrain()?;
        Some(TerrainLayers {
            solid: &pipelines.solid,
            translucent: &pipelines.translucent,
            flat: pipelines.flat.as_ref(),
            displaced: (pipelines.displaced.as_ref()).filter(|_| self.displacement.is_some()),
            msaa: pipelines.msaa.as_ref(),
            surface: m.writes_surface.then_some(&self.frame.surface_view),
            reads_opaque: self.frame.reads_opaque,
            frame,
        })
    }

    /// Copies the world before translucent terrain into what the material reads
    /// (`opaque_depth`, `opaque_color`).
    pub fn copy_opaque(&self, copy: OpaqueCopy<'_>) {
        let OpaqueCopy {
            device,
            encoder,
            depth,
            color,
        } = copy;
        encoder.copy_texture_to_texture(
            depth.as_image_copy(),
            self.frame.opaque_depth.as_image_copy(),
            depth.size(),
        );
        if let Some(color) = color {
            self.frame.copy_opaque(device, encoder, color);
        }
    }

    /// Writes out the solid quads of the sections `[displacement]` reaches and picks this
    /// frame's grid (none on the title screen, where the renderer hands over no sections).
    pub fn prepare_displacement<'s>(
        &mut self,
        prepare: DisplacementPrepare<'_, impl Iterator<Item = Near<'s>>>,
    ) {
        let Some(d) = &mut self.displacement else {
            return;
        };
        let near: smallvec::SmallVec<[Near<'_>; MAX_SECTIONS]> = prepare
            .sections
            .filter(|n| {
                let o = glam::Vec3::from(n.origin);
                let closest = glam::Vec3::ZERO.clamp(o, o + 16.0);
                closest.length() < d.distance
            })
            .collect();
        let DisplacementPrepare {
            device,
            queue,
            encoder,
            view_proj,
            ..
        } = prepare;
        d.prepare(device, queue, encoder, &near, view_proj);
    }

    /// `[displacement]`'s grid, drawn by `layers`' displaced layer; none without either.
    pub fn displaced_grid<'a>(&'a self, layers: TerrainLayers<'a>) -> Option<DisplacedGrid<'a>> {
        Some(DisplacedGrid {
            displacement: self.displacement.as_ref()?,
            pipeline: layers.displaced?,
            layers,
        })
    }
}

/// `[displacement]`'s grid of the solid terrain near the camera and the layer that draws it
/// (`NativePack::displaced_grid`).
#[derive(Clone, Copy)]
pub struct DisplacedGrid<'a> {
    displacement: &'a Displacement,
    pipeline: &'a wgpu::RenderPipeline,
    layers: TerrainLayers<'a>,
}

impl DisplacedGrid<'_> {
    /// Draws the grid over the flat quads it took over, writing its depth, in a terrain pass
    /// with the renderer's group 0 bound.
    pub fn draw(&self, pass: &mut wgpu::RenderPass<'_>) {
        self.layers.bind(pass);
        let d = self.displacement;
        d.draw(pass, &d.view, self.pipeline);
    }
}

#[cfg(test)]
/// A material pack's terrain shader, its frame holding linear light where `linear`, with a
/// full-screen `test_vertex`. Its material returns alpha `test_alpha` (0.7 unless set).
pub(super) fn coverage_test_shader(linear: bool) -> String {
    use horizon_shader_api::{MANIFEST, Pack, StageKind, check};
    let manifest = "schema = 1\nid = \"coverage\"\nname = \"Coverage\"\nversion = \"1\"\napi = \"0.2\"\n[material]\nfile = \"material.wgsl\"\n[displacement]\n";
    let material = "override test_alpha: f32 = 0.7;\nfn material(input: MaterialInput) -> Surface { return Surface(vec4<f32>(1.4, 0.3, 0.1, test_alpha)); }\nfn displacement(input: DisplacementInput) -> f32 { return 0.0; }\n";
    let files = [(MANIFEST, manifest), ("material.wgsl", material)]
        .map(|(n, text)| (n.to_owned(), text.as_bytes().to_vec()))
        .into();
    let report = check(&Pack::from_files(files).unwrap()).unwrap();
    let stage = report
        .stages
        .iter()
        .find(|s| s.kind == StageKind::Material)
        .unwrap();
    shader_source(
        &(stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL),
        &[],
        &[],
        (false, true, false, false, false),
        linear,
    ) + r#"
override TEST_TIER: u32 = 0u;
override TEST_OVERLAY: u32 = 0u;
@vertex fn test_vertex(@builtin(vertex_index) i: u32) -> HorizonMaterialOut {
    var o: HorizonMaterialOut;
    o.clip = vec4(vec2(f32((i << 1u) & 2u), f32(i & 2u)) * 2.0 - 1.0, 0.0, 1.0);
    o.uv = vec2(0.5);
    o.tint = vec4(1.0);
    o.lightmap = vec3(1.0);
    o.base = vec3(1.0);
    return o;
}
"#
}

#[cfg(test)]
mod tests {
    use super::*;
    use horizon_shader_api::{MANIFEST, Pack, StageKind, check};

    fn stage(material: &str) -> CheckedStage {
        let manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
            [material]\nfile = \"material.wgsl\"\n\
            [[options]]\nid = \"gain\"\nname = \"Gain\"\ntype = \"float\"\n\
            default = 1.0\nmin = 0.0\nmax = 2.0\n";
        let files = [(MANIFEST, manifest), ("material.wgsl", material)]
            .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
            .into();
        let mut report = check(&Pack::from_files(files).unwrap()).unwrap();
        assert_eq!(report.stages[0].kind, StageKind::Material);
        report.stages.remove(0)
    }

    /// The fade-in as its varying carries it: a section a quarter visible (`section_instance`
    /// with step 1: mantissa `1 - visibility` = 0.75) keeps its visibility, and a fragment 24
    /// blocks away, half-way into the 16-block blend, is 1 - (1 - 0.25) / 2 = 0.625 visible.
    #[test]
    fn the_fade_in_keeps_the_sections_visibility() {
        let w = f32::from_bits(1.0f32.to_bits() | (0.75 * 8_388_608.0) as u32);
        // `horizon_material_vertex`.
        let instance = 1.0 - (w.to_bits() & 0x7fffff) as f32 / 8_388_608.0;
        let fade = ((1.0 - instance) * 65535.0).round() as u32;
        // `horizon_material_faded`.
        let unpacked = 1.0 - fade as f32 / 65535.0;
        assert!((unpacked - 0.25).abs() < 1.0 / 65535.0);
        let blend = ((24.0f32 - 16.0) / 16.0).clamp(0.0, 1.0);
        let visibility = 1.0 + (unpacked - 1.0) * blend;
        assert!((visibility - 0.625).abs() < 1.0 / 65535.0);
    }

    #[test]
    fn the_terrain_takes_a_prefix_and_validates_with_a_pack() {
        let terrain = vanilla_terrain();
        for name in [
            "Globals",
            "globals",
            "sprites_7",
            "sprite",
            "SPRITE_SPLIT",
            "block_slots",
            "sample_lightmap",
            "apply_fog",
        ] {
            assert!(terrain.contains(&format!("{PREFIX}{name}")), "{name}");
        }
        assert!(!terrain.contains("fs_sky"), "the sky stays out");
        // A pack may use any name Horizon's terrain uses unprefixed.
        let own = "override gain: f32;\nconst PI: f32 = 3.0;\n\
            fn sprite(c: vec4<f32>) -> vec4<f32> { return c * PI; }\n\
            fn apply_fog(c: vec4<f32>) -> vec4<f32> { return c * gain; }\n\
            fn material(input: MaterialInput) -> Surface {\n    \
                let lit = input.albedo * input.tint * vec4(input.lightmap, 1.0);\n    \
                let t = vec2<i32>(input.screen * frame.resolution);\n    \
                let behind = textureLoad(opaque_color, t, 0) * textureLoad(opaque_depth, t, 0);\n    \
                let mirrored = textureSampleLevel(reflection, reflection_sampler, input.screen, 0.0);\n    \
                let kind = f32(input.face + input.fluid) * input.emission * mirrored.a;\n    \
                let frame_of = vec4(cross(input.normal, input.tangent.xyz) * input.tangent.w, kind);\n    \
                return Surface(apply_fog(sprite(lit)) + (behind + frame_of) * 0.0);\n}\n";
        let stage = stage(own);
        let tags = [(7, 1), (3, 1), (9, 2)];
        let materials = [(5, 1000)];
        assert!(layer_table("t", &tags).contains("case 3u, 7u: { return 1u; }"));
        let source = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
        let module = module(
            (&source, &stage.file),
            &tags,
            &materials,
            (false, false, false, false, false),
            false,
        )
        .unwrap();
        let info = naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .unwrap_or_else(|e| {
            panic!(
                "{}",
                e.emit_to_string(&shader_source(
                    &source,
                    &tags,
                    &materials,
                    (false, false, false, false, false),
                    false
                ))
            )
        });
        let entries: Vec<&str> = module
            .entry_points
            .iter()
            .map(|e| e.name.as_str())
            .collect();
        for entry in [
            "horizon_material_vs",
            "horizon_material_vs_flat",
            "horizon_material_vs_section",
            "horizon_material_vs_section_flat",
            "horizon_material_fs_solid",
            "horizon_material_fs_translucent",
        ] {
            assert!(entries.contains(&entry), "{entry}");
        }
        drop(info);
        assert_eq!(
            present_constants(&module, &[("gain".into(), 1.5), ("other".into(), 1.0)]),
            [("gain", 1.5)]
        );
    }

    /// The terrain shader of a pack with a vertex stage, whose tint the renderer decodes.
    #[test]
    fn the_terrain_validates_with_a_vertex_stage() {
        let manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
            [material]\nfile = \"material.wgsl\"\n[vertex]\nfile = \"vertex.wgsl\"\n";
        let material = "fn material(input: MaterialInput) -> Surface {\n    \
                return Surface(input.albedo * input.tint * vec4(input.colored_light, 1.0));\n}\n";
        let vertex = "fn vertex(input: VertexInput) -> vec3<f32> {\n    \
                return input.position + input.tint.rgb;\n}\n";
        let files = [
            (MANIFEST, manifest),
            ("material.wgsl", material),
            ("vertex.wgsl", vertex),
        ]
        .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
        .into();
        let report = check(&Pack::from_files(files).unwrap()).unwrap();
        let stage = report
            .stages
            .iter()
            .find(|s| s.kind == StageKind::Material)
            .unwrap();
        let text = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
        let source = (text.as_str(), stage.file.as_str());
        let module = module(source, &[], &[], (true, false, false, false, false), false).unwrap();
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .unwrap();
    }

    /// A material stage that traces, with a vertex stage and `[displacement]`: its terrain built
    /// against the scene validates, and only its fragment entries read the scene, which the
    /// renderer binds for the fragment stage alone.
    #[test]
    fn a_traced_terrain_reads_the_scene_in_its_fragments_only() {
        use horizon_shader_api::stages::{RAY_LOOKS_BINDING, RAY_SCENE_BINDING};
        let manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
            [material]\nfile = \"material.wgsl\"\n[vertex]\nfile = \"vertex.wgsl\"\n\
            [displacement]\n[ray_tracing]\n";
        let material = "fn material(input: MaterialInput) -> Surface {\n    \
                let hit = trace(input.position, input.normal, 16.0);\n    \
                let maps = hit_normal_map(hit) * hit_specular_map(hit).r * hit.emission;\n    \
                return Surface(input.albedo * f32(hit.distance < 0.0) + maps * hit.tangent);\n}\n\
            fn displacement(input: DisplacementInput) -> f32 { return 0.0; }\n";
        let vertex = "fn vertex(input: VertexInput) -> vec3<f32> { return input.position; }\n";
        let files = [
            (MANIFEST, manifest),
            ("material.wgsl", material),
            ("vertex.wgsl", vertex),
        ]
        .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
        .into();
        let report = check(&Pack::from_files(files).unwrap()).unwrap();
        let stage = report
            .stages
            .iter()
            .find(|s| s.kind == StageKind::Material)
            .unwrap();
        let text = stage.scene_source.clone().unwrap() + crate::gfx::looks::NO_LOOK_WGSL;
        let source = (text.as_str(), stage.file.as_str());
        let module = module(source, &[], &[], (true, true, false, false, false), false).unwrap();
        let info = naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .unwrap();
        let scene: Vec<_> = (module.global_variables.iter())
            .filter(|(_, g)| {
                (g.binding.as_ref())
                    .is_some_and(|b| b.group == GROUP && b.binding >= RAY_SCENE_BINDING)
            })
            .map(|(handle, _)| handle)
            .collect();
        // The hit's emission is decoded from the vertex.
        assert_eq!(scene.len(), 12);
        assert!(scene.iter().all(|&g| {
            module.global_variables[g].binding.as_ref().unwrap().binding != RAY_LOOKS_BINDING
        }));
        for (i, entry) in module.entry_points.iter().enumerate() {
            let reads = scene
                .iter()
                .any(|&g| !info.get_entry_point(i)[g].is_empty());
            // The material's fragment entries; no vertex entry, and none of terrain.wgsl's own,
            // copied with its section, which don't call `material`.
            let material = entry.name.starts_with("horizon_material_fs");
            assert_eq!(reads, material, "{}", entry.name);
        }
        let fragments = module
            .entry_points
            .iter()
            .filter(|e| e.name.starts_with("horizon_material_fs"));
        // Solid, 4x MSAA's solid, translucent and the displaced grid.
        assert_eq!(fragments.count(), 4);
    }

    /// A pack's own text that happens to hold a `lit_tint` mark's spelling keeps it.
    #[test]
    fn a_pack_s_own_text_keeps_a_lit_mark_s_spelling() {
        let text = test_shader("/* @lit_out@ */\n");
        assert!(text.starts_with("/* @lit_out@ */\n"), "{text}");
    }

    /// `MaterialInput.lit_tint`'s varying is the terrain's 15th, the last the weakest GPUs have
    /// (`inter_stage_tests::LIMIT`), and only a pack's that names it: with and without a vertex
    /// stage and `[displacement]`'s grid, a pack naming every optional input (`shaded_tint`, the
    /// light-source fields and `lit_tint`) fits, at 15 in every entry point that carries the
    /// terrain's varyings; one naming none is at 14, and its shader holds none of the field's
    /// text, so it is built as before it.
    #[test]
    fn lit_tint_takes_the_terrain_s_last_varying_only_where_named() {
        use super::super::inter_stage_tests::{LIMIT, interfaces};
        let stage = |material: &str| {
            let manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
                [material]\nfile = \"material.wgsl\"\n[vertex]\nfile = \"vertex.wgsl\"\n\
                [displacement]\n";
            let material = format!(
                "{material}fn displacement(input: DisplacementInput) -> f32 {{ return 0.0; }}\n"
            );
            let vertex = "fn vertex(input: VertexInput) -> vec3<f32> { return input.position; }\n";
            let files = [
                (MANIFEST, manifest),
                ("material.wgsl", &material),
                ("vertex.wgsl", vertex),
            ]
            .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
            .into();
            let report = check(&Pack::from_files(files).unwrap()).unwrap();
            let at = report
                .stages
                .iter()
                .position(|s| s.kind == StageKind::Material);
            report.stages.into_iter().nth(at.unwrap()).unwrap()
        };
        let named = stage(
            "fn material(input: MaterialInput) -> Surface {\n    \
                let t = f32(input.light_source_tier) * input.light_source_threshold;\n    \
                return Surface(input.shaded_tint * vec4<f32>(input.lit_tint * t, 1.0));\n}\n",
        );
        let plain = stage(
            "fn material(input: MaterialInput) -> Surface {\n    return Surface(input.albedo);\n}\n",
        );
        assert!(named.lit_tint() && named.shaded_tint() && named.light_source());
        assert!(!plain.lit_tint() && !plain.shaded_tint() && !plain.light_source());
        for vertex in [false, true] {
            for displaced in [false, true] {
                let most = |stage: &CheckedStage| {
                    let inputs = (
                        vertex,
                        displaced,
                        stage.shaded_tint(),
                        stage.light_source(),
                        stage.lit_tint(),
                    );
                    let source = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
                    let text = shader_source(&source, &[], &[], inputs, false);
                    let module = naga::front::wgsl::parse_str(&text).unwrap();
                    naga::valid::Validator::new(
                        naga::valid::ValidationFlags::all(),
                        naga::valid::Capabilities::all(),
                    )
                    .validate(&module)
                    .unwrap_or_else(|e| panic!("{}", e.emit_to_string(&text)));
                    let counts: Vec<u32> = (interfaces(&text).iter())
                        .filter(|i| i.entry.starts_with("horizon_material_"))
                        .map(|i| i.total())
                        .collect();
                    // Four vertex entries, the solid, translucent and 4x MSAA fragments, and
                    // the displaced grid's two.
                    assert_eq!(counts.len(), 7 + 2 * usize::from(displaced));
                    (counts.into_iter().max().unwrap(), text)
                };
                let case = format!("vertex {vertex}, displaced {displaced}");
                let (lit, text) = most(&named);
                assert_eq!((lit, LIMIT), (15, 15), "{case}");
                assert!(text.contains("@location(11) lit_tint"), "{case}");
                let (unlit, text) = most(&plain);
                assert_eq!(unlit, 14, "{case}");
                assert!(
                    !text.contains("lit_tint") && !text.contains("@lit"),
                    "{case}"
                );
            }
        }
    }

    #[test]
    fn the_displaced_grid_validates_with_a_pack() {
        let manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
            [material]\nfile = \"material.wgsl\"\n[displacement]\n";
        let material = "fn material(input: MaterialInput) -> Surface {\n    \
                return Surface(input.albedo * (1.0 - 0.5 * input.displaced));\n}\n\
            fn displacement(input: DisplacementInput) -> f32 {\n    \
                return (1.0 - input.height) * 0.125 * f32(input.material + 1u);\n}\n";
        let files = [(MANIFEST, manifest), ("material.wgsl", material)]
            .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
            .into();
        let mut report = check(&Pack::from_files(files).unwrap()).unwrap();
        let stage = report.stages.remove(0);
        let materials = [(5, 1000)];
        let source = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
        let module = module(
            (&source, &stage.file),
            &[],
            &materials,
            (false, true, false, false, false),
            false,
        )
        .unwrap();
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .unwrap_or_else(|e| {
            let text = shader_source(
                &source,
                &[],
                &materials,
                (false, true, false, false, false),
                false,
            );
            panic!("{}", e.emit_to_string(&text))
        });
        for entry in [
            "horizon_material_vs_displaced",
            "horizon_material_fs_displaced",
        ] {
            assert!(
                module.entry_points.iter().any(|e| e.name == entry),
                "{entry}"
            );
        }
    }

    /// An identity material (vanilla's own lighting, `albedo * tint * lightmap`), its colours
    /// decoded on the way in and encoded on the way out as the entries do, draws vanilla's
    /// product of the gamma colours within an 8-bit step.
    #[test]
    fn an_identity_material_is_vanilla_s_within_an_8_bit_step() {
        let _gpu = crate::gfx::test_gpu::lock();
        let instance = crate::gfx::test_gpu::instance();
        let Ok(adapter) = pollster::block_on(instance.request_adapter(&Default::default())) else {
            return;
        };
        let Ok((device, queue)) = pollster::block_on(adapter.request_device(&Default::default()))
        else {
            return;
        };
        // The entries' call of `material`, with a 16×16 grid of colours.
        let entry = "@vertex fn vs(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
    return vec4<f32>(vec2<f32>(f32((i << 1u) & 2u), f32(i & 2u)) * 2.0 - 1.0, 0.0, 1.0);
    }
    @fragment fn fs(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    let c = floor(p.xy) / 15.0;
    let albedo = vec4(c.x, c.y, 1.0 - c.x, 1.0);
    let tint = vec4(0.9, 1.0 - 0.5 * c.y, 0.7, 1.0);
    let lightmap = vec3(c.y, 0.8, 1.0 - c.y);
    let out = material(MaterialInput(vec4(horizon_line_in(albedo.rgb), albedo.a),
        vec4(horizon_line_in(tint.rgb), tint.a), 1.0, 1.0, vec2(1.0), horizon_line_in(lightmap),
        vec3(0.0), vec2(0.0), false, 0u, 0u, vec2(0.0), 0u, 0u, 0.0, vec3(0.0, 1.0, 0.0),
        vec4(1.0, 0.0, 0.0, 1.0), horizon_line_in(vec3(0.0)), 0.0)).color;
    return vec4(horizon_line_out(out.rgb), out.a);
    }
    ";
        let vanilla = "fn material(input: MaterialInput) -> Surface {\n    \
            return Surface(input.albedo * input.tint * vec4(input.lightmap, 1.0));\n}\n";
        let format = wgpu::TextureFormat::Rgba8Unorm;
        let manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
            [material]\nfile = \"material.wgsl\"\n";
        let files = [(MANIFEST, manifest), ("material.wgsl", vanilla)]
            .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
            .into();
        let report = check(&Pack::from_files(files).unwrap()).unwrap();
        let source = report.stages[0].source.clone()
            + horizon_shader_api::stages::PBR_STUB
            + super::super::native_post::line_helpers(false)
            + entry;
        let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: wgpu::ShaderSource::Wgsl(source.into()),
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: None,
            layout: None,
            vertex: wgpu::VertexState {
                module: &module,
                entry_point: Some("vs"),
                compilation_options: Default::default(),
                buffers: &[],
            },
            primitive: Default::default(),
            depth_stencil: None,
            multisample: Default::default(),
            fragment: Some(wgpu::FragmentState {
                module: &module,
                entry_point: Some("fs"),
                compilation_options: Default::default(),
                targets: &[Some(format.into())],
            }),
            multiview_mask: None,
            cache: None,
        });
        let size = wgpu::Extent3d {
            width: 16,
            height: 16,
            depth_or_array_layers: 1,
        };
        let target = device.create_texture(&wgpu::TextureDescriptor {
            label: None,
            size,
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });
        let view = target.create_view(&Default::default());
        let mut encoder = device.create_command_encoder(&Default::default());
        let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: &view,
                resolve_target: None,
                depth_slice: None,
                ops: Default::default(),
            })],
            ..Default::default()
        });
        pass.set_pipeline(&pipeline);
        pass.draw(0..3, 0..1);
        drop(pass);
        let screenshot = crate::gfx::copy_frame(&device, &mut encoder, &target, [16, 16]);
        queue.submit([encoder.finish()]);
        screenshot
            .slice(..)
            .map_async(wgpu::MapMode::Read, |r| r.unwrap());
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let drawn = screenshot.slice(..).get_mapped_range().unwrap().to_vec();
        // The entry's grid, multiplied as vanilla does: in gamma.
        let mut worst = 0;
        for (y, row) in drawn
            .chunks(crate::gfx::padded_row(16) as usize)
            .enumerate()
        {
            for (x, pixel) in row[..64].chunks(4).enumerate() {
                let c = [x as f32 / 15.0, y as f32 / 15.0];
                let albedo = [c[0], c[1], 1.0 - c[0]];
                let tint = [0.9, 1.0 - 0.5 * c[1], 0.7];
                let lightmap = [c[1], 0.8, 1.0 - c[1]];
                for i in 0..3 {
                    let vanilla = (albedo[i] * tint[i] * lightmap[i] * 255.0).round() as u8;
                    worst = worst.max(pixel[i].abs_diff(vanilla));
                }
            }
        }
        assert!(worst <= 1, "{worst}");
    }

    /// The vertex colour's alpha byte as the shaders read it back, on every device here: the
    /// engine's terrain (`terrain_vertex`) its HDR tier, a pack's material
    /// (`horizon_material_out`, with no quad look) whether its quad is a fluid's, the light
    /// level it gives off (`MaterialInput.fluid`, `emission`) and the same tier, for each tier a
    /// block has, each level and both kinds of quad, as mesher.rs writes them.
    #[test]
    fn the_vertex_alpha_reads_back_as_the_mesher_writes_it() {
        use crate::mesher::{WHOLE, as_fluid, emitting, giving_off};
        // (alpha byte, tier code, fluid, level): the codes are terrain.wgsl's `emission`.
        let tiers = [0, 1, 2, 3, 1 | WHOLE, 2 | WHOLE, 3 | WHOLE];
        let mut cases = Vec::new();
        for (tier, code) in tiers.into_iter().zip([0u32, 1, 2, 3, 5, 6, 7]) {
            for level in 0..=15u8 {
                let lit = giving_off(emitting(0xFF80_8080, tier), level);
                for (color, fluid) in [(lit, false), (as_fluid(lit), true)] {
                    cases.push((color >> 24, code, fluid, u32::from(level)));
                }
            }
        }
        let entries = format!(
            "
@group(3) @binding(0) var<storage, read_write> test_out: array<vec2<u32>, 256>;
@vertex fn test_alpha(@builtin(vertex_index) v: u32) -> @builtin(position) vec4<f32> {{
    // As the vertex fetch converts a Unorm8x4 attribute (terrain.wgsl's `unorm8x4`).
    let color = vec4(0.5, 0.5, 0.5, f32(v) * (1.0 / 255.0));
    let engine = {PREFIX}terrain_vertex(vec3(0.0), vec2(0.0), 0u, color, vec2(0u), vec3(0.0),
        1.0);
    let pack = horizon_material_out(vec3(0.0), vec2(0.0), 0u, color, vec2(0.0), vec2(0u), 1.0);
    test_out[v] = vec2(engine.emission, pack.look);
    return vec4(2.0, 2.0, 2.0, 1.0);
}}
@fragment fn test_fs() -> @location(0) vec4<f32> {{
    return vec4(0.0);
}}
"
        );
        let stage = stage(
            "override gain: f32 = 1.0;\n\
             fn material(input: MaterialInput) -> Surface {\n    \
                 return Surface(input.albedo * input.emission * gain);\n}\n",
        );
        let source = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
        let source = shader_source(
            &source,
            &[],
            &[],
            (false, false, false, false, false),
            false,
        ) + &entries;
        let _gpu = crate::gfx::test_gpu::lock();
        let instance = crate::gfx::test_gpu::instance();
        let mut tested = Vec::new();
        for adapter in pollster::block_on(instance.enumerate_adapters(wgpu::Backends::all())) {
            let info = adapter.get_info();
            let device_name = format!("{} ({:?})", info.name, info.backend);
            let features = wgpu::Features::VERTEX_WRITABLE_STORAGE;
            if !adapter.features().contains(features) {
                eprintln!("{device_name}: no vertex storage writes");
                continue;
            }
            let (device, queue) =
                pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
                    required_features: features,
                    required_limits: adapter.limits(),
                    ..Default::default()
                }))
                .unwrap();
            let (globals, empty) = super::super::native_pack::tests::terrain_layouts(&device);
            let outs = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: false },
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                }],
            });
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: None,
                bind_group_layouts: &[Some(&globals), Some(&empty), Some(&empty), Some(&outs)],
                ..Default::default()
            });
            let format = wgpu::TextureFormat::Rgba8Unorm;
            let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: None,
                source: wgpu::ShaderSource::Wgsl(source.as_str().into()),
            });
            let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: None,
                layout: Some(&layout),
                vertex: wgpu::VertexState {
                    module: &module,
                    entry_point: Some("test_alpha"),
                    compilation_options: Default::default(),
                    buffers: &[],
                },
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::PointList,
                    ..Default::default()
                },
                depth_stencil: None,
                multisample: Default::default(),
                fragment: Some(wgpu::FragmentState {
                    module: &module,
                    entry_point: Some("test_fs"),
                    compilation_options: Default::default(),
                    targets: &[Some(format.into())],
                }),
                multiview_mask: None,
                cache: None,
            });
            // Group 0 of blank resources, as `native_pack`'s looks test binds it.
            let texture = |layers: u32, usage| {
                device.create_texture(&wgpu::TextureDescriptor {
                    label: None,
                    size: wgpu::Extent3d {
                        width: 4,
                        height: 4,
                        depth_or_array_layers: layers,
                    },
                    mip_level_count: 1,
                    sample_count: 1,
                    dimension: wgpu::TextureDimension::D2,
                    format,
                    usage,
                    view_formats: &[],
                })
            };
            let sampled = wgpu::TextureUsages::TEXTURE_BINDING;
            let array = texture(2, sampled).create_view(&wgpu::TextureViewDescriptor {
                dimension: Some(wgpu::TextureViewDimension::D2Array),
                ..Default::default()
            });
            let plain = texture(1, sampled).create_view(&Default::default());
            let sampler = device.create_sampler(&Default::default());
            let uniform = device.create_buffer(&wgpu::BufferDescriptor {
                label: None,
                size: 16384,
                usage: wgpu::BufferUsages::UNIFORM,
                mapped_at_creation: false,
            });
            let resource = |binding: u32| match binding {
                0 => uniform.as_entire_binding(),
                2 | 4 => wgpu::BindingResource::Sampler(&sampler),
                3 | 12 => wgpu::BindingResource::TextureView(&plain),
                _ => wgpu::BindingResource::TextureView(&array),
            };
            let entries: Vec<_> = (0..=12)
                .map(|binding| wgpu::BindGroupEntry {
                    binding,
                    resource: resource(binding),
                })
                .collect();
            let terrain = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &globals,
                entries: &entries,
            });
            let none = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &empty,
                entries: &[],
            });
            let size = 256 * 8;
            let buffer = |usage| {
                device.create_buffer(&wgpu::BufferDescriptor {
                    label: None,
                    size,
                    usage,
                    mapped_at_creation: false,
                })
            };
            let written = buffer(wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_SRC);
            let read = buffer(wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST);
            let out_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &outs,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: written.as_entire_binding(),
                }],
            });
            let view =
                texture(1, wgpu::TextureUsages::RENDER_ATTACHMENT).create_view(&Default::default());
            let mut encoder = device.create_command_encoder(&Default::default());
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    depth_slice: None,
                    ops: Default::default(),
                })],
                ..Default::default()
            });
            pass.set_pipeline(&pipeline);
            pass.set_bind_group(0, &terrain, &[]);
            pass.set_bind_group(1, &none, &[]);
            pass.set_bind_group(2, &none, &[]);
            pass.set_bind_group(3, &out_group, &[]);
            pass.draw(0..256, 0..1);
            drop(pass);
            encoder.copy_buffer_to_buffer(&written, 0, &read, 0, size);
            queue.submit([encoder.finish()]);
            read.slice(..)
                .map_async(wgpu::MapMode::Read, |r| r.unwrap());
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let got: Vec<[u32; 2]> =
                bytemuck::pod_collect_to_vec(&read.slice(..).get_mapped_range().unwrap());
            for &(byte, code, fluid, level) in &cases {
                // `horizon_material_out`'s `look`: without a look, face 0 and no shade's code;
                // the light-source code the engine's terrain reads.
                let look = u32::from(fluid) << 3 | level << 8 | code << 12;
                assert_eq!(
                    got[byte as usize],
                    [code, look],
                    "{device_name}: alpha {byte:#04x} (tier {code}, fluid {fluid}, level {level})"
                );
            }
            tested.push(device_name);
        }
        eprintln!("read back on {tested:?}");
    }

    /// A pack whose files name the light-source fields and `full_lightmap` reads what the
    /// engine's terrain reads for its HDR look (terrain.wgsl's `solid_finish_at`): the tier and
    /// whether the sprite shines whole, from the vertex colour's alpha byte as mesher.rs writes it
    /// for blocks of each kind (a froglight, lava's surface among them) and as lod/mesh.rs writes
    /// it for a far tile of glowstone and of a froglight; the
    /// sprite's threshold, at either array; and the lightmap at full light, which the frame takes
    /// from the renderer's lightmap (`native_post::full_lightmap`).
    #[test]
    fn a_pack_reads_the_light_sources_the_engine_s_look_reads() {
        use crate::mesher::{WHOLE, as_fluid, emitting, giving_off, hdr_tier};
        let _gpu = crate::gfx::test_gpu::lock();
        let instance = crate::gfx::test_gpu::instance();
        let Ok(adapter) = pollster::block_on(instance.request_adapter(&Default::default())) else {
            return;
        };
        // The terrain's fragments sample more textures than the default limit allows.
        let Ok((device, queue)) =
            pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
                required_limits: adapter.limits(),
                ..Default::default()
            }))
        else {
            return;
        };
        // (block, its light level, a fluid's surface, its sprite's layer): 4 layers an array
        // here, and bit 15 of a layer the opaque leaves' flag.
        let blocks = [
            ("stone", 0, false, 0u32),
            ("ochre_froglight", 15, false, 1),
            ("torch", 14, false, 2),
            ("glowstone", 15, false, 3),
            ("campfire", 15, false, 5),
            ("redstone_torch", 7, false, 6),
            ("lava", 15, true, 7 | 0x8000),
        ];
        // (alpha byte, layer, tier as mesher.rs gives it).
        let mut cases: Vec<(u32, u32, u8)> = blocks
            .iter()
            .map(|&(name, level, fluid, layer)| {
                let tier = hdr_tier(name, level);
                let color = giving_off(emitting(0xFF80_8080, tier), level);
                let color = if fluid { as_fluid(color) } else { color };
                (color >> 24, layer, tier)
            })
            .collect();
        // Distant terrain keeps its block's tier and whole flag: far tiles of glowstone and of a
        // froglight, as the LOD mesher emits them.
        for (name, layer) in [("glowstone", 4u32), ("pearlescent_froglight", 4)] {
            let tier = hdr_tier(name, 15);
            let vertex = crate::lod::far_top_vertex((tier, 15), layer as u16);
            cases.push((vertex.color >> 24, layer, tier));
        }
        let n = cases.len();
        let list = |f: fn(&(u32, u32, u8)) -> u32| {
            let items: Vec<String> = cases.iter().map(|c| format!("{}u", f(c))).collect();
            items.join(", ")
        };
        let entries = format!(
            "
@vertex fn test_vs(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {{
    return vec4(vec2(f32((i << 1u) & 2u), f32(i & 2u)) * 2.0 - 1.0, 0.0, 1.0);
}}
struct TestOut {{
    @location(0) pack: vec4<f32>,
    @location(1) engine: vec4<f32>,
}}
// Column i of the first row: case i, the pack's light source and the engine's. The second row:
// the frame's full light and the engine's lightmap at full light.
@fragment fn test_fs(@builtin(position) p: vec4<f32>) -> TestOut {{
    var alphas = array<u32, {n}>({alphas});
    var layers = array<u32, {n}>({layers});
    let i = min(u32(p.x), {n}u - 1u);
    let color = vec4(0.5, 0.5, 0.5, f32(alphas[i]) / 255.0);
    let layer = layers[i];
    var m = horizon_material_out(vec3(0.0), vec2(0.5), layer, color, vec2(240.0), vec2(0u), 1.0);
    m.clip = p;
    m.uv = vec2(f32(p.y > 1.0));
    let engine = {PREFIX}terrain_vertex(vec3(0.0), vec2(0.0), layer, color, vec2(240u),
        vec3(0.0), 1.0);
    let whole = engine.emission > 4u;
    let tier = select(engine.emission, engine.emission - 4u, whole);
    let l = layer & 0x7fffu;
    let t = textureLoad({PREFIX}emission_thresholds,
        vec2(i32(l % {PREFIX}SPRITE_SPLIT), i32(l / {PREFIX}SPRITE_SPLIT)), 0).r;
    let full = horizon_line_in({PREFIX}sample_lightmap(15.0, 15.0).rgb);
    var out: TestOut;
    out.pack = horizon_material_color(m, false);
    out.engine = select(vec4(f32(tier), f32(whole), t, 1.0), vec4(full, 1.0), p.y > 1.0);
    return out;
}}
",
            alphas = list(|c| c.0),
            layers = list(|c| c.1),
        );
        let manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
            [material]\nfile = \"material.wgsl\"\n";
        let material = "fn material(input: MaterialInput) -> Surface {\n    \
                if input.uv.x > 0.5 {\n        \
                    return Surface(vec4<f32>(frame.full_lightmap, 1.0));\n    \
                }\n    \
                let whole = select(0.0, 1.0, input.light_source_whole);\n    \
                return Surface(vec4<f32>(f32(input.light_source_tier), whole,\n        \
                    input.light_source_threshold, 1.0));\n}\n";
        let files = [(MANIFEST, manifest), ("material.wgsl", material)]
            .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
            .into();
        let mut report = check(&Pack::from_files(files).unwrap()).unwrap();
        let stage = report.stages.remove(0);
        assert!(stage.light_source());
        let source = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
        // A frame of linear light: the material's colour comes out as it returned it.
        let inputs = (false, false, false, true, false);
        let source = shader_source(&source, &[], &[], inputs, true) + &entries;
        // The renderer's lightmap, distinct at full light.
        let mut lightmap = [0u8; 16 * 16 * 4];
        for (i, byte) in lightmap.iter_mut().enumerate() {
            *byte = (i * 7 % 251) as u8;
        }
        lightmap[(15 * 16 + 15) * 4..][..4].copy_from_slice(&[200, 150, 90, 255]);
        // The thresholds of 2 arrays of 4 layers, each its own.
        let threshold = |l: u32| 20 + 25 * l as u8;
        let thresholds: Vec<u8> = (0..8).flat_map(|l| [threshold(l), 9, 7, 255]).collect();
        let (globals, empty) = super::super::native_pack::tests::terrain_layouts(&device);
        let mut frame = super::super::native_post::NativeFrame::new(
            &device,
            None,
            Vec::new(),
            Default::default(),
            None,
            true,
        );
        frame.full_lightmap = super::super::native_post::full_lightmap(&lightmap);
        let hud = crate::hud::HudBatch::scratch([4, 4]);
        let renderer = crate::gfx::pack_uniforms::initial_history_tests::frame(&hud);
        let display = crate::gfx::output::DisplayValues::SDR;
        frame.write(&queue, &renderer, [16, 2], display);
        let texture = |[width, height, layers]: [u32; 3], usage| {
            device.create_texture(&wgpu::TextureDescriptor {
                label: None,
                size: wgpu::Extent3d {
                    width,
                    height,
                    depth_or_array_layers: layers,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::Rgba8Unorm,
                usage: usage | wgpu::TextureUsages::COPY_DST,
                view_formats: &[],
            })
        };
        let sampled = wgpu::TextureUsages::TEXTURE_BINDING;
        let filled = |size: [u32; 3], bytes: &[u8]| {
            let t = texture(size, sampled);
            queue.write_texture(
                t.as_image_copy(),
                bytes,
                wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(size[0] * 4),
                    rows_per_image: None,
                },
                t.size(),
            );
            t.create_view(&Default::default())
        };
        let array = texture([4, 4, 2], sampled).create_view(&wgpu::TextureViewDescriptor {
            dimension: Some(wgpu::TextureViewDimension::D2Array),
            ..Default::default()
        });
        let lightmap_view = filled([16, 16, 1], &lightmap);
        let thresholds_view = filled([4, 2, 1], &thresholds);
        let sampler = device.create_sampler(&Default::default());
        let uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: None,
            size: 16384,
            usage: wgpu::BufferUsages::UNIFORM,
            mapped_at_creation: false,
        });
        let resource = |binding: u32| match binding {
            0 => uniform.as_entire_binding(),
            2 | 4 => wgpu::BindingResource::Sampler(&sampler),
            3 => wgpu::BindingResource::TextureView(&lightmap_view),
            12 => wgpu::BindingResource::TextureView(&thresholds_view),
            _ => wgpu::BindingResource::TextureView(&array),
        };
        let entries: Vec<_> = (0..=12)
            .map(|binding| wgpu::BindGroupEntry {
                binding,
                resource: resource(binding),
            })
            .collect();
        let terrain = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &globals,
            entries: &entries,
        });
        let none = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &empty,
            entries: &[],
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: None,
            bind_group_layouts: &[
                Some(&globals),
                Some(&empty),
                Some(&empty),
                Some(&frame.layout),
            ],
            ..Default::default()
        });
        let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: wgpu::ShaderSource::Wgsl(source.as_str().into()),
        });
        let constants = [
            ("horizon_terrain_SPRITE_ARRAYS", 2.0),
            ("horizon_terrain_SPRITE_SPLIT", 4.0),
        ];
        let options = wgpu::PipelineCompilationOptions {
            constants: &constants,
            ..Default::default()
        };
        let format = wgpu::TextureFormat::Rgba32Float;
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: None,
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &module,
                entry_point: Some("test_vs"),
                compilation_options: options.clone(),
                buffers: &[],
            },
            primitive: Default::default(),
            depth_stencil: None,
            multisample: Default::default(),
            fragment: Some(wgpu::FragmentState {
                module: &module,
                entry_point: Some("test_fs"),
                compilation_options: options,
                targets: &[Some(format.into()), Some(format.into())],
            }),
            multiview_mask: None,
            cache: None,
        });
        // 16 texels of 16 bytes: a row is the 256 bytes a copy's rows align to.
        let targets = [0, 1].map(|_| {
            device.create_texture(&wgpu::TextureDescriptor {
                label: None,
                size: wgpu::Extent3d {
                    width: 16,
                    height: 2,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format,
                usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
                view_formats: &[],
            })
        });
        let views = targets
            .each_ref()
            .map(|t| t.create_view(&Default::default()));
        let mut encoder = device.create_command_encoder(&Default::default());
        let attachments = views.each_ref().map(|view| {
            Some(wgpu::RenderPassColorAttachment {
                view,
                resolve_target: None,
                depth_slice: None,
                ops: wgpu::Operations {
                    load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT),
                    store: wgpu::StoreOp::Store,
                },
            })
        });
        let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            color_attachments: &attachments,
            ..Default::default()
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &terrain, &[]);
        pass.set_bind_group(1, &none, &[]);
        pass.set_bind_group(2, &none, &[]);
        pass.set_bind_group(3, &frame.group, &[]);
        pass.draw(0..3, 0..1);
        drop(pass);
        let reads = targets.each_ref().map(|target| {
            let read = device.create_buffer(&wgpu::BufferDescriptor {
                label: None,
                size: 512,
                usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            encoder.copy_texture_to_buffer(
                target.as_image_copy(),
                wgpu::TexelCopyBufferInfo {
                    buffer: &read,
                    layout: wgpu::TexelCopyBufferLayout {
                        offset: 0,
                        bytes_per_row: Some(256),
                        rows_per_image: None,
                    },
                },
                target.size(),
            );
            read
        });
        queue.submit([encoder.finish()]);
        for read in &reads {
            read.slice(..)
                .map_async(wgpu::MapMode::Read, |r| r.unwrap());
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let [pack, engine] = reads.map(|read| -> Vec<[f32; 4]> {
            bytemuck::pod_collect_to_vec(&read.slice(..).get_mapped_range().unwrap())
        });
        for (i, &(alpha, layer, tier)) in cases.iter().enumerate() {
            let l = layer & 0x7fff;
            let want = [
                f32::from(tier & !WHOLE),
                f32::from(u8::from(tier & WHOLE != 0)),
                f32::from(threshold(l)) / 255.0,
                1.0,
            ];
            let close = |got: [f32; 4]| (0..4).all(|c| (got[c] - want[c]).abs() < 1e-6);
            let case = format!("alpha {alpha:#04x}, layer {layer:#x}");
            assert!(
                close(pack[i]),
                "{case}: the pack read {:?}, not {want:?}",
                pack[i]
            );
            assert!(close(engine[i]), "{case}: the engine read {:?}", engine[i]);
        }
        let full = [200.0f32, 150.0, 90.0].map(|c| (c / 255.0).powf(2.2));
        for (got, who) in [(pack[16], "the pack"), (engine[16], "the engine")] {
            let close = (0..3).all(|c| (got[c] - full[c]).abs() < 1e-5);
            assert!(close, "{who} read the full light {got:?}, not {full:?}");
        }
    }

    /// A pack's material and shadow pass take their solid corners through the engine's own
    /// section path (terrain.wgsl's `section_corner` and `corner_inputs`, prefixed into the
    /// material's module): for the same compact records and the same wide vertex words, every
    /// field comes out of the pack's module bit for bit as out of the engine's terrain, on every
    /// device here, and the two layouts agree (#16127).
    #[test]
    fn a_pack_s_solid_corners_are_the_engine_s() {
        use crate::mesher::{TerrainVertex, packed};
        use wgpu::util::DeviceExt;
        // Records of every orientation, UV corner choice, light, grey level, tint and alpha
        // code (`packed`'s word layout), and the vertices each one stands for.
        let mut seed = 0x2545_f491u32;
        let mut next = || {
            seed = seed.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
            seed >> 2
        };
        let mut records: Vec<Option<[u32; 6]>> = (0..64u32)
            .map(|i| {
                let orient = next() & 0xfff | (i % 3) << 12 | (next() & 0xf) << 14;
                let [c0, c1, c2] = [next() % 6, next() % 6, next() % 6];
                Some([
                    next() << 2,
                    next() << 2,
                    next() << 2,
                    next() & 0xffff | (next() & 0xfff) << 16 | c0 << 28,
                    next() & 0xff_ffff | c1 << 24 | c2 << 27,
                    next() & 0xfff | orient << 12,
                ])
            })
            .collect();
        let mut quads: Vec<[TerrainVertex; 4]> = records
            .iter()
            .map(|r| std::array::from_fn(|c| packed::packed_vertex(&r.unwrap(), c)))
            .collect();
        // A quad off the block grid keeps its vertices (`packed::FULL`).
        let mut spill = quads[5];
        for (v, y) in spill.iter_mut().zip([8.5, 3.25, 0.125, 15.75]) {
            v.pos[1] = y;
        }
        quads.push(spill);
        records.push(None);
        let compact = packed::place(&records, &quads);
        assert_eq!(packed::packed_quads(&compact, quads.len()), 64);
        let wide: Vec<TerrainVertex> = quads.concat();
        let corners = wide.len() as u32;
        // Each corner's fields as the section path `p` (the engine's names, or the material's
        // prefixed ones) gives them, by its index in the layout.
        let entries = |p: &str| {
            format!(
                "
@group(2) @binding(0) var<storage, read_write> test_out: array<array<u32, 12>>;
@vertex fn test_corner(@builtin(vertex_index) v: u32) -> @builtin(position) vec4<f32> {{
    let c = {p}corner_inputs({p}section_corner(v).c);
    let q = bitcast<vec3<u32>>(c.position);
    let t = bitcast<vec4<u32>>(c.color);
    test_out[v & 0xfffffffu] = array<u32, 12>(q.x, q.y, q.z, c.uv.x, c.uv.y, c.layer, t.x,
        t.y, t.z, t.w, c.light.x, c.light.y);
    return vec4(2.0, 2.0, 2.0, 1.0);
}}
@fragment fn test_fs() -> @location(0) vec4<f32> {{
    return vec4(0.0);
}}
"
            )
        };
        let engine = super::super::wgsl_prefix::HDR_LIGHT.to_owned()
            + section(TERRAIN, "struct Globals {", "// Sky (SkyRenderer)")
            + &entries("");
        let stage = stage(
            "override gain: f32 = 1.0;\n\
             fn material(input: MaterialInput) -> Surface { return Surface(input.albedo * gain); }\n",
        );
        let source = stage.source.clone() + crate::gfx::looks::NO_LOOK_WGSL;
        let pack = shader_source(
            &source,
            &[],
            &[],
            (false, false, false, false, false),
            false,
        ) + &entries(PREFIX);
        let instance = crate::gfx::test_gpu::instance();
        let mut tested = Vec::new();
        for adapter in pollster::block_on(instance.enumerate_adapters(wgpu::Backends::all())) {
            let info = adapter.get_info();
            let device_name = format!("{} ({:?})", info.name, info.backend);
            let features = wgpu::Features::VERTEX_WRITABLE_STORAGE;
            if !adapter.features().contains(features) {
                eprintln!("{device_name}: no vertex storage writes");
                continue;
            }
            let (device, queue) =
                pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
                    required_features: features,
                    ..Default::default()
                }))
                .unwrap();
            let storage = |binding, read_only| wgpu::BindGroupLayoutEntry {
                binding,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Storage { read_only },
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            };
            let group_layout = |entries: &[wgpu::BindGroupLayoutEntry]| {
                device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                    label: None,
                    entries,
                })
            };
            let arena = super::super::flat::ARENA_BINDING;
            let pages = group_layout(&[storage(arena, true)]);
            let outs = group_layout(&[storage(0, false)]);
            let empty = group_layout(&[]);
            let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: None,
                bind_group_layouts: &[Some(&empty), Some(&pages), Some(&outs)],
                ..Default::default()
            });
            let format = wgpu::TextureFormat::Rgba8Unorm;
            let pipeline = |source: &str| {
                let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                    label: None,
                    source: wgpu::ShaderSource::Wgsl(source.into()),
                });
                device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                    label: None,
                    layout: Some(&layout),
                    vertex: wgpu::VertexState {
                        module: &module,
                        entry_point: Some("test_corner"),
                        compilation_options: Default::default(),
                        buffers: &[],
                    },
                    primitive: wgpu::PrimitiveState {
                        topology: wgpu::PrimitiveTopology::PointList,
                        ..Default::default()
                    },
                    depth_stencil: None,
                    multisample: Default::default(),
                    fragment: Some(wgpu::FragmentState {
                        module: &module,
                        entry_point: Some("test_fs"),
                        compilation_options: Default::default(),
                        targets: &[Some(format.into())],
                    }),
                    multiview_mask: None,
                    cache: None,
                })
            };
            let pipelines = [pipeline(&engine), pipeline(&pack)];
            let buffer = |bytes: &[u8], usage| {
                device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                    label: None,
                    contents: bytes,
                    usage,
                })
            };
            let bind = |layout, binding, buffer: &wgpu::Buffer| {
                device.create_bind_group(&wgpu::BindGroupDescriptor {
                    label: None,
                    layout,
                    entries: &[wgpu::BindGroupEntry {
                        binding,
                        resource: buffer.as_entire_binding(),
                    }],
                })
            };
            // The page in each layout, and the draw's vertex indices into it: the vertices
            // themselves, or a record's corners from `PACKED_BASE` on.
            let storage_usage = wgpu::BufferUsages::STORAGE;
            let wide_page = buffer(bytemuck::cast_slice(&wide), storage_usage);
            let compact_page = buffer(bytemuck::cast_slice(&compact), storage_usage);
            let layouts =
                [(&wide_page, 0), (&compact_page, packed::PACKED_BASE)].map(|(page, base)| {
                    let indices: Vec<u32> = (0..corners).map(|i| base + i).collect();
                    let indices = buffer(bytemuck::cast_slice(&indices), wgpu::BufferUsages::INDEX);
                    (bind(&pages, arena, page), indices)
                });
            let out_size = u64::from(corners) * 48;
            let out = |usage| {
                device.create_buffer(&wgpu::BufferDescriptor {
                    label: None,
                    size: out_size,
                    usage,
                    mapped_at_creation: false,
                })
            };
            let target = device.create_texture(&wgpu::TextureDescriptor {
                label: None,
                size: wgpu::Extent3d {
                    width: 1,
                    height: 1,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format,
                usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
                view_formats: &[],
            });
            let view = target.create_view(&Default::default());
            let empty_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &empty,
                entries: &[],
            });
            let draw = |pipeline: &wgpu::RenderPipeline, (page, indices): &(_, wgpu::Buffer)| {
                let written = out(wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_SRC);
                let read = out(wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST);
                let out_group = bind(&outs, 0, &written);
                let mut encoder = device.create_command_encoder(&Default::default());
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &view,
                        resolve_target: None,
                        depth_slice: None,
                        ops: Default::default(),
                    })],
                    ..Default::default()
                });
                pass.set_pipeline(pipeline);
                pass.set_bind_group(0, &empty_group, &[]);
                pass.set_bind_group(1, page, &[]);
                pass.set_bind_group(2, &out_group, &[]);
                pass.set_index_buffer(indices.slice(..), wgpu::IndexFormat::Uint32);
                pass.draw_indexed(0..corners, 0, 0..1);
                drop(pass);
                encoder.copy_buffer_to_buffer(&written, 0, &read, 0, out_size);
                queue.submit([encoder.finish()]);
                read.slice(..)
                    .map_async(wgpu::MapMode::Read, |r| r.unwrap());
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let words: Vec<[u32; 12]> =
                    bytemuck::pod_collect_to_vec(&read.slice(..).get_mapped_range().unwrap());
                words
            };
            let fields = [
                "position.x",
                "position.y",
                "position.z",
                "uv.x",
                "uv.y",
                "layer",
                "color.r",
                "color.g",
                "color.b",
                "color.a",
                "light.x",
                "light.y",
            ];
            let engine_wide = draw(&pipelines[0], &layouts[0]);
            for (name, pipeline, layout) in [
                ("the engine's records", &pipelines[0], &layouts[1]),
                ("the pack's vertices", &pipelines[1], &layouts[0]),
                ("the pack's records", &pipelines[1], &layouts[1]),
            ] {
                let got = draw(pipeline, layout);
                for (i, (want, got)) in engine_wide.iter().zip(&got).enumerate() {
                    for (field, (x, y)) in fields.iter().zip(want.iter().zip(got)) {
                        assert_eq!(x, y, "{device_name}: {name}, corner {i}'s {field}");
                    }
                }
            }
            // The engine read the vertex words as they are.
            for (i, (got, v)) in engine_wide.iter().zip(&wide).enumerate() {
                let light = [u32::from(v.light & 0xff), u32::from(v.light >> 8)];
                let words = [
                    v.pos.map(f32::to_bits).to_vec(),
                    v.uv.map(u32::from).to_vec(),
                ];
                assert_eq!(got[..5], words.concat()[..], "{device_name}: corner {i}");
                assert_eq!(got[5], u32::from(v.layer), "{device_name}: corner {i}");
                assert_eq!(got[10..], light[..], "{device_name}: corner {i}");
            }
            tested.push(device_name);
        }
        eprintln!("compared on {tested:?}");
    }
}
