//! The sky stage of Horizon's own shader packs (docs/shaders.md): the pack's `sky` function,
//! called for each pixel of the sky disc with vanilla's colour along its view ray. The
//! pipeline's shader is the pack's stage (`CheckedStage::source`) followed by a copy of the
//! renderer's sky (terrain.wgsl's `Globals`, `linear_fog` and sky section) whose names all
//! take a `horizon_sky_` prefix, so none can meet a pack's (the check refuses `horizon_`
//! names). It reads the renderer's globals (group 0) and the pack's frame (group 3), and
//! draws where vanilla's sky draws; the sun, moon, stars and the dark disc are drawn over it.

use horizon_shader_api::{check::CheckedStage, stages::GROUP};

use super::external::SkyPass;
use super::native_post::kept::StageReads;
use super::native_post::{NativeFrame, present_constants};
use super::wgsl_prefix::{TERRAIN, prefixed, section};

const PREFIX: &str = "horizon_sky_";

/// The fragment entry that calls the pack: vanilla's colour in, an opaque colour out.
const PACK_ENTRY: &str = "
@fragment fn horizon_sky_fs_pack(in: horizon_sky_SkyOut) -> @location(0) vec4<f32> {
    let d = horizon_sky_view_ray(in.ndc);
    let color = vec4(horizon_line_in(horizon_sky_sky_along_ray(d)), 1.0);
    return vec4(horizon_line_out(sky(SkyInput(d, color)).rgb), 1.0);
}
";

pub struct NativeSky {
    pipeline: wgpu::RenderPipeline,
    pub label: String,
    /// `[sky] reads`: none without.
    pub(super) kept: Option<StageReads>,
}

/// terrain.wgsl's sky with every name it declares (and `globals`) prefixed.
fn vanilla_sky() -> String {
    let text = [
        super::wgsl_prefix::HDR_LIGHT,
        section(TERRAIN, "struct Globals {", "@group(0) @binding(1)"),
        section(TERRAIN, "fn linear_fog(", "fn apply_fog("),
        section(TERRAIN, "struct SkyOut {", "// rendertype_lines"),
    ]
    .concat();
    prefixed(&text, PREFIX)
}

/// The sky shader for the pack's sky stage `source`, onto a frame that holds linear light when
/// `linear`.
fn shader_source(source: &str, linear: bool) -> String {
    format!(
        "{source}\n// Horizon's sky (terrain.wgsl)\n{}{}{PACK_ENTRY}",
        vanilla_sky(),
        super::native_post::line_helpers(linear)
    )
}

/// A sky pipeline over `module` whose fragment entry is `fragment`.
fn pipeline(
    device: &wgpu::Device,
    layout: &wgpu::PipelineLayout,
    module: &wgpu::ShaderModule,
    fragment: &str,
    constants: &[(&str, f64)],
    format: wgpu::TextureFormat,
) -> wgpu::RenderPipeline {
    let options = wgpu::PipelineCompilationOptions {
        constants,
        ..Default::default()
    };
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Native shader pack sky"),
        layout: Some(layout),
        vertex: wgpu::VertexState {
            module,
            entry_point: Some("horizon_sky_vs_sky"),
            compilation_options: options.clone(),
            buffers: &[],
        },
        primitive: Default::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(false),
            depth_compare: Some(wgpu::CompareFunction::Always),
            stencil: Default::default(),
            bias: Default::default(),
        }),
        multisample: Default::default(),
        fragment: Some(wgpu::FragmentState {
            module,
            entry_point: Some(fragment),
            compilation_options: options,
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
        }),
        multiview_mask: None,
        cache: None,
    })
}

/// The sky's naga module and the layout of its pipelines: `globals` at group 0, the frame
/// at group 3, with the kept resources the stage reads (`kept`).
fn build(
    device: &wgpu::Device,
    globals: &wgpu::BindGroupLayout,
    (frame, kept): (&NativeFrame, Option<&StageReads>),
    stage: &CheckedStage,
) -> Result<(naga::Module, wgpu::PipelineLayout), String> {
    let text = shader_source(&stage.source, frame.linear);
    let module = naga::front::wgsl::parse_str(&text)
        .map_err(|e| format!("{}: {}", stage.file, e.emit_to_string(&text)))?;
    let mut groups: [Option<&wgpu::BindGroupLayout>; GROUP as usize + 1] = Default::default();
    groups[0] = Some(globals);
    groups[GROUP as usize] = Some(kept.map_or(&frame.layout, |k| &k.layout));
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Native shader pack sky"),
        bind_group_layouts: &groups,
        ..Default::default()
    });
    Ok((module, layout))
}

impl NativeSky {
    /// The pipeline of the pack's sky `stage` with the option values `constants`, drawing
    /// onto the world's target of `format`; `globals` is the terrain's group 0, and the frame
    /// with the kept resources the stage reads (`kept`) its group 3.
    pub(in crate::gfx) fn new(
        device: &wgpu::Device,
        globals: &wgpu::BindGroupLayout,
        (frame, kept): (&NativeFrame, Option<StageReads>),
        stage: &CheckedStage,
        constants: &[(String, f64)],
        format: wgpu::TextureFormat,
    ) -> Result<Self, String> {
        let limits = device.limits();
        let others = super::native_material::terrain_entries();
        if let Some(why) = (kept.as_ref()).and_then(|k| k.over(frame, &others, &limits)) {
            return Err(format!("{}: {why}", stage.file));
        }
        let (module, layout) = build(device, globals, (frame, kept.as_ref()), stage)?;
        let present = present_constants(&module, constants);
        let validation = device.push_error_scope(wgpu::ErrorFilter::Validation);
        let internal = device.push_error_scope(wgpu::ErrorFilter::Internal);
        let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some(&super::dx12_compiler::module_label(&stage.label)),
            source: wgpu::ShaderSource::Naga(std::borrow::Cow::Owned(module)),
        });
        let pipeline = pipeline(
            device,
            &layout,
            &module,
            "horizon_sky_fs_pack",
            &present,
            format,
        );
        let internal = pollster::block_on(internal.pop());
        if let Some(e) = internal.or(pollster::block_on(validation.pop())) {
            return Err(format!("{}: {e}", stage.file));
        }
        Ok(Self {
            pipeline,
            label: stage.label.clone(),
            kept,
        })
    }

    /// Draws the sky in a pass whose group 0 is the terrain's (`group`).
    pub fn draw(&self, pass: &mut wgpu::RenderPass<'_>, frame: &NativeFrame, parity: usize) {
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(GROUP, self.group(frame, parity), &[]);
        pass.draw(0..3, 0..1);
    }

    /// Its group 3: the frame's, or the one with the kept resources it reads, this frame's
    /// version `parity`.
    pub(super) fn group<'a>(
        &'a self,
        frame: &'a NativeFrame,
        parity: usize,
    ) -> &'a wgpu::BindGroup {
        let kept = self.kept.as_ref().and_then(|k| k.group(parity));
        kept.unwrap_or(&frame.group)
    }
}

impl super::native_pack::NativePack {
    /// In a timed frame (`start_frame` said so), the pack's sky in a pass of its own, which
    /// clears the world's colour and depth first so that the world pass loads them.
    pub fn draw_sky_pass(&mut self, sky_pass: SkyPass<'_>) {
        let SkyPass {
            device,
            encoder,
            target: (view, format),
            depth,
            clear,
            globals,
        } = sky_pass;
        let Some(sky) = &self.sky else {
            return;
        };
        if let Some(t) = &mut self.timing {
            t.mark(device, encoder, (view, format));
        }
        let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some(&sky.label),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view,
                resolve_target: None,
                depth_slice: None,
                ops: wgpu::Operations {
                    load: wgpu::LoadOp::Clear(clear),
                    store: wgpu::StoreOp::Store,
                },
            })],
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                view: depth,
                depth_ops: Some(wgpu::Operations {
                    load: wgpu::LoadOp::Clear(0.0),
                    store: wgpu::StoreOp::Discard,
                }),
                stencil_ops: None,
            }),
            timestamp_writes: self.timing.as_mut().and_then(|t| t.writes(&sky.label)),
            ..Default::default()
        });
        pass.set_bind_group(0, globals, &[]);
        sky.draw(&mut pass, &self.frame, self.post.parity());
    }

    /// The pack's sky inside the world pass, whose group 0 is the terrain's. False when the
    /// pack has no sky stage, for the renderer's own.
    pub fn draw_sky(&self, pass: &mut wgpu::RenderPass<'_>) -> bool {
        let Some(sky) = &self.sky else {
            return false;
        };
        sky.draw(pass, &self.frame, self.post.parity());
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use horizon_shader_api::{Frame as FrameInputs, MANIFEST, Pack, StageKind, check};

    fn stage(sky: &str) -> CheckedStage {
        let mut manifest = "schema = 1\nid = \"t\"\nname = \"T\"\nversion = \"1\"\napi = \"0.2\"\n\
            [sky]\nfile = \"sky.wgsl\"\n"
            .to_owned();
        if sky.contains("gain") {
            manifest += "[[options]]\nid = \"gain\"\nname = \"Gain\"\ntype = \"float\"\n\
                default = 1.0\nmin = 0.0\nmax = 2.0\n";
        }
        let manifest = manifest.as_str();
        let files = [(MANIFEST, manifest), ("sky.wgsl", sky)]
            .map(|(n, t)| (n.to_owned(), t.as_bytes().to_vec()))
            .into();
        let mut report = check(&Pack::from_files(files).unwrap()).unwrap();
        assert_eq!(report.stages[0].kind, StageKind::Sky);
        report.stages.remove(0)
    }

    #[test]
    fn the_renderer_s_sky_takes_a_prefix_and_validates_with_a_pack() {
        let _gpu = crate::gfx::test_gpu::lock();
        let sky = vanilla_sky();
        for name in [
            "Globals",
            "SkyOut",
            "view_ray",
            "PI",
            "sky_along_ray",
            "linear_fog",
            "fs_sky",
        ] {
            assert!(sky.contains(&format!("{PREFIX}{name}")), "{name}");
        }
        // A pack may use the renderer's names for its own things.
        let own = "override gain: f32;\nconst PI: f32 = 3.0;\nfn view_ray() -> f32 { return PI; }\n\
            fn sky(input: SkyInput) -> vec4<f32> { return input.color * gain * view_ray(); }\n";
        let text = shader_source(&stage(own).source, false);
        let module = naga::front::wgsl::parse_str(&text).unwrap_or_else(|e| {
            panic!("{}", e.emit_to_string(&text));
        });
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::default(),
        )
        .validate(&module)
        .unwrap();
    }

    /// The terrain's group 0, the globals a sky reads.
    fn globals_layout(device: &wgpu::Device) -> wgpu::BindGroupLayout {
        device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: None,
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        })
    }

    fn frame(device: &wgpu::Device) -> NativeFrame {
        NativeFrame::new(device, None, Vec::new(), Default::default(), None, false)
    }

    /// A pack names its stages, and the module's label comes from that name: one with a
    /// colon, or one starting like a command-line option, still compiles on Vulkan and on
    /// DirectX 12 with both its compilers (#16258). DXC needs `dxcompiler.dll` beside the
    /// test or on `PATH`; a device this machine lacks is skipped.
    #[test]
    fn a_stage_s_name_does_not_stop_it_compiling() {
        let _gpu = crate::gfx::test_gpu::lock();
        for (backends, compiler, name) in [
            (wgpu::Backends::VULKAN, Default::default(), "Vulkan"),
            (
                wgpu::Backends::DX12,
                wgpu::Dx12Compiler::Fxc,
                "DirectX 12, FXC",
            ),
            (
                wgpu::Backends::DX12,
                wgpu::Dx12Compiler::default_dynamic_dxc(),
                "DirectX 12, DXC",
            ),
        ] {
            let mut desc = wgpu::InstanceDescriptor::new_without_display_handle();
            desc.backends = backends;
            desc.backend_options.dx12.shader_compiler = compiler;
            let instance = wgpu::Instance::new(desc);
            let Ok(adapter) = pollster::block_on(instance.request_adapter(&Default::default()))
            else {
                eprintln!("{name}: skipped");
                continue;
            };
            let (device, _) =
                pollster::block_on(adapter.request_device(&Default::default())).unwrap();
            let (globals, frame) = (globals_layout(&device), frame(&device));
            for (i, label) in ["Sky: dusk", "-dusk", "/E"].into_iter().enumerate() {
                // A shader of its own each: a device compiles the same shader only once.
                let mut stage = stage(&format!(
                    "fn sky(input: SkyInput) -> vec4<f32> {{ return input.color * {i}.0; }}\n"
                ));
                stage.label = label.to_owned();
                let format = wgpu::TextureFormat::Rgba8Unorm;
                let internal = device.push_error_scope(wgpu::ErrorFilter::Internal);
                let sky = NativeSky::new(&device, &globals, (&frame, None), &stage, &[], format);
                let internal = pollster::block_on(internal.pop());
                assert!(
                    sky.is_ok() && internal.is_none(),
                    "{name}, {label:?}: {internal:?}"
                );
                assert_eq!(sky.unwrap().label, label);
            }
            eprintln!("{name}: compiled");
        }
    }

    /// Vanilla's sky and two packs over the same globals: one that returns its input draws
    /// vanilla's pixels within an 8-bit step (decoded on the way in, encoded on the way out), one
    /// that halves their light draws that (and stays opaque).
    #[test]
    fn a_pack_gets_vanilla_s_colour_and_draws_opaque() {
        let _gpu = crate::gfx::test_gpu::lock();
        let instance = crate::gfx::test_gpu::instance();
        let Ok(adapter) = pollster::block_on(instance.request_adapter(&Default::default())) else {
            return;
        };
        let (device, queue) =
            pollster::block_on(adapter.request_device(&Default::default())).unwrap();
        let format = wgpu::TextureFormat::Rgba8Unorm;
        let globals_layout = globals_layout(&device);
        let mut globals: super::super::Globals = bytemuck::Zeroable::zeroed();
        globals.inverse_view = glam::Mat4::IDENTITY.to_cols_array_2d();
        globals.misc = [0.0, 0.0, 1.0, 1.0];
        globals.fog_color = [0.2, 0.4, 0.6, 1.0];
        globals.sky_color = [0.5, 0.7, 1.0, 1.0];
        globals.fog_ends = [64.0, 0.0, 0.0, 0.0];
        let globals_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: None,
            size: size_of::<super::super::Globals>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        queue.write_buffer(&globals_buffer, 0, bytemuck::bytes_of(&globals));
        let globals_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &globals_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: globals_buffer.as_entire_binding(),
            }],
        });
        let frame = frame(&device);
        queue.write_buffer(
            &frame.buffer,
            0,
            bytemuck::bytes_of(&FrameInputs::default()),
        );

        let gain = [("gain".to_owned(), 1.0)];
        let draw = |stage: &CheckedStage, vanilla: bool| -> Vec<u8> {
            let pack = (&frame, None);
            let sky = NativeSky::new(&device, &globals_layout, pack, stage, &gain, format).unwrap();
            let pipeline = if vanilla {
                let (module, layout) =
                    build(&device, &globals_layout, (&frame, None), stage).unwrap();
                let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                    label: None,
                    source: wgpu::ShaderSource::Naga(std::borrow::Cow::Owned(module)),
                });
                pipeline(&device, &layout, &module, "horizon_sky_fs_sky", &[], format)
            } else {
                sky.pipeline.clone()
            };
            let texture = |format, usage| {
                device.create_texture(&wgpu::TextureDescriptor {
                    label: None,
                    size: wgpu::Extent3d {
                        width: 4,
                        height: 4,
                        depth_or_array_layers: 1,
                    },
                    mip_level_count: 1,
                    sample_count: 1,
                    dimension: wgpu::TextureDimension::D2,
                    format,
                    usage,
                    view_formats: &[],
                })
            };
            let color = texture(
                format,
                wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
            );
            let depth = texture(
                wgpu::TextureFormat::Depth32Float,
                wgpu::TextureUsages::RENDER_ATTACHMENT,
            );
            let (color_view, depth_view) = (
                color.create_view(&Default::default()),
                depth.create_view(&Default::default()),
            );
            let mut encoder = device.create_command_encoder(&Default::default());
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: None,
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &color_view,
                        resolve_target: None,
                        depth_slice: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                        view: &depth_view,
                        depth_ops: Some(wgpu::Operations {
                            load: wgpu::LoadOp::Clear(0.0),
                            store: wgpu::StoreOp::Discard,
                        }),
                        stencil_ops: None,
                    }),
                    ..Default::default()
                });
                pass.set_bind_group(0, &globals_group, &[]);
                pass.set_pipeline(&pipeline);
                pass.set_bind_group(GROUP, &frame.group, &[]);
                pass.draw(0..3, 0..1);
            }
            let buffer = device.create_buffer(&wgpu::BufferDescriptor {
                label: None,
                size: u64::from(wgpu::COPY_BYTES_PER_ROW_ALIGNMENT * 4),
                usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            encoder.copy_texture_to_buffer(
                color.as_image_copy(),
                wgpu::TexelCopyBufferInfo {
                    buffer: &buffer,
                    layout: wgpu::TexelCopyBufferLayout {
                        offset: 0,
                        bytes_per_row: Some(wgpu::COPY_BYTES_PER_ROW_ALIGNMENT),
                        rows_per_image: Some(4),
                    },
                },
                color.size(),
            );
            queue.submit([encoder.finish()]);
            buffer
                .slice(..)
                .map_async(wgpu::MapMode::Read, |r| r.unwrap());
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let bytes = buffer.slice(..).get_mapped_range().unwrap().to_vec();
            (0..4)
                .flat_map(|row| {
                    let start = row * wgpu::COPY_BYTES_PER_ROW_ALIGNMENT as usize;
                    bytes[start..start + 16].to_vec()
                })
                .collect()
        };
        let same = stage("fn sky(input: SkyInput) -> vec4<f32> { return input.color; }\n");
        let vanilla = draw(&same, true);
        for (got, want) in draw(&same, false).iter().zip(&vanilla) {
            assert!(got.abs_diff(*want) <= 1, "{got} {want}");
        }
        // The top row looks up into the sky disc, the bottom one down into the fog.
        assert_ne!(vanilla[..4], vanilla[vanilla.len() - 4..]);
        let half = stage(
            "override gain: f32;\nfn sky(input: SkyInput) -> vec4<f32> { return vec4(input.color.rgb * gain * 0.5, 0.25); }\n",
        );
        let halved = draw(&half, false);
        // Half the light is 0.5^(1/2.2) of the encoded value.
        let encoded_half = 0.5f32.powf(1.0 / 2.2);
        for (got, want) in halved.chunks(4).zip(vanilla.chunks(4)) {
            assert_eq!(got[3], 255);
            for i in 0..3 {
                let want = (f32::from(want[i]) * encoded_half).round() as u8;
                assert!(got[i].abs_diff(want) <= 1, "{got:?} {want}");
            }
        }
    }
}
